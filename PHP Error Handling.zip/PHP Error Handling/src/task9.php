<?php
echo "<h3>9. Use error_get_last() function print message from the last error that occurred</h3>";
echo $a;
print_r(error_get_last()); //priniting error with error_get_last()-----
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
