<?php
echo "<h3>3. Create a custom error handling using die() function when unable to open  certain file</h3>";
if (file_exists("mytestfile.txt")) { //if file exists than it will open file--
    $file = fopen("mytestfile.txt", "r");
} else {
    die("Error: The file does not exist."); //die() with custom error message--
}
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
