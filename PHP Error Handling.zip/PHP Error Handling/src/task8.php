<?php
echo "<h3>8. Create a custom error displaying the file name and line number of the error</h3>";
// User-defined error handling function---
function customErrorHandlar($errorNo, $errorMessage, $errorFile, $errorLine)
{
    // Giving Error Message with line number---
    echo "Error Message: [$errorNo] $errorMessage<br>";
    echo "Error on line $errorLine in $errorFile";
}
// Set Error Handler---
set_error_handler("customErrorHandlar");
$file = fopen("mytestfile.txt", "r"); //for open mytestfile.txt file---
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
