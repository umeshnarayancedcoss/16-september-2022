<?php
echo "<h3>5. Use E_USER_WARNING if a variable is greater than 1 and trigger a custom error</h3>";
//error handler function---
function customError($errno, $errstr)
{
    echo "<b>Error:</b> [$errno] $errstr<br>";
    die();
}
//set error handler---
set_error_handler("customError", E_USER_WARNING);
//trigger error---
$value = 150; //variable initilization---
if ($value > 1) {
    trigger_error("Value must be 1 or below", E_USER_WARNING); //trigger custom warning---
}
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
