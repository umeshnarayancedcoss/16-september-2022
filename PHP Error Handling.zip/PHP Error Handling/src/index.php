<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>PHP Error Handling</title>
</head>

<body>
    <center>
        <h1>PHP Error Handling</h1>
        <!-- ---Table Starts Here---- -->
        <table class="table table-striped">
            <tr>
                <th>Task No.</th>
                <th>Task Name</th>
                <th>View</th>
            </tr>
            <tr>
                <td>01.</td>
                <td>Trigger an error for certain variable value greater than 100</td>
                <td><a href="./task1.php">View</a></td>
            </tr>
            <tr>
                <td>02.</td>
                <td>Use E_USER_NOTICE if a file exist else use E_USER_ERROR and trigger error</td>
                <td><a href="./task2.php">View</a></td>
            </tr>
            <tr>
                <td>03.</td>
                <td>Create a custom error handling using die() function when unable to open certain file</td>
                <td><a href="./task3.php">View</a></td>
            </tr>
            <tr>
                <td>04.</td>
                <td>Create a custom error handler using set error handler that shows error no and error string</td>
                <td><a href="./task4.php">View</a></td>
            </tr>
            <tr>
                <td>05.</td>
                <td>Use E_USER_WARNING if a variable is greater than 1 and trigger a custom error</td>
                <td><a href="./task5.php">View</a></td>
            </tr>
            <tr>
                <td>06.</td>
                <td>Design a navbar and show custom error instead of error 404</td>
                <td><a href="./task6.php">View</a></td>
            </tr>
            <tr>
                <td>07.</td>
                <td>Log errors into my-error.log file</td>
                <td><a href="./task7.php">View</a></td>
            </tr>
            <tr>
                <td>08.</td>
                <td>Create a custom error displaying the file name and line number of the error</td>
                <td><a href="./task8.php">View</a></td>
            </tr>
            <tr>
                <td>09.</td>
                <td>Use error_get_last() function print message from the last error that occurred</td>
                <td><a href="./task9.php">View</a></td>
            </tr>
            <tr>
                <td>10.</td>
                <td>Send error message to the server log if error connecting to the database</td>
                <td><a href="./task10.php">View</a></td>
            </tr>
        </table>
    </center>
</body>

</html>