<?php
// session starts here----------
session_start();
//session for session product array-----
if (!isset($_SESSION['product'])) {
    $_SESSION['product'] = array();
}
//session for cart array-------
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}
// session for quantity array----------
if (!isset($_SESSION['quantity'])) {
    $_SESSION['quantity'] = 0;
}
// Holding products details into variables-----
$pro_id = $_REQUEST['pro_id'];
$pro_images = $_REQUEST['pro_image'];
$pro_title = $_REQUEST['pro_title'];
$pro_price = $_REQUEST['pro_price'];
$flag = 0; //temporary variable for insertion data into cart---
//condition if cart will be empty---
if (count($_SESSION['cart']) == 0) {
    $_SESSION['quantity'] = $_SESSION['quantity'] + 1;
    $cart_data = array("productid" => $pro_id, "images" => $pro_images, "title" => $pro_title, "price" => $pro_price, "quantity" => $_SESSION['quantity']);
    array_push($_SESSION['cart'], $cart_data);
} else if (count($_SESSION['cart']) > 0) { //checking that products already exists in cart or not.
    foreach ($_SESSION['cart'] as &$value1) {
        if ($pro_id == $value1['productid']) {
            $flag = 1;
            $value1['quantity'] += 1;
        }
    }
    if ($flag == 0) { //if same product not exists in cart----
        $_SESSION['quantity'] = 1;
        $cart_data = array("productid" => $pro_id, "images" => $pro_images, "title" => $pro_title, "price" => $pro_price, "quantity" => $_SESSION['quantity']);
        array_push($_SESSION['cart'], $cart_data);
    }
}
header("location:products.php");
