<style>
    <?php
    //  CSS linking for cart table----
    include("style.css");
    ?>
</style>
<?php
//session starts here----
session_start();
if (!isset($_SESSION['product'])) {
    $_SESSION['product'] = array();
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}
if (!isset($_SESSION['quantity'])) {
    $_SESSION['quantity'] = 0;
}

if (count($_SESSION['cart']) == 0) { //if cart is empty
    echo "<h1>Cart is Empty, Please add some products in cart.!!<h1>";
    // Display cart table-----------
} else {
    echo '<a href="deletecart.php"><button id="del_cart">Delete Cart</button></a>';
    echo "<br/>";
    echo "<br/>";
    echo '<table border="1px solid" >
<tr>
	<th><h2>Product ID</h2></th>
	<th><h2>Product Title</h2></th>
	<th><h2>Product Image</h2></th>
	<th><h2>Product Price</h2></th>
    <th><h2>Product Quantity</h2></th>
     <th><h2>Action</h2></th>
</tr>
<tr>';
?>
<?php
    $index = 0;
    $total = 0;
    foreach ($_SESSION['cart'] as $key => $val1) {
        $price = $val1["price"] * $val1["quantity"];
        echo '<td><h2>' . $val1["productid"] . '</h2></td>';
        echo '<td><h2>' . $val1["title"] . '</h2></td>';
        echo '<td><img src="./images/' . $val1['images'] . '" /></td>';
        echo '<td><h2>$' . $price . '.00</h2></td>';
        echo '<td><h2><a href="cart_qty.php?pro_id=' . $val1["productid"] . '&&op=dec&&pro_qty=' . $val1["quantity"] . '&&index=' . $index . '"><button id="dec">-</button></a>  ' . $val1["quantity"] . ' <a href="cart_qty.php?pro_id=' . $val1["productid"] . '&&op=inc&&pro_qty=' . $val1["quantity"] . '&&index=' . $index . '"><button id="inc">+</button></a> </h2> </td>';
        echo '<td><a href="remove_cart.php?index=' . $index . '"><button id="remove">Remove</button></a></td>';
        echo '</tr>';
        $index++;
        $total = $total + ($val1["price"] * $val1["quantity"]);
    }
    echo '</table>';
    echo '<p>Total Cart Price: $' . $total . '.00</p>';
}
?>