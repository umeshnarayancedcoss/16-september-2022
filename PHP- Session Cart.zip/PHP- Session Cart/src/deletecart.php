<?php
//session starts here---
session_start();
echo "<script>";
$_SESSION['cart'] = []; //cart session array will be empty----
$_SESSION['quantity'] = 0; //quantity session set as 0-------
echo "alert('Cart  deleted successfully.!!');
window.location.href='products.php';
</script>";
