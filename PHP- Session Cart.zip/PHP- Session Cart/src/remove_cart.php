<?php
//session starts here---
session_start();
$index = $_REQUEST['index']; //holding array index
echo "<script>";
array_splice($_SESSION['cart'], $index, 1); //deleting products from cart
$_SESSION['quantity'] = 0;
echo "alert('Item removed from cart successfully.!!');
window.location.href='products.php';
</script>";
