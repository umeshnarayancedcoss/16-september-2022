<?php
// Redirecting to Register Page---
header("location:./private/View/Register.php");
