<?php
//ActiveRecord Model extending properties to Class User----
class User extends ActiveRecord\Model
{
}
