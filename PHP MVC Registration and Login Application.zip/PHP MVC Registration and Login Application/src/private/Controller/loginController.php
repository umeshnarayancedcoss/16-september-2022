<?php
// session starts here---
session_start();
include("../config/config.php"); //database connectivity--
if (isset($_POST)) {
    // Holding Form Values in variables---
    $email = $_POST['email'];
    $password = $_POST['password'];
    // Fetching Record From tbl_users-----
    $user = User::find('all', array('conditions' => array('email' => $email, 'password' =>  $password)));
    if ($user) { //if email password matched---
        $_SESSION['user'] = $email; //creating session of users emailID----
        header("location:../View/UserProfile.php"); //redirecting to userProfile page---
    } else { //if email password not matched---
        $msg = "Error: Invalid Email or Password..!!";
        header("location:../View/Login.php?msg=$msg"); //redirecting to Login page with error message---
    }
}
