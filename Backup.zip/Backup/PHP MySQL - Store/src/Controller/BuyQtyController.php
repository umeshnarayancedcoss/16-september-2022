<?php
// session starts here---
session_start();
$op = $_REQUEST['op']; //holding operation---
$pro_id = $_REQUEST['pro_id']; //holding product id----
// For Increase Quantity----
if ($op == 'inc') {
    $_SESSION['quantity']++;
    header("location:./BuyNowController.php?pro_id=$pro_id");
}
// For Decrease Quantity-------
if ($op == 'dec') {
    if ($_SESSION['quantity'] == 1) {
        $_SESSION['quantity'] = 1;
        header("location:./BuyNowController.php?pro_id=$pro_id");
    } else {
        $_SESSION['quantity']--;
        header("location:./BuyNowController.php?pro_id=$pro_id");
    }
}
