<?php
// session _starts here---
session_start();
$email = $_SESSION['user'];
include("../Config/config.php"); //Database connectivity-----
// ----------------Fetching User Detail------------------------
$query1 = "SELECT * FROM tbl_user where email = '$email'"; //select query for fetch user detail----
$result1 = mysqli_query($conn, $query1);
if (mysqli_num_rows($result1) > 0) {
    while ($row1 = mysqli_fetch_assoc($result1)) {
        // holding user id and name and address in variables----
        $user_id =  $row1["user_id"];
        $user_name =  $row1["username"];
        $user_address = $row1['address'];
    }
}
$payment_mode = $_POST['select'];
// Select query for fetching poducts from product table---------
$query = "SELECT * FROM tbl_cart WHERE user_id='$user_id'";
$result = mysqli_query($conn, $query);
$a = 1;
$total = 0;
while ($row = mysqli_fetch_assoc($result)) {
    $product_id = $row['product_id'];
    $quantity = $row['quantity'];
    $price = $row['price'];
    $product_name = $row['product_name'];
    $category = $row['category'];
    $image = $row['image'];
    $user_id = $row['user_id'];
    // Insertion query for inserting all cart items in order table----
    $query3 = "INSERT INTO `tbl_order` (`order_id`, `user_id`, `pro_id`, `pro_name`, `pro_category`, `pro_image`, `quantity`, `price`, `payment_mode`,`date`, `status`) VALUES (NULL, '$user_id', '$product_id', '$product_name', '$category', '$image', '$quantity', '$price', '$payment_mode',curdate(), 'Pending')";
    mysqli_query($conn, $query3); //executing query---
}
//after insertion in order table,deleting items from cart----
$query4 = "DELETE FROM `tbl_cart` WHERE `tbl_cart`.`user_id` = $user_id";
mysqli_query($conn, $query4);
echo "<script>alert('Order Placed Successfully.!!');window.location.href='../View/MyOrder.php';</script>";
