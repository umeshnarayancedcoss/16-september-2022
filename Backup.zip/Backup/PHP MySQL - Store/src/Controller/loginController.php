<?php
// session starts here---
session_start();
include("../Config/config.php"); //database connectivity--
$email = $_POST['email'];
$password = $_POST['password'];
// --select query for fetching users details---
$query = "select email,password,status from tbl_user where email = '$email' and password = '$password' and status='Approved' ";
$res = mysqli_query($conn, $query); //executing query---
if ($row = mysqli_fetch_array($res, MYSQLI_BOTH)) {
    $_SESSION['user'] = $email; //creating session of user's email-----
    $redirect_url = isset($_SESSION['redirect_url']) ? $_SESSION['redirect_url'] : "";
    if ($redirect_url == "") {
        header("location:../index.php");
    } else {
        $page = explode("&", $redirect_url); //exploding page name after '&'------
        $gotopage = explode("=", $page[0]); //exploding pro_id from page name----
        $nextpage = $gotopage[1];
        $nextpage = $nextpage;
        $query_string = $page[1];
        $header_url = $nextpage . "?" . $query_string; //making header url----
        header("location:$header_url");
    }
} else {
    $redirect_url = isset($_SESSION['redirect_url']) ? $_SESSION['redirect_url'] : "";
    if ($redirect_url == "") {
        header("location:../View/Login.php");
    } else { //redirecting to specific page------
        header("location:Login.php?$redirect_url");
    }
}
