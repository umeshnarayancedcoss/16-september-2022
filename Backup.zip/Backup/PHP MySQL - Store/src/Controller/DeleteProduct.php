<?php
// session starts here---
session_start();
$pro_id = $_REQUEST['pro_id'];
include("../Config/config.php"); //database connectivity----
$query = "DELETE FROM `tbl_product` WHERE `tbl_product`.`pro_id` = $pro_id"; //delete query----
mysqli_query($conn, $query); //executing query---
echo "<script>alert('Product Deleted Successfully.!!');window.location.href='../View/AdminViewProduct.php';</script>";
