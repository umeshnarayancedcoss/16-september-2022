<?php
// session starts here----
session_start();
$user_id = $_REQUEST['user_id'];
include("../Config/config.php"); //database connectivity---
// Update query for update status from 'Requested' to 'Approved'---------
$query = "UPDATE `tbl_user` SET `status` = 'Approved' WHERE `tbl_user`.`user_id` = $user_id;";
mysqli_query($conn, $query); //executing query---
echo "<script>alert('User Status Updated Successfully.!!');window.location.href='../View/AdminViewUser.php';</script>";
