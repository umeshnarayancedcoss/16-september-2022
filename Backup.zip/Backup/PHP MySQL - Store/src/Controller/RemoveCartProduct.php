<?php
// session starts here------
session_start();
$cart_id = $_REQUEST['cart_id'];
include("../Config/config.php"); //database connectivity---
// Delete query for delete products from cart---
$query = "DELETE FROM `tbl_cart` WHERE `tbl_cart`.`cart_id` = $cart_id";
mysqli_query($conn, $query); //executing query---
