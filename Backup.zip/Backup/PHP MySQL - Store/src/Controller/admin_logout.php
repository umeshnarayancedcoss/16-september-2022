<?php
// session starts here----
session_start();
session_unset();
session_destroy(); //session destroy here---
header("location:../admin/index.php");
