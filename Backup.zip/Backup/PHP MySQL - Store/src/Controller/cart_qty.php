<?php
//session starts here--
session_start();
$op = $_REQUEST['op'];
$cart_id = $_POST['cart_id'];
include("../Config/config.php"); //database connectivity---
if ($op == "inc") { //for increase counter
    $query1 = "SELECT * FROM tbl_cart where cart_id = '$cart_id'"; //select query for fetching cart detail----
    $result1 = mysqli_query($conn, $query1);
    if (mysqli_num_rows($result1) > 0) {
        while ($row1 = mysqli_fetch_assoc($result1)) {
            $product_quantity =  $row1["quantity"] + 1; //increasing quantity by 1---
            $query5 = "UPDATE `tbl_cart` SET `quantity` = '$product_quantity' WHERE `tbl_cart`.`cart_id` = $cart_id;";
            mysqli_query($conn, $query5);
        }
    }
}
if ($op == 'dec') { //for decrease counter
    $query = "SELECT * FROM tbl_cart where cart_id = '$cart_id'"; //select query for fetching cart detail----
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $product_quantity =  $row["quantity"];
            if ($product_quantity == 1) { //if quantity will be 0 , it will remove item from cart---
                $query3 = "DELETE FROM `tbl_cart` WHERE `tbl_cart`.`cart_id` = $cart_id";
                mysqli_query($conn, $query3);
                echo 0;
            } else {
                $product_quantity =  $row["quantity"] - 1; //quantity decrease by 1---
                $query6 = "UPDATE `tbl_cart` SET `quantity` = '$product_quantity' WHERE `tbl_cart`.`cart_id` = $cart_id;";
                mysqli_query($conn, $query6);
            }
        }
    }
}
