<?php
// session starts here----
session_start();
$pro_id = $_REQUEST['pro_id']; //holding product id----
include("../Config/config.php"); //database connectivity---
// Updating status from 'Hide' to 'Show'-----
$query = "UPDATE `tbl_product` SET `status` = 'Show' WHERE `tbl_product`.`pro_id` = $pro_id;";
mysqli_query($conn, $query); //executing query---
echo "<script>alert('Product Status Updated Successfully.!!');window.location.href='../View/AdminViewProduct.php';</script>";
