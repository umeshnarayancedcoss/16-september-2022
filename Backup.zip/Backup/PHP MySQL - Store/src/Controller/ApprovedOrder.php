<?php
// session starts here---
session_start();
$order_id = $_REQUEST['order_id'];
include("../Config/config.php"); //database connectivity--
// update query for update status from 'Pending' to 'Approved'----
$query = "UPDATE `tbl_order` SET `status` = 'Delivered' WHERE `tbl_order`.`order_id` = $order_id";
mysqli_query($conn, $query);
header("location:../View/AdminViewOrder.php");
