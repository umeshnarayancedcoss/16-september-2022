<?php
// session starts here----
session_start();
$order_id = $_REQUEST['order_id']; //Holding Order Id
include("../Config/config.php"); //database connectivity---
// Updating query for changing status from 'Pending' to 'Approved'------
$query = "UPDATE `tbl_order` SET `status` = 'Approved' WHERE `tbl_order`.`order_id` = $order_id";
mysqli_query($conn, $query); //executing query---
header("location:../View/AdminViewOrder.php");
