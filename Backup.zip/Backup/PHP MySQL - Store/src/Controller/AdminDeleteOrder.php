<?php
// session starts here---
session_start();
$order_id = $_REQUEST['order_id']; //holding order id
include("../Config/config.php"); //database connection--
$query = "DELETE FROM `tbl_order` WHERE `tbl_order`.`order_id` = $order_id"; //delete query---
mysqli_query($conn, $query); //executing query--
echo "<script>alert('Order Deleted Successfully.!!');window.location.href='../View/AdminViewOrder.php';</script>";
