<?php
// session starts here----
session_start();
$email = $_SESSION['user'];
include("../Config/config.php"); //database connectivity---
$pro_id = $_REQUEST['pro_id']; //holding product id---
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:../View/Login.php");
}
// NavBar Condition----
if (isset($_SESSION['user'])) {
    include("../View/UserMenu.php");
} else {
    include("../View/menu.php");
}
//--------select query for fetch user detail---------------------------
$query1 = "SELECT * FROM tbl_user where email = '$email'";
$result1 = mysqli_query($conn, $query1);
if (mysqli_num_rows($result1) > 0) {
    while ($row1 = mysqli_fetch_assoc($result1)) {
        // holding user id,name,address in variables----
        $user_id =  $row1["user_id"];
        $user_name =  $row1["username"];
        $user_address = $row1['address'];
    }
}
// ------------------Query For Fetching Product Detail----------------
$query = "SELECT * FROM tbl_product where pro_id=$pro_id";
$result = mysqli_query($conn, $query); //executing query-----
while ($row = mysqli_fetch_assoc($result)) {
    // Holding product details into variables------------
    $pro_name = $row['pro_name'];
    $category = $row['category'];
    $image = $row['image'];
    $title = $row['title'];
    $quantity = $row['quantity'];
    $price = $row['price'];
}
if (!isset($_SESSION['quantity'])) {
    $_SESSION['quantity'] = 1;
}
if (isset($_POST['checkout'])) {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $payment_mode = $_POST['select'];
    $total_price = $price * $_SESSION['quantity'];
    // Inseertion query for inserting detail in order table------
    $query3 = "INSERT INTO `tbl_order` (`order_id`, `user_id`, `pro_id`, `pro_name`, `pro_category`, `pro_image`, `quantity`, `price`, `payment_mode`,`date`, `status`) VALUES (NULL, '$user_id', '$pro_id', '$pro_name', '$category', '$image', '$quantity', '$total_price', '$payment_mode',curdate(), 'Pending')";
    mysqli_query($conn, $query3); //executing query---
    echo "<script>alert('Order Placed Successfully.!!');window.location.href='../View/MyOrder.php';</script>";
}
?>
<!-- --HTML Code starts here- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="../css/MyCart.css" rel="stylesheet">
    <title>View Product</title>
    <style>
        body {
            overflow: hidden;
        }
    </style>
</head>

<body>
    <!-- Buy Now Div Starts Here--- -->
    <div class="card" style="margin-top: 70px;">
        <div class="row">
            <div class="col-md-8 cart">
                <div class="title">
                    <div class="row">
                        <div class="col">
                            <h4><b>Shopping Now</b></h4>
                        </div>
                    </div>
                </div>
                <div class="row border-top border-bottom">
                    <div class="row main align-items-center">
                        <div class="col-2"><img class="img-fluid" src="../images/<?php echo $image; ?>"></div>
                        <div class="col">
                            <div class="row text-muted"><?php echo $category; ?></div>
                            <div class="row"><?php echo $pro_name; ?></div>
                        </div>
                        <div class="col">
                            <a href="../Controller/BuyQtyController.php?op=dec&&pro_id=<?php echo $pro_id; ?>">-</a><a href="#" class="border"><?php echo $_SESSION['quantity']; ?></a><a href="../Controller/BuyQtyController.php?op=inc&&pro_id=<?php echo $pro_id; ?>">+</a>
                        </div>
                        <div class="col"><?php echo $price * $_SESSION['quantity']; ?> Rs.<span class="close">&#10005;</span></div>
                    </div>
                </div>
                <div class="back-to-shop"><a href="../index.php">&leftarrow;</a><span class="text-muted">Back to shop</span></div>
            </div>
            <div class="col-md-4 summary">
                <div>
                    <h5><b>Summary</b></h5>
                </div>
                <hr>
                <div class="row">
                    <div class="col" style="padding-left:0;">Price</div>
                    <div class="col text-right"><?php echo $price * $_SESSION['quantity']; ?> Rs.</div>
                </div>
                <!-- --Form Starts Here---- -->
                <form method="POST" action="">
                    <p>Name</p>
                    <input type="text" placeholder="Enter your name" name="name" value="<?php echo $user_name; ?>">
                    <p>Address</p>
                    <textarea name="address" cols="30" rows="2" style="resize:none;"><?php echo $user_address; ?></textarea>
                    <p>Mode Of Payment</p>
                    <select name="select" required>
                        <option value="">--Select--</option>
                        <option value="Cash On Delivery">Cash On Delivery</option>
                    </select>
                    <div class="row" style="border-top: 1px solid rgba(0,0,0,.1); padding: 2vh 0;">
                        <div class="col">TOTAL PRICE</div>
                        <div class="col text-right"><?php echo $price * $_SESSION['quantity']; ?> Rs.</div>
                    </div>
                    <button type="submit" class="btn" name="checkout">CHECKOUT</button>
                </form>
                <!-- Form Ends Here -->
            </div>
        </div>
    </div>
</body>

</html>