<?php
// session starts here---u
session_start();
include("../Config/config.php");
$email = $_POST['email'];
$password = $_POST['password'];
// select query for fetching admin detail----
$query = "select email,password from tbl_admin where email = '$email' and password = '$password' ";
$res = mysqli_query($conn, $query);
if ($row = mysqli_fetch_array($res, MYSQLI_BOTH)) {
    $_SESSION['admin'] = $email; //creating session of admin's email-----
    echo "0";
} else {
    echo "1";
}
