<?php
// session starts here----
session_start();
$user_id = $_REQUEST['user_id'];
include("../Config/config.php"); //database connectivity---
$query = "DELETE FROM `tbl_user` WHERE `tbl_user`.`user_id` = $user_id"; //delete query----
mysqli_query($conn, $query);
echo "<script>alert('User Deleted Successfully.!!');window.location.href='../View/AdminViewUser.php';</script>";
