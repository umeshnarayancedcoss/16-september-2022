<?php
// session starts here------
session_start();
$email = $_SESSION['admin'];
include("../Config/config.php"); //Database Connectivity---
if (isset($_POST)) {
    // Holding Form Input Values in Variables--------
    $pro_name = $_POST['pro_name'];
    $category = $_POST['category'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $title = $_POST['title'];
    $filename = $_FILES['file']['name'];
    $filetype = $_FILES['file']['type'];
    $file_tmp_name = $_FILES['file']['tmp_name'];
    $filesize = $_FILES['file']['size'];
    $file_ext = strtolower(end(explode('.', $_FILES['file']['name'])));
    $uploaddir = "../images/";
    $uploadfile = $uploaddir . basename($_FILES['file']['name']);
    // Insertion query for inserting product into tbl_product--------------
    $query = "INSERT INTO `tbl_product` (`pro_name`, `category`, `quantity`, `price`, `title`, `image`, `status`) VALUES ( '$pro_name', '$category', '$quantity', '$price', '$title', '$filename', 'Hide')";
    mysqli_query($conn, $query); //executing query---
    move_uploaded_file($file_tmp_name, "../images/" . $filename); //image moved into folder----
    echo "<script>
    alert('Product Uploaded Successfully.!!');
    window.location.href = '../View/AddProduct.php';
     </script>";
}
