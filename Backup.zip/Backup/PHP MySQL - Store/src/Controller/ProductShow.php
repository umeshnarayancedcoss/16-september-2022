<?php
// session starts here----
session_start();
include("../Config/config.php"); //database connectivity----
$pro_id = $_REQUEST['pro_id'];
// changing status from 'Show' to 'Hide'----------
$query = "UPDATE `tbl_product` SET `status` = 'Hide' WHERE `tbl_product`.`pro_id` = $pro_id;";
mysqli_query($conn, $query); //executing query---
echo "<script>alert('Product Status Updated Successfully.!!');window.location.href='../View/AdminViewProduct.php';</script>";
