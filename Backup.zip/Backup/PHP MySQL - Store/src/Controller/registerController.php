<?php
include("../Config/config.php"); //database connectivity-----
if (isset($_POST)) {
    // ---Holding form input values into variables----
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $city = $_POST['city'];
    $address = $_POST['address'];
    $pincode = $_POST['pincode'];
    $password = $_POST['password'];
    // Insertion query for register a user---
    $query = "INSERT INTO `tbl_user`(`username`, `email`, `mobile`, `city`, `address`, `pincode`, `password`, `status`) VALUES ('$name','$email','$mobile','$city','$address','$pincode','$password','Requested')";
    mysqli_query($conn, $query); //executing query---
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
</body>
<script>
    // Alert after successful registration and redirected to Login Page----
    alert('Registered Successfully.!! \n You can login after verification.');
    window.location.href = '../View/Login.php';
</script>

</html>