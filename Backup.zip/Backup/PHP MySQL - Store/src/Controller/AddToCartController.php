<?php
// Session starts here-----
session_start();
$email = $_SESSION['user'];
include("../Config/config.php"); //Database Connectivity----
$pro_id = $_REQUEST['pro_id']; //Holding product id--
$flag = 0; //temporary variable for insertion---
// ----------query for product details-----------
$query = "SELECT * FROM tbl_product where pro_id=$pro_id";
$result = mysqli_query($conn, $query); //executing query-----
while ($row = mysqli_fetch_assoc($result)) {
    // Holding product details into variables------------
    $pro_name = $row['pro_name'];
    $category = $row['category'];
    $image = $row['image'];
    $title = $row['title'];
    $quantity = $row['quantity'];
    $price = $row['price'];
}
$query1 = "SELECT * FROM tbl_user where email = '$email'"; //select query for fetch user detail----
$result1 = mysqli_query($conn, $query1);
if (mysqli_num_rows($result1) > 0) {
    while ($row1 = mysqli_fetch_assoc($result1)) {
        // holding user id and name in variables----
        $user_id =  $row1["user_id"];
        $user_name =  $row1["username"];
    }
}
// ---------select query for fetch cart detail----
$query4 = "SELECT * FROM tbl_cart where user_id = '$user_id'";
$result4 = mysqli_query($conn, $query4);
if (mysqli_num_rows($result4) == 0) { //if cart is empty--
    $query3 = "INSERT INTO `tbl_cart`(`product_id`, `user_id`, `quantity`,`price`,`product_name`,`category`,`image`) VALUES ('$pro_id','$user_id','1','$price','$pro_name','$category','$image')";
    mysqli_query($conn, $query3);
    echo "<script> alert('Added to Cart Successfully.!!'); window.location.href='../View/MyCart.php'; </script>";
} else if (mysqli_num_rows($result4) > 0) { //if same product already exists in cart--
    while ($row4 = mysqli_fetch_assoc($result4)) {
        $product_id =  $row4["product_id"];
        if ($pro_id == $product_id) {
            $pro_quantity = $row4['quantity'] + 1; //quantity increase by 1----
            $flag = 1;
            // ------Quantity Update Query------
            $query5 = "UPDATE `tbl_cart` SET `quantity` = '$pro_quantity' WHERE `tbl_cart`.`product_id` = $product_id;";
            mysqli_query($conn, $query5);
            echo "<script> alert('Added to Cart Successfully.!!'); window.location.href='../View/MyCart.php'; </script>";
        }
    }
    if ($flag == 0) { //new product insertion in cart table----
        $query6 = "INSERT INTO `tbl_cart`(`product_id`, `user_id`, `quantity`,`price`,`product_name`,`category`,`image`) VALUES ('$pro_id','$user_id','1','$price','$pro_name','$category','$image')";
        mysqli_query($conn, $query6);
        echo "<script> alert('Added to Cart Successfully.!!'); window.location.href='../View/MyCart.php'; </script>";
    }
}
