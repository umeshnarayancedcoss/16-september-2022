<?php
// session starts here---
session_start();
$order_id = $_REQUEST['order_id']; //Holding Order Id
include("../Config/config.php"); //database connectivity---
$query = "DELETE FROM `tbl_order` WHERE `tbl_order`.`order_id` = $order_id"; //Delete Query---
mysqli_query($conn, $query); //Executing Query---
echo "<script>alert('Order Cancelled Successfully.!!');window.location.href='../View/MyOrder.php';</script>";
