<?php
// session starts here-----
session_start();
$pro_id = $_REQUEST['pro_id'];
include("../Config/config.php"); //database connectivity---
if (isset($_POST)) {
    // Holding Updated values into Variables----
    $pro_name = $_POST['pro_name'];
    $category = $_POST['category'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $title = $_POST['title'];
    // Update query for update product details----
    $query = "UPDATE `tbl_product` SET `pro_name` = '$pro_name', `category` = '$category',`quantity`='$quantity', `price` = '$price', `title` = '$title' WHERE `tbl_product`.`pro_id` = $pro_id";
    mysqli_query($conn, $query); //executing query---
    echo "<script>alert('Product Updated Successfully.!!');window.location.href='../View/AdminViewProduct.php';</script>";
}
