-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql-server
-- Generation Time: Nov 17, 2022 at 10:51 AM
-- Server version: 8.0.19
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `email`, `password`, `status`) VALUES
(1, 'admin@gmail.com', 'admin', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cart_id` int NOT NULL,
  `product_id` int NOT NULL,
  `user_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` varchar(20) NOT NULL,
  `product_name` varchar(30) NOT NULL,
  `category` varchar(20) NOT NULL,
  `image` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cart_id`, `product_id`, `user_id`, `quantity`, `price`, `product_name`, `category`, `image`) VALUES
(36, 10, 1, 5, '399', 'Yellow Linen Slim Shirt', 'Clothes', '1637660765.MN0058.jpg'),
(37, 9, 1, 6, '599', 'Softball Cricket Bat', 'Sports', '32651-1-cricket-bat.png'),
(39, 8, 1, 1, '799', 'Electric Dry Iron', 'Electronics', 'press.jpeg'),
(40, 14, 1, 3, '699', 'Mens Watch', 'Electronics', '71UXbfMHImS._UY445_.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int NOT NULL,
  `user_id` int NOT NULL,
  `pro_id` int NOT NULL,
  `pro_name` varchar(30) NOT NULL,
  `pro_category` varchar(30) NOT NULL,
  `pro_image` varchar(60) NOT NULL,
  `quantity` varchar(10) NOT NULL,
  `price` varchar(30) NOT NULL,
  `payment_mode` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `user_id`, `pro_id`, `pro_name`, `pro_category`, `pro_image`, `quantity`, `price`, `payment_mode`, `date`, `status`) VALUES
(12, 3, 7, 'T- Shirt', 'Clothes', 'download (1).jpeg', '20', '598', 'Cash On Delivery', '2022-11-16', 'Approved'),
(13, 3, 9, 'Softball Cricket Bat', 'Sports', '32651-1-cricket-bat.png', '12', '1198', 'Cash On Delivery', '2022-11-16', 'Approved'),
(14, 3, 8, 'Electric Dry Iron', 'Electronics', 'press.jpeg', '10', '799', 'Cash On Delivery', '2022-11-16', 'Pending'),
(23, 1, 9, 'Softball Cricket Bat', 'Sports', '32651-1-cricket-bat.png', '1', '599', 'Cash On Delivery', '2022-11-17', 'Pending'),
(24, 1, 10, 'Yellow Linen Slim Shirt', 'Clothes', '1637660765.MN0058.jpg', '2', '399', 'Cash On Delivery', '2022-11-17', 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `pro_id` int NOT NULL,
  `pro_name` varchar(30) NOT NULL,
  `category` varchar(20) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `price` varchar(15) NOT NULL,
  `title` varchar(60) NOT NULL,
  `image` varchar(60) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`pro_id`, `pro_name`, `category`, `quantity`, `price`, `title`, `image`, `status`) VALUES
(7, 'T- Shirt', 'Clothes', '20', '299', 'Printed Graphic Half Sleeve TShirt', 'download (1).jpeg', 'Show'),
(8, 'Electric Dry Iron', 'Electronics', '10', '799', 'We sing electric flame', 'press.jpeg', 'Show'),
(9, 'Softball Cricket Bat', 'Sports', '12', '599', 'The bat is not a toy, it\'s a weapon', '32651-1-cricket-bat.png', 'Show'),
(10, 'Yellow Linen Slim Shirt', 'Clothes', '20', '399', 'Dressed to chill.', '1637660765.MN0058.jpg', 'Show'),
(13, 'Mens Shoes', 'Footwear', '20', '399', 'Comfort Matters', 'shoes.jpg', 'Show'),
(14, 'Mens Watch', 'Electronics', '25', '699', 'Black Color', '71UXbfMHImS._UY445_.jpg', 'Show');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `city` varchar(30) NOT NULL,
  `address` varchar(60) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `username`, `email`, `mobile`, `city`, `address`, `pincode`, `password`, `status`) VALUES
(1, 'Umesh Narayan', 'srivastavau215@gmail.com', '9140843718', 'Lucknow', '121/K Purania Lucknow', '226001', '1234', 'Approved'),
(3, 'Ankit Verma', 'ankit@gmail.com', '9658745632', 'Lakhimpur Kheri', 'Rajapur Lakhimpur Kheri', '262701', '1234', 'Approved'),
(5, 'Adarsh Singh', 'adarsh@gmail.com', '9652365897', 'Lakhimpur Kheri', '121/K Alambag Lucknow', '223652', '1234', 'Requested'),
(7, 'Ram Kumar', 'ram@gmail.com', '8956321456', 'Kanpur', 'Civil Lines Kanpur', '252365', '1234', 'Requested'),
(8, 'Abhishek Singh', 'abhishek@gmail.com', '9658745698', 'Lucknow', '60 feet lucknow', '236541', '1234', 'Requested'),
(9, 'Aniket Shukla', 'aniket@gmail.com', '9856987456', 'Lucknow', 'Sector-J Jankipuram Lucknow', '236523', '1234', 'Requested');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cart_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `pro_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
