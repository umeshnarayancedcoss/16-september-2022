<?php
$servername = "mysql-server";
$username = "root";
$password = "secret";
$database = "store";
// Create connection
$conn = new mysqli($servername, $username, $password, $database); //Connectivity Function--