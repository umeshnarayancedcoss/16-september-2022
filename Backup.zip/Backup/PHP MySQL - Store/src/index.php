<?php
// session starts here----
session_start();
$_SESSION['quantity'] = 1; //initilizing product quantity with session-----
@$email = isset($_SESSION['user']) ? $_SESSION['user'] : "notlogged";
include("./Config/config.php"); //database connectivity----
// ----NavBar Condition--------
if ($_SESSION['user'] == "") {
    include("./View/menu.php");
} else {
    include("./View/UserMenu.php");
}
?>
<!-- --HTML Code starts here---- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <title>Index</title>
    <style>
        body {
            overflow-x: hidden;
        }
    </style>
</head>

<body>
    <!-- ---Showing Products in a row on home page---- -->
    <div class="container" style="margin-top:160px;">
        <div class="col-sm-12">
            <div class="row">
                <?php
                // Select query for fetching poducts from product table---------
                $query = "SELECT * FROM tbl_product where status='Show' order by pro_id desc";
                $result = mysqli_query($conn, $query);
                $a = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    $pro_id = $row['pro_id'];
                ?>
                    <div class="col-3" style="margin-top:20px;">
                        <div class="card">
                            <center> <img src="./images/<?php echo $row['image'] ?>" class="card-img-top" style="height:220px;width:200px;"></center>
                            <div class="card-body">
                                <a href="./View/ViewProduct.php?pro_id=<?php echo $row['pro_id']; ?>">
                                    <h5 class="card-title"><?php echo $row['pro_name'] ?></h5>
                                </a>
                                <!-- ---Add to Cart Button -->
                                <a href="javascript:addcart('<?php echo $email; ?>',<?php echo $row['pro_id'] ?>);" id="addcart" class="btn btn-info">Add To Cart</a>
                                <!-- ----Buy Now Button----- -->
                                <a href="javascript:buynow('<?php echo $email; ?>',<?php echo $row['pro_id'] ?>);" id="buynow" class="btn btn-success">BuyNow</a>
                            </div>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</body>
<script>
    // -------Add To Cart Script------------
    function addcart(emailstatus, pro_id) {
        var cart = document.getElementById("addcart");
        if (emailstatus == "notlogged") {
            var r = confirm("Cant Add.\n Are You Want to login.??");
            if (r == true) {
                window.location.href = './View/Login.php?page=AddToCartController.php&pro_id=' + pro_id;
            }
        } else {
            window.location.href = './Controller/AddToCartController.php?pro_id=' + pro_id;
        }
    }
    // ----------Buy Now Script------------
    function buynow(emailstatus, pro_id) {
        var buy = document.getElementById("buynow");
        if (emailstatus == "notlogged") {
            var r = confirm("Cant Buy.\n Are You Want to login.??");
            if (r == true) {
                window.location.href = './View/Login.php?page=BuyNowController.php&pro_id=' + pro_id;
            }
        } else {
            window.location.href = './Controller/BuyNowController.php?pro_id=' + pro_id;
        }
    }
</script>

</html>