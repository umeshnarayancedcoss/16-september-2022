$(document).ready(function () { //jQuery Starts Here---
    // -------Admin Login---------------
    $("#admin_login").click(function () {
        var email = $("#email").val();
        var password = $("#password").val();
        $.ajax({
            url: "../Controller/adminLoginController.php",
            method: "POST",
            data: {
                email: email,
                password: password,
            },
            success: function (data) {
                if (data == 0) {
                    window.location.href = "../View/AdminDashboard.php";
                }
                if (data == 1) {
                    $('#error_msg').html("Error: Wrong Email ID or Password or Verification Under Process.!!");
                    $('#error_msg').css('color', 'red');
                }
            }
        });
    });
    // ------------Increase Quantity-----------
    $(document).on("click", ".increment", function () {
        var cart_id = $(this).attr("id");
        $.ajax({
            url: "../Controller/cart_qty.php?op=inc",
            method: "POST",
            data: {
                cart_id: cart_id,
            },
            success: function (data) {
                window.location.href = "../View/MyCart.php";
            }
        });
    });
    // ----------------Decrease Quanity-------------------
    $(document).on("click", ".decrement", function () {
        var cart_id = $(this).attr("id");
        $.ajax({
            url: "../Controller/cart_qty.php?op=dec",
            method: "POST",
            data: {
                cart_id: cart_id,
            },
            success: function (data) {
                window.location.href = "../View/MyCart.php";
            }
        });
    });
    // -------------Delete Product From Cart------------------
    $(document).on("click", ".close", function () {
        var cart_id = $(this).attr("id");
        $.ajax({
            url: "../Controller/RemoveCartProduct.php",
            method: "POST",
            data: {
                cart_id: cart_id,
            },
            success: function (data) {
                window.location.href = "../View/MyCart.php";
            }
        });
    });
}); //-----jQuery Ends Here-----