<?php
// session starts here-----
session_start();
$email = $_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../admin/index.php");
}
include("./AdminMenu.php"); //including AdminMenu----
?>
<!-- ----HTML Code Starts Here-- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="../css/product.css">
    <title>Add Products</title>
</head>

<body>
    <section class="h-100 bg-dark">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col">
                    <div class="card card-registration my-4">
                        <div class="row g-0">
                            <div class="col-xl-6 d-none d-xl-block">
                                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img4.webp" alt="Sample photo" class="img-fluid" style="border-top-left-radius: .25rem; border-bottom-left-radius: .25rem;" />
                            </div>
                            <div class="col-xl-6">
                                <!-- Form Stsrts Here--- -->
                                <form action="../Controller/addProductController.php" method="post" enctype="multipart/form-data">
                                    <div class="card-body p-md-5 text-black">
                                        <h3 class="mb-5 text-uppercase">Product registration form</h3>
                                        <div class="row">
                                            <div class="col-md-6 mb-4">
                                                <div class="form-outline">
                                                    <label class="form-label" for="form3Example1m">Product Name</label>
                                                    <input type="text" id="form3Example1m" name="pro_name" class="form-control form-control-md" required />
                                                </div>
                                            </div>
                                            <div class="col-md-6 mb-4">
                                                <div class="form-outline">
                                                    <label class="form-label" for="form3Example1n">Category</label>
                                                    <select name="category" id="category" class="form-control form-control-md" required>
                                                        <option value="">--Select a Category--</option>
                                                        <option value="Electronics">Electronics</option>
                                                        <option value="Clothes">Clothes</option>
                                                        <option value="Groceries">Groceries</option>
                                                        <option value="Jewellery">Jewellery</option>
                                                        <option value="Footwear">Footwear</option>
                                                        <option value="Sports">Sports</option>
                                                        <option value="Other">Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 mb-4">
                                                <div class="form-outline">
                                                    <label class="form-label" for="form3Example1m1">Quantity</label>
                                                    <input type="number" id="form3Example1m1" class="form-control form-control-md" min="1" name="quantity" required />
                                                </div>
                                            </div>
                                            <div class="col-md-6 mb-4">
                                                <div class="form-outline">
                                                    <label class="form-label" for="form3Example1n1">Price</label>
                                                    <input type="number" id="form3Example1n1" class="form-control form-control-md" min="1" name="price" required />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-outline mb-4">
                                            <label class="form-label" for="form3Example8">Title</label>
                                            <input type="text" id="form3Example8" class="form-control form-control-md" name="title" required />
                                        </div>
                                        <div class="form-outline mb-4">
                                            <label class="form-label" for="form3Example97">Image</label>
                                            <input type="file" id="form3Example97" class="form-control form-control-md" name="file" required />
                                        </div>
                                        <div class="d-flex justify-content-end pt-3">
                                            <input type="submit" value="Add" id="product_add" class="btn btn-warning btn-lg ms-2">
                                        </div>
                                    </div>
                            </div>
                            </form>
                            <!-- Form Ends Here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>