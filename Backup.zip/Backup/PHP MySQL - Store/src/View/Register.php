<?php
include("./menu.php"); //NavBar Linking--
?>
<!-- HTML Code starts here--- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="../css/style.css" rel="stylesheet">
    <title>Register Here.!!</title>
</head>

<body>
    <div class="wrapper" style="margin-top: 58px;">
        <div class="form">
            <h1 class="title">Create an account</h1>
            <!--Registration  Form starts here -->
            <form action="../Controller/registerController.php" method="POST" class="myform">
                <div class="control-from">
                    Name *
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="control-from">
                    Email Address *
                    <input type="text" id="emailaddress" name="email" required>
                </div>
                <div class="control-from">
                    Phone Number *
                    <input type="number" id="mobile" name="mobile" required>
                </div>
                <div class="control-from">
                    City *
                    <input type="text" id="city" name="city" required>
                </div>
                <div class="control-from">
                    Address *
                    <input type="text" id="address" name="address" required>
                </div>
                <div class="control-from">
                    Pincode *
                    <input type="number" id="pincode" name="pincode" required>
                </div>
                <div class="control-from">
                    Password *
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="button">
                    <button id="register">Register</button>
                </div>
            </form>
            <!-- Form Ends Here -->
        </div>
    </div>
</body>

</html>