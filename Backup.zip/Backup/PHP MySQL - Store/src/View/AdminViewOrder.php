<?php
// session starts here------
session_start();
$email = $_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../admin/index.php");
}
include("../Config/config.php"); //database connectivity --
include("AdminMenu.php"); // Navbar Linking---------
?>
<!-- ------HTML Code Starts Here---------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>All Orders</title>
    <style>
        /* ---------CSS For Table Tag------ */
        table,
        th,
        td {
            border: 1px solid black;
            text-align: center;
        }

        .table_show {
            font-family: rockwell;
            width: 100%;
            margin: 0px auto;
            cursor: not-allowed;
        }

        tr:hover {
            background-color: aqua;
        }
    </style>
</head>

<body>
    <!-- -----------Showing data in table starts here------- -->
    <?php
    $query4 = "SELECT * FROM tbl_order";
    $result4 = mysqli_query($conn, $query4);
    $items = mysqli_num_rows($result4); //counting total number of rows-- 
    ?>
    <?php
    if ($items < 1) {
        echo "<center><h2 style='margin-top:200px;'>No Items Found.!!($items)</h2></center>";
    } else {
    ?>
        <div class="showtables" style="margin-top:60px;">
            <center>
                <!-- data in table showing here------ -->
                <table class="table_show">
                    <tr>
                        <th>S. No.</th>
                        <th>Order ID</th>
                        <th>User ID</th>
                        <th>Product ID</th>
                        <th>ProductName</th>
                        <th>Image</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>PaymentMode</th>
                        <th>Ordered Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    <?php
                    // Fetching orders from tbl_order-------
                    $query1 = "SELECT * FROM tbl_order order by order_id desc";
                    $result1 = mysqli_query($conn, $query1); //executing query-------
                    $a = 1;
                    while ($row1 = mysqli_fetch_assoc($result1)) {
                        $status = $row1['status'];
                    ?>
                        <tr>
                            <td><?php echo $a++; ?></td>
                            <td><?php echo $row1['order_id'] ?></td>
                            <td><?php echo $row1['user_id'] ?></td>
                            <td><?php echo $row1['pro_id'] ?></td>
                            <td><?php echo $row1['pro_name'] ?></td>
                            <td><img src="../images/<?php echo $row1['pro_image'] ?>" style="height:100px;width:100px;"></td>
                            <td><?php echo $row1['quantity'] ?></td>
                            <td><?php echo $row1['price'] ?></td>
                            <td><?php echo $row1['payment_mode'] ?></td>
                            <td><?php echo $row1['date'] ?></td>
                            <?php
                            if ($status == "Pending") {
                            ?>
                                <td><a href="../Controller/PendingOrder.php?order_id=<?php echo $row1['order_id']; ?>"><button style="background-color:blueviolet;color:white;border-radius:5px;border:none;"><?php echo $status; ?></button></a></td>
                            <?php
                            }
                            if ($status == "Approved") {
                            ?>
                                <td><a href="../Controller/ApprovedOrder.php?order_id=<?php echo $row1['order_id']; ?>"><button style="background-color:yellow;color:black;border-radius:5px;border:none;"><?php echo $status; ?></button></a></td>
                            <?php
                            }
                            if ($status == "Delivered") {
                            ?>
                                <td><button style="background-color:green;color:white;border-radius:5px;border:none;"><?php echo $status; ?></button></td>
                            <?php
                            }
                            ?>
                            <td><a href="../Controller/AdminDeleteOrder.php?order_id=<?php echo $row1['order_id'] ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Delete</button></a></td>
                        <?php
                    }
                        ?>
                        </tr>
                        <?php
                        $a++;
                        ?>
                        <tr></tr>
                </table>
        </div>
    <?php
    }
    ?>
    </center>
</body>

</html>