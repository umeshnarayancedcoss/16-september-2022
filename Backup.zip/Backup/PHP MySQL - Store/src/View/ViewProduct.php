<?php
// session starts here----
session_start();
include("../Config/config.php"); //database connectivity----
$pro_id = $_REQUEST['pro_id'];
@$email = isset($_SESSION['user']) ? $_SESSION['user'] : "notlogged";
// NavBar Condition---
if (isset($_SESSION['user'])) {
    include("../View/UserMenu.php");
} else {
    include("../View/menu.php");
}
// Select query for fetching product detail----
$query = "SELECT * FROM tbl_product where pro_id=$pro_id";
$result = mysqli_query($conn, $query); //executing query-----
while ($row = mysqli_fetch_assoc($result)) {
    // Holding product details into variables------------
    $pro_name = $row['pro_name'];
    $category = $row['category'];
    $image = $row['image'];
    $title = $row['title'];
    $quantity = $row['quantity'];
    $price = $row['price'];
}
?>
<!-- HTML Code starts Here -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>View Product</title>
    <style>
        body {
            overflow: hidden;
        }
    </style>
</head>

<body>
    <section style="background-color: #eee; margin-top :50px;">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-4">
                    <div class="card text-black">
                        <i class="fab fa-apple fa-lg pt-3 pb-1 px-3"></i>
                        <img src="../images/<?php echo $image; ?>" class="card-img-top" style="height:250px;width:100%;" />
                        <div class="card-body">
                            <div class="text-center">
                                <h5 class="card-title"><?php echo $pro_name; ?></h5>
                                <p class="text-muted mb-4"><?php echo $title; ?></p>
                            </div>
                            <div>
                                <div class="d-flex justify-content-between">
                                    <span>Price</span><span><?php echo $price; ?> Rs./-</span>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span>Quantity(In Stock)</span><span><?php echo $quantity; ?></span>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between total font-weight-bold mt-4">
                                <!-- --Add To Cart Button--- -->
                                <a href="javascript:addcart('<?php echo $email; ?>',<?php echo $pro_id; ?>);" id="addcart" class="btn btn-info">Add To Cart</a>
                                <a href="../index.php" class="btn btn-primary">Back</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
<script>
    // ----------Add To Cart--------------
    function addcart(emailstatus, pro_id) {
        var cart = document.getElementById("addcart");
        if (emailstatus == "notlogged") {
            var r = confirm("Cant Add.\n Are You Want to login.??");
            if (r == true) {
                window.location.href = './Login.php?page=AddToCartController.php&pro_id=' + pro_id;
            }
        } else {
            window.location.href = '../Controller/AddToCartController.php?pro_id=' + pro_id;
        }
    }
</script>

</html>