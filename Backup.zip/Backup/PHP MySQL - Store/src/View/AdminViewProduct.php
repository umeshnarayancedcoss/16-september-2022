<?php
// session starts here---
session_start();
$email = $_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../admin/index.php");
}
include("../Config/config.php"); //database connectivity----
?>
<!-- ---HTML Code starts here--- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Linking Bootstrap CDN -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="../css/MyCart.css" rel="stylesheet">
    <title>View Products</title>
</head>

<body>
    <div class="card" style="margin-top:50px">
        <div class="row">
            <div class="col-md-12 cart">
                <div class="title">
                    <div class="row">
                        <div class="col">
                            <h4><b>Product</b></h4>
                        </div>
                        <?php
                        // select query for fetching total number of products from product table---
                        $query1 = "SELECT * FROM tbl_product";
                        $result1 = mysqli_query($conn, $query1); //executing query----
                        $items = mysqli_num_rows($result1);
                        ?>
                        <div class="col align-self-center text-right text-muted"><?php echo $items; ?> items </div>
                    </div>
                </div>
                <div class="row border-top border-bottom">
                    <?php
                    // Select query for fetching poducts from product table---------
                    $query = "SELECT * FROM tbl_product order by pro_id desc";
                    $result = mysqli_query($conn, $query);
                    $a = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $pro_id = $row['pro_id'];
                        $status = $row['status'];
                    ?>
                        <div class="row main align-items-center">
                            <div class="col-2"><img class="img-fluid" src="../images/<?php echo $row['image']; ?>"></div>
                            <div class="col">
                                <div class="row text-muted"><?php echo $row['category']; ?></div>
                                <div class="row"><?php echo $row['pro_name']; ?></div>
                            </div>
                            <div class="row">
                                <span class="border"><?php echo $row['category']; ?></span> <span class="border" style="margin-left:50px;"><?php echo $row['quantity']; ?> Items(In Stock)</span>
                            </div>
                            <div class="row" style="margin-left:50px;"> <?php echo $row['price']; ?> Rs. <a class="close" href="../Controller/DeleteProduct.php?pro_id=<?php echo $pro_id; ?>" style="margin-left:20px;">&#10005;</a>
                            </div>
                            <div class="row" style="margin-left:10px;">
                                <a href="../View/UpdateProduct.php?pro_id=<?php echo $pro_id; ?>"><img src="../images/pencil.png" style="height: 15px;width:15px;"></a>
                                <?php
                                if ($status == "Hide") {
                                ?>
                                    <a href="../Controller/ProductHide.php?pro_id=<?php echo $pro_id; ?>" style="margin-left:10px ;"> <button style="background-color:red;color:white;border-radius:5px;border:none;"><?php echo $row['status']; ?></button></a>
                                <?php
                                } else {
                                ?>
                                    <a href="../Controller/ProductShow.php?pro_id=<?php echo $pro_id; ?>" style="margin-left:10px ;"> <button style="background-color:green;color:white;border-radius:5px;border:none;"><?php echo $row['status']; ?></button></a>
                                <?php
                                }
                                ?>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
                <div class="back-to-shop"><a href="./AdminDashboard.php">&leftarrow;</a><span class="text-muted">Back to Dashboard</span></div>
            </div>
        </div>
    </div>
</body>

</html>