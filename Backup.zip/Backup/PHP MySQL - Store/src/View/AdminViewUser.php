<?php
// session starts here----
session_start();
$email = $_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../admin/index.php");
}
include("../Config/config.php"); //database connectivity-----
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="../css/MyCart.css" rel="stylesheet">
    <title>View Products</title>
</head>

<body>
    <div class="card" style="margin-top:50px">
        <div class="row">
            <div class="col-md-12 cart">
                <div class="title">
                    <div class="row">
                        <div class="col">
                            <h4><b>User</b></h4>
                        </div>
                        <?php
                        // select query for fetching user----
                        $query1 = "SELECT * FROM tbl_user";
                        $result1 = mysqli_query($conn, $query1);
                        $items = mysqli_num_rows($result1); //holding total rows in table---
                        ?>
                        <div class="col align-self-center text-right text-muted"><?php echo $items; ?> Users </div>
                    </div>
                </div>
                <div class="row border-top border-bottom">
                    <?php
                    // Select query for fetching user detail from user table---------
                    $query = "SELECT * FROM tbl_user order by user_id desc";
                    $result = mysqli_query($conn, $query);
                    $a = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $user_id = $row['user_id'];
                        $status = $row['status'];
                    ?>
                        <div class="row main align-items-center">
                            <div class="col-2">User ID- <?php echo $user_id; ?></div>
                            <div class="col">
                                <div class="row text-muted"><?php echo $row['username']; ?></div>
                                <div class="row"><?php echo $row['email']; ?></div>
                            </div>
                            <div class="col">
                                <span class="border"><?php echo $row['mobile']; ?></span> <span class="border" style="margin-left:20px;"><?php echo $row['city']; ?></span>
                            </div>
                            <div class="row" style="margin-left:0px;"> <?php echo $row['pincode']; ?>
                                <span class="border" style="margin-left:20px;">Password- <?php echo $row['password']; ?></span>
                            </div>
                            <div class="row" style="margin-left:0px;">
                                <a class="close" href="../Controller/DeleteUser.php?user_id=<?php echo $user_id; ?>" style="margin-left:20px;">&#10005;</a>
                            </div>
                            <div class="row" style="margin-left:10px;">
                                <?php
                                if ($status == "Requested") {
                                ?>
                                    <a href="../Controller/UserApproved.php?user_id=<?php echo $user_id; ?>" style="margin-left:10px ;"> <button style="background-color:red;color:white;border-radius:5px;border:none;"><?php echo $row['status']; ?></button></a>
                                <?php
                                } else {
                                ?>
                                    <a href="../Controller/UserRequested.php?user_id=<?php echo $user_id; ?>" style="margin-left:10px ;"> <button style="background-color:green;color:white;border-radius:5px;border:none;"><?php echo $row['status']; ?></button></a>
                                <?php
                                }
                                ?>
                            </div>

                        </div>
                    <?php
                    }
                    ?>
                </div>
                <div class="back-to-shop"><a href="./AdminDashboard.php">&leftarrow;</a><span class="text-muted">Back to Dashboard</span></div>
            </div>
        </div>
    </div>
</body>

</html>