<?php
// session starts here----
session_start();
$email = $_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../admin/index.php");
}
include("../Config/config.php"); //database connectivity---
include("../View/AdminMenu.php"); //including Admin NavBar----
?>
<!-- HTML Code Starts Here-- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Admin Dashboard</title>
    <style>
        table,
        th,
        td {
            border: 1px solid black;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="col-sm-12" style="display: flex;margin-top:150px;">
            <!-- ----------------------------User Details---------- -->
            <div class="col-sm-4" style="min-height:300px;border-radius:10%;">
                <center>
                    <h3>Recent Users</h3>
                    <table>
                        <tr>
                            <th>UserID</th>
                            <th>UserName</th>
                            <th>Status</th>
                        </tr>
                        <tr>
                            <?php
                            // Select query for fetching user detail from user table---------
                            $query = "SELECT * FROM tbl_user order by user_id desc LIMIT 5";
                            $result = mysqli_query($conn, $query);
                            $a = 1;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $user_id = $row['user_id'];
                                $status = $row['status'];
                            ?>
                                <td><?php echo $row['user_id'];  ?></td>
                                <td><?php echo $row['username'];  ?></td>
                                <td><?php echo $row['status'];  ?></td>
                        </tr>
                    <?php
                            }
                    ?>
                    </table>
                    <br>
                    <a href="../View/AdminViewUser.php"><button style="background-color:green;color:white;border-radius:5px;border:none;">Show More</button></a>
                </center>
            </div>
            <div class="col-sm-4" style="min-height:300px;border-radius:10%;">
                <!-- ---------Product Detail------------ -->
                <center>
                    <h3>Recent Products</h3>
                    <table>
                        <tr>
                            <th>ProductID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Status</th>
                        </tr>
                        <tr>
                            <?php
                            // Select query for fetching product detail from product table---------
                            $query1 = "SELECT * FROM tbl_product order by pro_id desc LIMIT 5";
                            $result1 = mysqli_query($conn, $query1);
                            $a = 1;
                            while ($row1 = mysqli_fetch_assoc($result1)) {
                            ?>
                                <td><?php echo $row1['pro_id'];  ?></td>
                                <td><?php echo $row1['pro_name'];  ?></td>
                                <td><?php echo $row1['category'];  ?></td>
                                <td><?php echo $row1['status'];  ?></td>
                        </tr>
                    <?php
                            }
                    ?>
                    </table>
                    <br>
                    <a href="../View/AdminViewProduct.php"><button style="background-color:green;color:white;border-radius:5px;border:none;">Show More</button></a>
                </center>
            </div>
            <div class="col-sm-4" style="min-height:300px;border-radius:10%;">
                <!-- --------------------Order Details------------- -->
                <center>
                    <h3>Recent Orders</h3>
                    <table>
                        <tr>
                            <th>OrderID</th>
                            <th>UserID</th>
                            <th>ProductID</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                        <tr>
                            <?php
                            // Select query for fetching order detail from order table---------
                            $query2 = "SELECT * FROM tbl_order order by order_id desc LIMIT 5";
                            $result2 = mysqli_query($conn, $query2);
                            $a = 1;
                            while ($row2 = mysqli_fetch_assoc($result2)) {
                            ?>
                                <td><?php echo $row2['order_id'];  ?></td>
                                <td><?php echo $row2['user_id'];  ?></td>
                                <td><?php echo $row2['pro_id'];  ?></td>
                                <td><?php echo $row2['date'];  ?></td>
                                <td><?php echo $row2['status'];  ?></td>
                        </tr>
                    <?php
                            }
                    ?>
                    </table>
                    <br>
                    <a href="../View/AdminViewOrder.php"><button style="background-color:green;color:white;border-radius:5px;border:none;">Show More</button></a>
                </center>
            </div>
        </div>
    </div>
</body>

</html>