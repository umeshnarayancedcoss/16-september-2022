<?php
// session starts here---
session_start();
$email = $_SESSION['user'];
include("../Config/config.php"); //database connectivity---

if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:./Login.php");
}
// NavBar Condition---
if ($_SESSION['user'] == "") {
    include("../View/menu.php");
} else {
    include("../View/UserMenu.php");
}
$query1 = "SELECT * FROM tbl_user where email = '$email'"; //select query for fetch user detail----
$result1 = mysqli_query($conn, $query1);
if (mysqli_num_rows($result1) > 0) {
    while ($row1 = mysqli_fetch_assoc($result1)) {
        // holding user id and name in variables----
        $user_id =  $row1["user_id"];
        $user_name =  $row1["username"];
        $user_address = $row1["address"];
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="../css/MyCart.css" rel="stylesheet">
    <title>My Cart</title>
</head>

<body>
    <div class="card" style="margin-top:100px">
        <div class="row">
            <div class="col-md-8 cart">
                <div class="title">
                    <div class="row">
                        <div class="col">
                            <h4><b>Shopping Cart</b></h4>
                        </div>
                        <?php
                        // --select number of rows from cart table----
                        $query1 = "SELECT * FROM tbl_cart WHERE user_id='$user_id'";
                        $result1 = mysqli_query($conn, $query1); //exequting query---
                        $items = mysqli_num_rows($result1); //holding 
                        ?>
                        <div class="col align-self-center text-right text-muted"><?php echo $items; ?> items </div>
                    </div>
                </div>
                <div class="row border-top border-bottom">
                    <?php
                    // Select query for fetching cart detail from cart table---------
                    $query = "SELECT * FROM tbl_cart WHERE user_id='$user_id' order by cart_id desc";
                    $result = mysqli_query($conn, $query); //executing query---
                    $a = 1;
                    $total = 0;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $cart_id = $row['cart_id'];
                    ?>
                        <div class="row main align-items-center">
                            <div class="col-2"><img class="img-fluid" src="../images/<?php echo $row['image']; ?>"></div>
                            <div class="col">
                                <div class="row text-muted"><?php echo $row['category']; ?></div>
                                <div class="row"><?php echo $row['product_name']; ?></div>
                            </div>
                            <div class="col">
                                <a href="#" class="decrement" id="<?php echo $cart_id; ?>">-</a><span class="border"><?php echo $row['quantity']; ?></span><a href="#" class="increment" id="<?php echo $cart_id; ?>">+</a>
                            </div>
                            <div class="col"> <?php echo $row['price'] * $row['quantity']; ?> Rs. <a class="close" href="#" id="<?php echo $cart_id; ?>">&#10005;</a></div>
                        </div>
                    <?php
                        // Holding total cart amount----
                        $total = $total + ($row['price'] * $row['quantity']);
                    }
                    ?>
                </div>
                <div class="back-to-shop"><a href="../index.php">&leftarrow;</a><span class="text-muted">Back to shop</span></div>
            </div>
            <div class="col-md-4 summary">
                <div>
                    <h5><b>Summary</b></h5>
                </div>
                <hr>
                <div class="row">
                    <div class="col" style="padding-left:0;">Price</div>
                    <div class="col text-right"><?php echo $total; ?> Rs.</div>
                </div>
                <!-- ---Form Starts Here--- -->
                <form method="POST" action="../Controller/CartBuy.php">
                    <p>Name</p>
                    <input type="text" placeholder="Enter your name" name="name" value="<?php echo $user_name; ?>">
                    <p>Address</p>
                    <textarea name="address" cols="30" rows="2" style="resize:none;"><?php echo $user_address; ?></textarea>
                    <p>Mode Of Payment</p>
                    <select name="select" required>
                        <option value="">--Select--</option>
                        <option value="Cash On Delivery">Cash On Delivery</option>
                    </select>
                    <div class="row" style="border-top: 1px solid rgba(0,0,0,.1); padding: 2vh 0;">
                        <div class="col">TOTAL PRICE</div>
                        <div class="col text-right"><?php echo $total; ?> Rs.</div>
                    </div>
                    <button type="submit" class="btn" name="checkout">CHECKOUT</button>
                </form>
                <!-- Form Ends Here-- -->
            </div>
        </div>
    </div>
</body>
<!-- Linking Script File -->
<script src="../script/script.js"></script>

</html>