<?php
// session starts here------
session_start();
$email = $_SESSION['user'];
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:../View/Login.php");
}
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:./Login.php");
}
include("../Config/config.php"); //database connectivity --
// Navbar Linking Condition----------
if ($_SESSION['user'] == "") {
    include("./menu.php");
} else {
    include("./UserMenu.php");
}
$query = "SELECT * FROM tbl_user where email = '$email'"; //generating query for user detail----
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // storing user details into variables--------
        $user_id =  $row["user_id"];
        $user_name =  $row["username"];
    }
}
?>
<!-- ------HTML Code Starts Here---------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>My Orders</title>
    <style>
        /* ---------CSS For Table Tag------ */
        table,
        th,
        td {
            border: 1px solid black;
            text-align: center;
        }

        .table_show {
            font-family: rockwell;
            width: 100%;
            margin: 0px auto;
            cursor: not-allowed;
        }

        tr:nth-child(even) {
            background-color: pink;
        }

        tr:hover {
            background-color: aqua;
        }
    </style>
</head>

<body>
    <!-- -----------Showing data in table starts here------- -->
    <?php
    $query4 = "SELECT * FROM tbl_order WHERE user_id='$user_id'"; //fetching total number of orders--------
    $result4 = mysqli_query($conn, $query4); //executing query---
    $items = mysqli_num_rows($result4); //holding total rows--
    ?>
    <?php
    if ($items < 1) {
        echo "<center><h2 style='margin-top:200px;'>No Items Found.!!($items)</h2></center>";
    } else {
    ?>
        <div class="showtables" style="margin-top:60px;">
            <center>
                <table class="table_show">
                    <tr>
                        <th>S. No.</th>
                        <th>Order ID</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Image</th>
                        <th>PaymentMode</th>
                        <th>Ordered Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    <?php
                    // Fetching orders from tbl_order, ordered by specific user-------
                    $query1 = "SELECT * FROM tbl_order where user_id=$user_id order by order_id desc";
                    $result1 = mysqli_query($conn, $query1); //executing query-------
                    $a = 1;
                    while ($row1 = mysqli_fetch_assoc($result1)) {
                        $status = $row1['status'];
                    ?>
                        <tr>
                            <td><?php echo $a++; ?></td>
                            <td><?php echo $row1['order_id'] ?></td>
                            <td><?php echo $row1['pro_name'] ?></td>
                            <td><?php echo $row1['pro_category'] ?></td>
                            <td><img src="../images/<?php echo $row1['pro_image'] ?>" style="height:100px;width:100px;"></td>
                            <td><?php echo $row1['payment_mode'] ?></td>
                            <td><?php echo $row1['date'] ?></td>
                            <td><?php echo $status ?></td>
                            <td><a href="../Controller/cancelOrder.php?order_id=<?php echo $row1['order_id'] ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Cancel</button></a></td>
                        <?php
                    }
                        ?>
                        </tr>
                        <?php
                        $a++;
                        ?>
                        <tr></tr>
                </table>
        </div>
    <?php
    }
    ?>
    </center>
</body>

</html>