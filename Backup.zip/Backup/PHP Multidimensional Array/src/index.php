<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Php Multi Dimensional Array Task</title>
  <style>
    /* ------Table style CSS---- */
    table {
      border: 1px solid;
    }

    table th {
      border: 1px solid;
    }

    table td {
      border: 1px solid;
    }
  </style>
</head>
<?php
// -------------------1. Create Multidimensional array of the following table------------------------
echo "<h3>1. Create Multidimensional array of the following table</h3>";
// Array Initilization----------------
$data_array = array(
  array(
    array("Time" => "Q1", "Location" => "Kolkata", "Milk" => "340", "Egg" => "604", "Bread" => "38"),
    array("Time" => "Q1", "Location" => "Delhi", "Milk" => "335", "Egg" => "365", "Bread" => "35"),
    array("Time" => "Q1", "Location" => "Mumbai", "Milk" => "336", "Egg" => "484", "Bread" => "80")
  ),
  array(
    array("Time" => "Q2", "Location" => "Kolkata", "Milk" => "680", "Egg" => "583", "Bread" => "10"),
    array("Time" => "Q2", "Location" => "Delhi", "Milk" => "684", "Egg" => "490", "Bread" => "48"),
    array("Time" => "Q2", "Location" => "Mumbai", "Milk" => "595", "Egg" => "594", "Bread" => "39")
  ),
  array(
    array("Time" => "Q3", "Location" => "Kolkata", "Milk" => "535", "Egg" => "490", "Bread" => "50"),
    array("Time" => "Q3", "Location" => "Delhi", "Milk" => "389", "Egg" => "385", "Bread" => "15"),
    array("Time" => "Q3", "Location" => "Mumbai", "Milk" => "366", "Egg" => "385", "Bread" => "20")
  )
);
// Displaying data in table-------------------
$str = "<table style='border:1px solid green;'><tr><td rowspan=3> Time:</td><td colspan=3> Location =" . $data_array[0][0]["Location"] . "</td><td colspan=3> Location =" . $data_array[0][1]["Location"] . "</td><td colspan=3> Location =" . $data_array[0][2]["Location"] . "</td></tr>";
$str .= "<tr><td colspan=3> Item</td><td colspan=3> Item</td><td colspan=3> Item</td></tr>";
$str .= "<tr><td>Milk</td><td>Egg</td><td>Bread</td><td>Milk</td><td>Egg</td><td>Bread</td><td>Milk</td><td>Egg</td><td>Bread</td></tr>";
foreach ($data_array as $key => $value) {
  $str .= "<tr> <td>" . $value[0]["Time"] . "</td><td>" . $value[0]["Milk"] . "</td><td>" . $value[0]["Egg"] . "</td><td>" . $value[0]["Bread"] . "</td>
        <td>" . $value[1]["Milk"] . "</td><td>" . $value[1]["Egg"] . "</td><td>" . $value[1]["Bread"] . "</td>
        <td>" . $value[2]["Milk"] . "</td><td>" . $value[2]["Egg"] . "</td><td>" . $value[2]["Bread"] . "</td></tr>";
}
$str .= "</table>";
echo $str;
echo "<hr>";
// -------------2. Identify the Quarter with maximum sale of Egg---------------------------
echo "<h3>2. Identify the Quarter with maximum sale of Egg </h3>";
$max_egg = array(); //stroring array in a variable for maximum egg sale----
foreach ($data_array as $key => $value) {
  $sum = $value[0]["Egg"] + $value[1]["Egg"] + $value[2]["Egg"];
  array_push($max_egg, $sum); //pushing data into array-----------
}
$max = max($max_egg);
$indexes = array_search($max, $max_egg);
echo "Max sale of Egg in Quater" . $indexes;
echo "<hr>";
// -------------------3. Identify the Location with minimum consumption of Milk-----------------------------
echo "<h3>3. Identify the Location with minimum consumption of Milk</h3>";
$milk = array(0, 0, 0); //storing array into variable for minimum milk consumption-----
foreach ($data_array as $key => $value) {
  if ($value[0]['Location'] == "Kolkata") {
    $milk[0] += $value[0]['Milk'];
  }
  if ($value[1]['Location'] == "Delhi") {
    $milk[1] += $value[1]['Milk'];
  }
  if ($value[2]['Location'] == "Mumbai") {
    $milk[2] += $value[2]['Milk'];
  }
}
$min = min($milk);
$indexes = array_search($min, $milk);
if ($indexes == 0) {
  echo "Minumum consumption of Milk is in Kolkata";
}
if ($indexes == 1) {
  echo "Minumum consumption of Milk is in Delhi";
}
if ($indexes == 2) {
  echo "Minumum consumption of Milk is in Mumbai";
}
echo "<hr>";
// --------------------------4. Delete location with Minimum sale of Bread-------------------------------
echo "<h3>4. Delete location with Minimum sale of Bread</h3>";
$bread_sum = array(0, 0, 0); //storing array into variable for minimum sale of bread-----
foreach ($data_array as $key => $value) {
  if ($value[0]['Location'] == "Kolkata") {
    $bread_sum[0] += $value[0]["Bread"];
  }
  if ($value[1]['Location'] == "Delhi") {
    $bread_sum[1] += $value[1]["Bread"];
  }
  if ($value[2]['Location'] == "Mumbai") {
    $bread_sum[2] += $value[2]["Bread"];
  }
}
$min = min($bread_sum);
$indexx = array();
for ($i = 0; $i < count($bread_sum); $i++) {
  if ($bread_sum[$i] == $min) {
    array_push($indexx, $i); //pushing data into array-----
  }
}
foreach ($data_array as $key => $value) {
  for ($i = count($indexx) - 1; $i >= 0; $i--) {
    array_splice($data_array[$key], $i, 1); //deleting data from array-----
  }
};
// showing data in a table-------------
$str = "<table><tr><td rowspan=3 >Time</td><td colspan=3 >Location=" . $data_array[0][0]['Location'] . "  </td></tr>";
$str .= "<tr><td colspan=3> Item</td></tr>";
$str .= "<tr><td>Milk</td><td>Egg</td><td>Bread</td></tr>";
foreach ($data_array as $key => $value) {
  $str .= "<tr><td>" . $value[0]["Time"] . "</td><td>" . $value[0]["Milk"] . "</td><td>" . $value[0]["Egg"] . "</td><td>" . $value[0]["Bread"] . "</td></tr>";
}
$str .= "</table>";
echo $str;
?>
</body>

</html>