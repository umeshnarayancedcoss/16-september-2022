<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pattern</title>
</head>

<body>
    <!-- php code start here -->
    <?php
    if (isset($_POST["submit"])) {
        $num = $_POST['digit'];
        //echo $num;
       $temp=0;
       for ($i = $num; $i >= 1; $i--)
        {
            for ($j = $num ; $j >= $i; $j--)
            {
                echo("$j"." ");
                $temp =$j;
            }

            for ($k = $num - $i+1; $k < $num; $k++)
            {
               echo("$temp"." ");
            } echo "<br>";
            
        }
        
    }

    ?>
    <!-- form start here -->
    <form action="" method="post">
        <!-- input box for digit -->
        Enter a digit: <input type="number" name="digit" value="<?php echo $num; ?>" /></br />
        <!-- submit button -->
        <input type="submit" value="Print" name="submit">
    </form>
</body>

</html>