<?php
//session starts here----
session_start();
if (!isset($_SESSION['product'])) {
    $_SESSION['product'] = array();
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}
if (!isset($_SESSION['quantity'])) {
    $_SESSION['quantity'] = 0;
}
?>
<style>
    <?php
    //  CSS linking for cart table----
    include("style.css");
    ?>
</style>
<?php
if (count($_SESSION['cart']) == 0) { //if cart is empty
    echo "<h1>Cart is Empty, Please add some products in cart.!!<h1>";
    // Display cart table-----------
} else {
    echo '<button class="delete_cart" id=' . $key . '>Delete Cart</button>';
    echo "<br/>";
    echo "<br/>";
    echo '<table border="1px solid" >
<tr>
	<th><h2>Product ID</h2></th>
	<th><h2>Product Title</h2></th>
	<th><h2>Product Image</h2></th>
	<th><h2>Product Price</h2></th>
    <th><h2>Product Quantity</h2></th>
     <th><h2>Action</h2></th>
</tr>
<tr>';
?>
<?php
    $total = 0;
    foreach ($_SESSION['cart'] as $key => $val1) {
        $pro_index = $val1['productindex'];
        $price = $_SESSION['product'][$pro_index]["price"] * $val1["quantity"];
        echo '<td><h2>' . $_SESSION['product'][$pro_index]["productid"] . '</h2></td>';
        echo '<td><h2>' . $_SESSION['product'][$pro_index]["title"] . '</h2></td>';
        echo '<td><img src="./images/' . $_SESSION['product'][$pro_index]["images"] . '" /></td>';
        echo '<td><h2>$' . $price . '.00</h2></td>';
        echo '<td><h2><button class="decrease" id=' . $key . '>-</button>  ' . $val1["quantity"] . ' <button class="increase" id=' . $key . '>+</button> </h2> </td>';
        echo '<td><button class="remove_product" id=' . $key . '>Remove</button></td>';
        echo '</tr>';
        $total = $total + ($_SESSION['product'][$pro_index]["price"] * $val1["quantity"]);
    }
    echo '</table>';
    echo '<p>Total Cart Price: $' . $total . '.00</p>';
}
?>