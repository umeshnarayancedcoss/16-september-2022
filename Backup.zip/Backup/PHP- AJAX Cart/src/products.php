<?php
// session starts here---
session_start();
if (!isset($_SESSION['product'])) {
	$_SESSION['product'] = array();
}
if (!isset($_SESSION['cart'])) {
	$_SESSION['cart'] = array();
}
if (!isset($_SESSION['quantity'])) {
	$_SESSION['quantity'] = 0;
}
// including config file that contains session product array----
include("config.php");
?>
<!DOCTYPE html>
<html>

<head>
	<title>
		Products
	</title>
	<!-- linking jQuery File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<!-- Linking StyleSheet -->
	<link href="style.css" type="text/css" rel="stylesheet">
</head>

<body>
	<div id="header">
		<!-- Including Header File -->
		<?php include("header.php"); ?>
	</div>
	<div id="main">
		<div id="products">
			<?php
			foreach ($_SESSION['product'] as $key => $value) {
				echo '	<div id="product-' . $value['productid'] . '" class="product">
			<img src="images/' . $value['images'] . '">
			<h3 class="title"><a href="#">' . $value['title'] . '</a></h3>
			<span>Price: $' . $value['price'] . '</span>
			<a class="add-to-cart" id=' . $key . '>Add To Cart</a>
		</div>';
			}
			?>
		</div>
	</div>
	<!-- Div starting for show cart table -->
	<div id="mycart">
	</div>
	<div id="footer">
		<nav>
			<!-- Including Footer File -->
			<?php include("footer.php"); ?>
	</div>
</body>
<!-- Linking Script File -->
<script src="./script.js"></script>

</html>