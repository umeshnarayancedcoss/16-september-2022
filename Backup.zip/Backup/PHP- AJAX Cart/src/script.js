$(document).ready(function () { //jQuery Starts here
    // -------------Cart Table Display Function--------------
    function display() {
        $.ajax({
            url: "cart_display.php",
            method: "POST",
            success: function (data) {
                $('#mycart').html(data);
            }
        });
    }
    // -----------Add To Cart----------------------------
    $(".add-to-cart").click(function () {
        var pro_index = $(this).attr("id");
        // alert(pro_index);
        $.ajax({
            url: "cart_code.php",
            method: "POST",
            data: {
                pro_index: pro_index,
            },
            success: function (data) {
                display(data);
            }
        });
    })
    //-------------Decrease Counter for Procuct Quantity-------
    $(document).on("click", ".decrease", function () {
        var pro_index = $(this).attr("id");
        //   alert(pro_index);
        // console.log(pro_index);

        $.ajax({
            url: "cart_qty.php?op=dec",
            method: "POST",
            data: {
                pro_index: pro_index,
            },
            success: function (data) {
                display(data);
            }
        });

    });
    // -----------------Increase Counter for Product Quantity---------------
    $(document).on("click", ".increase", function () {
        var pro_index = $(this).attr("id");
        // alert(pro_index);
        $.ajax({
            url: "cart_qty.php?op=inc",
            method: "POST",
            data: {
                pro_index: pro_index,
            },
            success: function (data) {
                display(data);
            }
        });
    });

    // -----------------------Remove Products From Cart-------------------------
    $(document).on("click", ".remove_product", function () {
        var pro_index = $(this).attr("id");
        //  alert(pro_index);
        $.ajax({
            url: "remove_product.php",
            method: "POST",
            data: {
                pro_index: pro_index,
            },
            success: function (data) {
                alert('Product Removed From Cart Successfully.!!');
                display(data);
            }
        });

    });
    // ---------------Delete all Cart------------
    $(document).on("click", ".delete_cart", function () {
        $.ajax({
            url: "delete_cart.php",
            success: function (data) {
                alert('Cart Deleted Successfully.!!');
                display(data);
            }
        });
    });
});//jQuery Ends Here---------
