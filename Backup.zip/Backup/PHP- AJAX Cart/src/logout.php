<?php
session_start();
session_destroy(); //session destroys here---
header("location:index.php");
