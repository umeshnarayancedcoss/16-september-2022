<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PHP Form Validation</title>
</head>

<body>

  <!-- Starting PHP code here----------------- -->
  <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // -----------------------Storing form values in variables-------------------------------------------------------------
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $dob = $_POST['dob'];
    $gender = $_POST['a'];
    $sibling_detail = $_POST['sibling_detail'];
    $f_first_name = $_POST['f_first_name'];
    $f_last_name = $_POST['f_last_name'];
    $f_qualification = $_POST['f_qualification'];
    $f_phone = $_POST['f_phone'];
    $f_email = $_POST['f_email'];
    $f_occupation = $_POST['f_occupation'];
    $m_first_name = $_POST['m_first_name'];
    $m_last_name = $_POST['m_last_name'];
    $m_qualification = $_POST['m_qualification'];
    $m_phone = $_POST['m_phone'];
    $m_email = $_POST['m_email'];
    $m_occupation = $_POST['m_occupation'];
    $address = $_POST['address']; //--storing form variables ends here---

    // --------------------Forms Input Fields Validation through nested if-else starts here-----------------------------
    if (empty($_POST["first_name"])) {
      $err_msg1 = "Please enter the both First Name & Last Name";
      // echo $err_msg1;  
    } else if (!filter_var($first_name, FILTER_VALIDATE_INT) === false) {
      $err_msg20 = "First Name Should be character only.";
    } else if (empty($_POST["last_name"])) {
      $err_msg1 = "Please enter the both First Name & Last Name";
      // echo $err_msg2;  
    } else if (!filter_var($last_name, FILTER_VALIDATE_INT) === false) {
      $err_msg21 = "Last Name Should be character only.";
    } else if (empty($_POST["dob"])) {
      $err_msg2 = "Error! You didn't enter the DOB.";
    } else if (empty($_POST["a"])) {

      $err_msg3 = "Error! You didn't enter the Gender.";
    } else  if (empty($_POST["sibling_detail"])) {

      $err_msg4 = "Error! You didn't enter the Siblings Detail.";
    } else  if (empty($_POST["f_first_name"])) {
      $err_msg5 = "Please enter the both Fathers First Name & Last Name.";
    } else if (!filter_var($f_first_name, FILTER_VALIDATE_INT) === false) {
      $err_msg22 = "First Name Should be character only.";
    } else  if (empty($_POST["f_last_name"])) {
      $err_msg5 = "Please enter the both Fathers First Name & Last Name.";
    } else if (!filter_var($f_last_name, FILTER_VALIDATE_INT) === false) {
      $err_msg22 = "Last Name Should be character only.";
    } else  if (empty($_POST["f_qualification"])) {
      $err_msg6 = "Error! You didn't enter the Fathers Qualifications.";
    } else  if (empty($_POST["f_phone"])) {
      $err_msg9 = "Please enter the Fathers Phone No.";
    } else  if (strlen($_POST["f_phone"]) != 10) {
      $err_msg16 = "Please enter 10 digit valid Mobile No.";
    } else  if (($f_phone[0] != 9)  && ($f_phone[0] != 8) && ($f_phone[0] != 7) &&  ($f_phone[0] != 6)) {
      $err_msg17 = "Mobile No. Should starts with 9, 8,7,6 only.";
    } else  if (empty($_POST["f_email"])) {
      $err_msg10 = "Please enter the Fathers Email Address.";
    } else  if (empty($_POST["f_occupation"])) {
      $err_msg11 = "Error! You didn't enter the Fathers Occupation.";
    } else if (!filter_var($f_occupation, FILTER_VALIDATE_INT) === false) {
      $err_msg27 = "Occupation Should be character only.";
    } else  if (empty($_POST["m_first_name"])) {
      $err_msg7 = "Error! You didn't enter the Mothers First Name & Last Name.";
    } else if (!filter_var($m_first_name, FILTER_VALIDATE_INT) === false) {
      $err_msg23 = "First Name Should be character only.";
    } else if (!filter_var($m_last_name, FILTER_VALIDATE_INT) === false) {
      $err_msg23 = "Last Name Should be character only.";
    } else  if (empty($_POST["m_last_name"])) {
      $err_msg7 = "Please enter the both Mothers First Name & Last Name.";
    } else  if (empty($_POST["m_qualification"])) {
      $err_msg8 = "Please enter the Mothers Qualification";
    } else  if (empty($_POST["m_phone"])) {
      $err_msg12 = "Please enter the Mothers Phone No.";
    } else  if (strlen($_POST["m_phone"]) != 10) {
      $err_msg24 = "Please enter 10 digit valid Mobile No.";
    } else  if (($m_phone[0] != 9)  && ($m_phone[0] != 8) && ($m_phone[0] != 7) &&  ($m_phone[0] != 6)) {
      $err_msg25 = "Mobile No. Should starts with 9, 8,7,6 only.";
    } else  if (empty($_POST["m_email"])) {
      $err_msg13 = "Please enter the Mothers Email Address.";
    } else  if (empty($_POST["m_occupation"])) {
      $err_msg14 = "Please enter the Mothers Occupation.";
    } else if (!filter_var($m_occupation, FILTER_VALIDATE_INT) === false) {
      $err_msg28 = "Occupation Should be character only.";
    } else  if (empty($_POST["address"])) {
      $err_msg15 = "Please enter Address.";
    } else {
      // When all conditions will satisfied then this code will executed----------------------------
      echo '<script type ="text/JavaScript">';
      echo 'alert("Details Submitted Successfully.!!")';
      echo '</script>';
      $success_message = "Details Submitted Successfully..!!";
    }
  } //Form validation if else ends here------------------
  ?>

  <!-- -------------------------------HTML Form starts here--------------------- -->
  <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
    <?php
    $c_date = date("Y-m-d"); //storing current date for date validation
    //echo $c_date;
    ?>
    <h2>Student Registration Form</h2>
    <h3 style="color:green;"><?php echo $success_message; ?></h3>
    <p style="color:red;">* indicates required field</p>

    <!-- ----------forms fields starts here---------- -->
    <!-- Applicnts information -->
    Name of the Applicant <span style="color:red">*</span> <br />
    <input type="text" name="first_name" value="<?php echo $first_name; ?>" placeholder="First" onkeydown="return/[a-z]/i.test(event.key);">
    <input type="text" name="last_name" value="<?php echo $last_name; ?>" placeholder="Last"><br>
    <p style="color:red;"><?php echo $err_msg1;  ?></p>
    <p style="color:red;"><?php echo $err_msg20;  ?></p>
    <p style="color:red;"><?php echo $err_msg21;  ?></p>
    <br>

    Date of Birth <span style="color:red">*</span><br>
    <input type="date" name="dob" value="<?php echo $dob; ?>" max="<?php echo $c_date; ?>"><br>
    <p style="color:red;"><?php echo $err_msg2;   ?></p><br>

    Gender <span style="color:red">*</span> <br>
    <input type="radio" name="a" value="male" <?php if ($_POST['a'] == 'male') {
                                                echo "checked";
                                              }  ?>>Male <br>
    <input type="radio" name="a" value="female" <?php if ($_POST['a'] == 'female') {
                                                  echo "checked";
                                                }  ?>>Female <br>
    <p style="color:red;"><?php echo $err_msg3;   ?></p><br>

    Details of Siblings <span style="color:red">*</span> <br>
    <textarea name="sibling_detail" id="" cols="45" rows="4" style="resize:none;"><?php echo $sibling_detail; ?>
</textarea><br>
    <p style="color:red;"><?php echo $err_msg4;   ?></p>

    <h3>Parents Information</h3>
    <!-- Fathers information----------- -->
    Father's Name <span style="color:red">*</span> <br>
    <input type="text" name="f_first_name" value="<?php echo $f_first_name; ?>" placeholder="First" onkeydown="return/[a-z]/i.test(event.key)">
    <input type="text" name="f_last_name" value="<?php echo $f_last_name; ?>" placeholder="Last" onkeydown="return/[a-z]/i.test(event.key)"><br>
    <p style="color:red;"><?php echo $err_msg5;   ?></p>
    <p style="color:red;"><?php echo $err_msg22;   ?></p>
    <br>

    Fathers Qualification <span style="color:red">*</span><br>
    <input type="text" name="f_qualification" value="<?php echo $f_qualification; ?>" style="width:380px;height:40px;"><br>
    <p style="color:red;"><?php echo $err_msg6;   ?></p>
    <br>

    Phone <span style="color:red">*</span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email <span style="color:red">*</span><br>
    <input type="number" name="f_phone" value="<?php echo $f_phone; ?>" placeholder="### ### ###" min="0" oninput="validity.valid||(value='');">
    <input type="email" name="f_email" value="<?php echo $f_email; ?>"> <br>
    <p style="color:red;"><?php echo $err_msg9;   ?></p>
    <p style="color:red;"><?php echo $err_msg10;   ?></p>
    <p style="color:red;"><?php echo $err_msg16;   ?></p>
    <p style="color:red;"><?php echo $err_msg17;   ?></p>
    <br>

    Fathers Occupation <span style="color:red">*</span> <br>
    <input type="text" name="f_occupation" value="<?php echo $f_occupation; ?>" style="width:380px;height:30px;" onkeydown="return/[a-z]/i.test(event.key)"><br>
    <p style="color:red;"><?php echo $err_msg11;   ?></p>
    <p style="color:red;"><?php echo $err_msg27;   ?></p>
    <br>

    <!-- ---------------------------Mothers Information------------------------------- -->
    Mothers Name <span style="color:red">*</span> <br>
    <input type="text" name="m_first_name" placeholder="First" value="<?php echo $m_first_name; ?>" onkeydown="return/[a-z]/i.test(event.key)">
    <input type="text" name="m_last_name" placeholder="Last" value="<?php echo $m_last_name; ?>" onkeydown="return/[a-z]/i.test(event.key)"><br>
    <p style="color:red;"><?php echo $err_msg7;   ?></p>
    <p style="color:red;"><?php echo $err_msg23;   ?></p>
    <br>

    Mothers Qualification <span style="color:red">*</span> <br><br>
    <input type="text" name="m_qualification" value="<?php echo $m_qualification; ?>" style="width:380px;height:40px;"><br>
    <p style="color:red;"><?php echo $err_msg8;   ?></p>
    <br>

    Phone <span style="color:red">*</span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email <span style="color:red">*</span> <br>
    <input type="number" name="m_phone" value="<?php echo $m_phone; ?>" placeholder="### ### ###" min="0" oninput="validity.valid||(value='');">
    <input type="email" name="m_email" value="<?php echo $m_email; ?>"> <br>
    <p style="color:red;"><?php echo $err_msg12;   ?></p>
    <p style="color:red;"><?php echo $err_msg13;   ?></p>
    <p style="color:red;"><?php echo $err_msg24;   ?></p>
    <p style="color:red;"><?php echo $err_msg25;   ?></p>
    <br>

    Mother's Occupation <span style="color:red">*</span> <br>
    <input type="text" name="m_occupation" value="<?php echo $m_occupation; ?>" style="width:380px;height:30px;"><br>
    <p style="color:red;"><?php echo $err_msg14;   ?></p>
    <p style="color:red;"><?php echo $err_msg28;   ?></p>
    <br>

    Address <span style="color:red">*</span> <br>
    <textarea name="address" id="" placeholder="Street Address" cols="45" rows="4" style="resize:none;">
<?php echo $address; ?>
</textarea><br>
    <p style="color:red;"><?php echo $err_msg15;   ?></p>
    <br>
    <!-- Form submit button -->
    <input type="submit" value="Check Here" name="submit" style="height:50px; width:350px; font-size:18px;color:white; background-color:green;border-radius:10px;">

  </form>
  <!-- Form ends here -->

</body>

</html>