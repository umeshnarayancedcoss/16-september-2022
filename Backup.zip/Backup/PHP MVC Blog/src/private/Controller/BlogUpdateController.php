<?php
// session starts here--------
session_start();
$email = $_SESSION['user'];
include("../config/config.php"); //database connectivity---------
$blog_id = $_REQUEST['blog_id']; //holding blog id-------
if (isset($_POST)) {
    // holding updated data into variables----------
    $category = $_POST['category'];
    $title = $_POST['title'];
    $description = $_POST['blog_description'];
    // Query for upadting values in blog table------------
    $blog = Blog::find_by_blog_id($blog_id);
    // updating blog details---
    $blog->category = $category;
    $blog->title = $title;
    $blog->description = $description;
    $blog->save();
    echo "<script>alert('Blog Updated Successfully.!!');window.location.href='../View/MyBlog.php';</script>";
}
