<?php
// session starts here--
session_start();
$blog_id = $_REQUEST['blog_id'];
include("../config/config.php"); //database connectivity---
$blog = Blog::find_by_blog_id($blog_id);
$blog->status = 'Show'; //updating status from 'Hide' to 'Show'----
$blog->save();
header("location:../View/ViewBlog.php");
