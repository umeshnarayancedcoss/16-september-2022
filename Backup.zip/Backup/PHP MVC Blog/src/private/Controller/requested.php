<?php
// session starts here---
session_start();
$user_id = $_REQUEST['user_id'];
include("../config/config.php"); //database connectivity--
$user = User::find_by_user_id($user_id); //fetching user detail--
$user->status = 'Approved'; //update status---
$user->save(); //save---
header("location:../View/ViewUser.php"); //redirect to ViewUser page--
