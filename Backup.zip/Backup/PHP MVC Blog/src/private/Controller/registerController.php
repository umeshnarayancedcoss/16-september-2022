<?php
include("../config/config.php"); //database connectivity--
if (isset($_POST)) {
    // storing form input values into variables---
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];
    $cnfpass = $_POST['cnfpass'];
    if ($password == $cnfpass) { //if password and confirm password will be same--
        // inserting record into users table---
        $user = User::create(array('user_name' => $name, 'email' => $email, 'mobile' => $mobile, 'password' => $password, 'status' => 'Requested'));
        echo "<script>alert('Registered Successfully.!!');window.location.href='../View/Login.php'</script>";
    } else { //if password and confirm password not same--
        $msg = "Error: Password and Repeat Password Should be Same.!!";
        header("location:../View/Register.php?msg=$msg"); //redirecting to Register Page with Error message---
    }
}
