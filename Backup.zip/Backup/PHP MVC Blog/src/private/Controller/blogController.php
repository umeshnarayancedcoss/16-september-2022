<?php
// session starts here---
session_start();
$email = $_SESSION['user'];
include("../config/config.php"); //database connectivity---
$user = User::find_by_email($email); //query for fetching user detail by email id--
$user_name = $user->user_name;
$user_id = $user->user_id;
if (isset($_POST)) { //On submit post button---
    // holding form values into variables-----
    $category = $_POST['category'];
    $title = $_POST['title'];
    $blog_description = $_POST['blog_description'];
    $filename = $_FILES['file']['name'];
    $filetype = $_FILES['file']['type'];
    $file_tmp_name = $_FILES['file']['tmp_name'];
    $filesize = $_FILES['file']['size'];
    $file_ext = strtolower(end(explode('.', $_FILES['file']['name'])));
    $uploaddir = "../../public/images/";
    $uploadfile = $uploaddir . basename($_FILES['file']['name']);
    $date = date("d/m/y");
    // Insertion query for insert blog in blog tble------
    $blog = Blog::create(array('user_id' => $user_id, 'posted_by' => $user_name, 'category' => $category, 'title' => $title, 'description' => $blog_description, 'image' => $filename, 'date' => $date, 'status' => 'Hide'));
    move_uploaded_file($file_tmp_name, "../../public/images/" . $filename); //image moved into folder----
    echo "<script>alert('Blog Posted Successfully.!!');window.location.href='../View/MyBlog.php';</script>";
}
