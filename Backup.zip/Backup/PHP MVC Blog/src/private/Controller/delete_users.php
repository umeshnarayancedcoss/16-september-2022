<?php
// session starts here---
session_start();
$user_id = $_REQUEST['user_id'];
include("../config/config.php"); //database connectivity---
$user = User::table()->delete(array('user_id' => $user_id)); //delete query---
echo "<script>alert('User Record Deleted Successfully.!!');window.location.href='../View/ViewUser.php';</script>";
