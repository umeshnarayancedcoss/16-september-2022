<?php
// session starts here---
session_start();
include("../config/config.php"); //database connectivity---
if (isset($_POST)) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    // Fetching Record From admins table-----
    $admin = Admin::find('all', array('conditions' => array('admin_email' => $email, 'password' =>  $password)));
    if ($admin) { //if email password matched---
        $_SESSION['admin'] = $email; //creating session of users emailID----
        header("location:../View/AdminDashboard.php"); //redirecting to AdminDeashboard page---
    } else { //if email password not matched---
        $msg = "Error: Invalid Email or Password..!!";
        header("location:../View/AdminLogin.php?msg=$msg"); //redirecting to Login page with error message---
    }
}
