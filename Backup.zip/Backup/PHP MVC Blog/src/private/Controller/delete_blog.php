<?php
// session starts here----
session_start();
include("../config/config.php"); //database connectivity-----
$blog_id = $_REQUEST['blog_id'];
$blog = Blog::table()->delete(array('blog_id' => $blog_id)); //delete query---
echo "<script>alert('Blog Deleted Successfully.!!');window.location.href='../View/MyBlog.php';</script>";
