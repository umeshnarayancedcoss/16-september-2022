<?php
// session starts here----
session_start();
include("../config/config.php"); //database connectivity-----
$cat_id = $_REQUEST['cat_id'];
$category = Category::table()->delete(array('cat_id' => $cat_id)); //delete query---
header("location:../View/AddCategory.php");
