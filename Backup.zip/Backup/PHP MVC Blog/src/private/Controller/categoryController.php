<?php
// session starts here---
session_start();
include "../config/config.php"; //database connectivity---
$category = $_POST['category'];
$category = Category::create(array('cat_name' => $category)); //insertion in database--
header("location:../View/AddCategory.php");
