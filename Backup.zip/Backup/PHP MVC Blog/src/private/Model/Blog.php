<?php
//ActiveRecord Model extending properties to Class Blog----
class Blog extends ActiveRecord\Model
{
}
