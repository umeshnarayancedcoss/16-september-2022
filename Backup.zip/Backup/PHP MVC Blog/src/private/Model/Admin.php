<?php
//ActiveRecord Model extending properties to Class Admin----
class Admin extends ActiveRecord\Model
{
}