<?php
// session starts here------
session_start();
$_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../../admin/index.php");
}
include("../config/config.php"); //database connectivity---
include("AdminMenu.php"); //Linking AdminMenu-----------
?>
<!-- --------HTML Code Starts Here--------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>View Blogs</title>
    <style>
        /* -----CSS for table-------------- */
        table,
        th,
        td {

            text-align: center;

        }

        tr:hover {
            background-color: lightgrey;
        }
    </style>
</head>

<body>
    <!-- ------DIV For showing tables showing here------ -->
    <div class="showtables">
        <table class="table table-striped">
            <tr>
                <th>S. No.</th>
                <th>Blog ID</th>
                <th>User ID</th>
                <th>Posted By</th>
                <th>Posted Date</th>
                <th>Category</th>
                <th>Title</th>
                <th>Description</th>
                <th>Related Image</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php
            // ---Query for fetching all Blogs From Blog Table------------
            $blog = Blog::find('all',array('order'=> 'blog_id desc'));
            $a = 1;
            foreach ($blog as $key => $value) {
                $status = $value->status;
            ?>
                <tr>
                    <td><?php echo $a++; ?></td>
                    <td><?php echo $value->blog_id ?></td>
                    <td><?php echo $value->user_id ?></td>
                    <td><?php echo $value->posted_by ?></td>
                    <td><?php echo $value->date ?></td>
                    <td><?php echo $value->category ?></td>
                    <td><?php echo $value->title ?></td>
                    <td><?php echo $value->description ?></td>
                    <td><img src="../../public/images/<?php echo $value->image ?>" style="height:100px;width:100px;"></td>
                    <?php
                    if ($status == "Show") { //if status will be 'show'----
                    ?>
                        <td><a href="../Controller/show.php?blog_id=<?php echo $value->blog_id  ?>"><?php echo $status ?></a></td>
                    <?php
                    } else { //if status will be 'hide'------
                    ?>
                        <td><a href="../Controller/hide.php?blog_id=<?php echo $value->blog_id  ?>"><?php echo $value->status ?></a></td>
                    <?php
                    }
                    ?>
                    <td><a href="../Controller/admin_delete_blog.php?blog_id=<?php echo $value->blog_id ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Delete</button></a></td>
                <?php
            }
                ?>
                </tr>
                <?php
                $a++;
                ?>
                <tr></tr>
        </table>
    </div>
</body>

</html>