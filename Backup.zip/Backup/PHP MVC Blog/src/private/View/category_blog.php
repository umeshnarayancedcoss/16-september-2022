<?php
// session starts here---
session_start();
include("../config/config.php");
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../../admin/index.php");
}
$category = $_REQUEST['category'];
$_SESSION['category'] = $category; //storing category in a session---
?>
<!-- HTML Code starts here -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top <?php echo $_SESSION['category']; ?> Blogs</title>
</head>

<body>
    <!-- Admin NavBar Linking -->
    <?php include("../View/AdminMenu.php"); ?>
    <div class="container" style="margin-top:50px;">
        <center>
            <h3>Top <?php echo $_SESSION['category'] ?> Blogs</h3>
        </center>
        <div class="col-sm-12">
            <div class="row">
                <?php
                // Select query for fetching blogs from blog table which status is "show"---------
                $blog = Blog::find('all', array('conditions' => array('category' => $_SESSION['category'], 'status' => 'Show'))); //blog query
                foreach ($blog as $key => $value) {
                ?>
                    <div class="col-4" style="margin-top:20px;">
                        <div class="card">
                            <img src="../../public/images/<?php echo $value->image ?>" class="card-img-top" style="height:220px;width:100%;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $value->title ?></h5>
                                <a href="AdminReadBlog.php?blog_id=<?php echo $value->blog_id; ?>" class="btn btn-primary">Read Full Blog</a>
                            </div>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</body>

</html>