<?php
// session starts here------
session_start();
$email = $_SESSION['user'];
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:../View/Login.php");
}
include("../config/config.php"); //database connectivity --
// Navbar Linking Condition----------
if ($_SESSION['user'] == "") {
    include("../View/menu.php");
} else {
    include("../View/UserMenu.php");
}
// Fetching User Detail with the help of email id---
$user = User::find_by_email($email);
$user_name = $user->user_name;
$user_id = $user->user_id;
?>
<!-- ------HTML Code Starts Here---------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>My Blogs</title>
    <style>
        /* ---------CSS For Table Tag------ */
        table,
        th,
        td {
            text-align: center;

        }

        .table-striped {
            font-family: rockwell;
            width: 100%;
            margin: 0px auto;
            cursor: not-allowed;
            margin-top: 70px;
        }

        tr:hover {
            background-color: lightgray;
        }
    </style>
</head>

<body>
    <!-- -----------Showing data in table starts here------- -->
    <div class="showtables">
        <center>
            <table class="table table-striped">
                <tr>
                    <th>S. No.</th>
                    <th>Blog ID</th>
                    <th>Posted Date</th>
                    <th>Category</th>
                    <th>Title</th>
                    <th>Related Image</th>
                    <th>Status</th>
                    <th>Delete</th>
                    <th>View</th>
                </tr>
                <?php
                // Fetching blogs from tbl_blog posted by specific user-------
                $blog = Blog::find('all', array('order' => 'blog_id desc', 'conditions' => array('user_id' => $user_id)));
                $a = 1;
                foreach ($blog as $key => $value) {
                    $status = $value->status;
                ?>
                    <tr>
                        <td><?php echo $a++; ?></td>
                        <td><?php echo  $value->blog_id ?></td>
                        <td><?php echo $value->date ?></td>
                        <td><?php echo $value->category ?></td>
                        <td><?php echo $value->title ?></td>
                        <td><img src="../../public/images/<?php echo $value->image ?>" style="height:100px;width:100px;"></td>
                        <td><?php echo $status ?></td>
                        <td><a href="../Controller/delete_blog.php?blog_id=<?php echo $value->blog_id ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Delete</button></a></td>
                        <td><a href="../View/view_blog.php?blog_id=<?php echo $value->blog_id ?>">View</a></td>
                    <?php
                }
                    ?>
                    </tr>
                    <?php
                    $a++;
                    ?>
                    <tr></tr>
            </table>
    </div>
    </center>

</body>

</html>