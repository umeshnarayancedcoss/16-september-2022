<?php
// session starts here------
session_start();
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../../admin/index.php");
}
include("AdminMenu.php"); //Linking Admin NavBar---
include("../config/config.php"); //Database Connectivity----
?>
<!-- ----HTML Code starts Here----- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Add Category</title>
    <style>
        /* ---CSS For Table------- */
        table,
        th,
        td {
            text-align: center;
        }
    </style>
</head>

<body>
    <center>
        <div style="margin-top:20px;">
            <!-- -------Form Starts Here------ -->
            <form action="../Controller/categoryController.php" method="post">
                Enter a category: <input type="text" name="category" required><br><br>
                <input type="submit" value="Add" style="background-color:green;color:white;">
            </form>
            <!-- ------Form Ends Here------ -->
        </div>
    </center>
    <br><br>
    <center>
        <!-- ----------Showing Categories in Table------------  -->
        <table class="table table-striped">
            <tr>
                <th>S. No.</th>
                <th>Category ID</th>
                <th>Category Name</th>
                <th>Delete</th>
            </tr>
            <?php
            $category = Category::find('all'); //query for fetching all categories from table---
            $a = 1;
            foreach ($category as $key => $value) {
            ?>
                <tr>
                    <td><?php echo $a++; ?></td>
                    <td><?php echo $value->cat_id; ?></td>
                    <td><?php echo $value->cat_name; ?></td>
                    <td><a href="../Controller/delete_cat.php?cat_id=<?php echo $value->cat_id;
                                                                        ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Delete</button></a></td>
                <?php
            }
                ?>
                </tr>
                <?php
                $a++;
                ?>
                <tr></tr>
        </table>
    </center>
</body>

</html>