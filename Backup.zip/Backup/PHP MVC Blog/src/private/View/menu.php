<?php
include("../config/config.php"); //database connectivity---
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <style>
        /* On Hover CSS */
        .nav-item:hover {
            background-color: white;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><img src="../../public/images/logo.png" style="height:30px;width:35px;"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/Login.php"> Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/Register.php">Register</a>
                    </li>

                    <div class="btn-group">
                        <button type="button" class="btn btn-secondary dropdown-toggle bg-info" data-bs-toggle="dropdown" aria-expanded="false" style="color:black">
                            Category
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php
                            $category = Category::find('all', array('order' => 'cat_name asc')); //category query
                            foreach ($category as $key => $value) {
                                echo "<li><a class='dropdown-item' href='../View/UserCategoryBlog.php?category=$value->cat_name'>" .  $value->cat_name . "</a></li>"; //generating options---
                            }
                            ?>

                        </ul>
                    </div>
                </ul>
            </div>
        </div>
    </nav>
</body>

</html>