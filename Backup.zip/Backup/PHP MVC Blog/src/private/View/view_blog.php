<?php
// session starts here--------
session_start();
$_SESSION['user'];
include("../config/config.php"); //database connectivity-------
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:../View/Login.php");
}
// NavBar Linking Condition-------
if ($_SESSION['user'] == "") {
    include("../View/menu.php");
} else {
    include("../View/UserMenu.php");
}

$blog_id = $_REQUEST['blog_id'];
// Query For Showing Blog with the help of Blog ID---------
$blog = Blog::find('all', array('conditions' => array('blog_id' => $blog_id)));
foreach ($blog as $key => $value) {
    $title = $value->title;
    $image = $value->image;
    $postedby = $value->posted_by;
    $description = $value->description;
    $posteddate = $value->date;
}
?>
<!-- -----HTML Code starts here------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title;  ?></title>
</head>

<body>
    <!-- -------------Div for showing Blog----------- -->
    <div class="container" style="margin-top:80px;">
        <div class="col-sm-12" style="min-height:550px;">
            <div class="row" style="height:250px;">
                <div class="col-sm-5">
                    <img src="../../public/images/<?php echo $image ?>" style="height:250px;width:100%;border-radius:20px;">
                </div>
                <div class="col-sm-7">
                    <p class="card-title" style="font-size:35px;"><?php echo $title ?></p>
                    <p style="margin-top: 60px"> Posted By- <b><?php echo $postedby; ?></b>, Posted Date- <b><?php echo $posteddate; ?></b></p>
                    <!-- ----Edit Button For Edit a Blog--- -->
                    <a href="../View/editblog.php?blog_id=<?php echo $blog_id;  ?>"><button style="height:30px; width:150px;background-color:green;color:white;border-radius:10px;border:none;">Edit This Blog</button></a>
                </div>
            </div>
            <div class="row" style="min-height:auto;margin-top:4%;border-radius:5px;">
                <p align="justify" style="font-size:20px;"><?php echo $description; ?></p>
            </div>
        </div>
    </div>
</body>

</html>