<?php
// Session starts here----------
session_start();
$_SESSION['user'];
include("../config/config.php"); //database connectivity---
// NavBar Linking Condition--
if ($_SESSION['user'] == "") {
    include("menu.php");
} else {
    include("UserMenu.php");
}
?>
<!-- ------HTML Code Starts Here-------------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./css/style.css">
    <title>Welcome</title>
</head>

<body>
    <!-- ---Showing Blogs in a row on home page---- -->
    <div class="container" style="margin-top:70px;">
        <div class="col-sm-12">
            <div class="row">
                <?php
                // Select query for fetching blogs from blog table which status is "show"---------
                $blog = Blog::find('all', array('order' => 'blog_id desc','conditions' => array('status' => 'Show'))); //blog query
                foreach ($blog as $key => $value) {
                ?>
                    <div class="col-4" style="margin-top:20px;">
                        <div class="card">
                            <img src="../../public/images/<?php echo $value->image ?>" class="card-img-top" style="height:220px;width:100%;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $value->title ?></h5>
                                <a href="read_blog.php?blog_id=<?php echo $value->blog_id; ?>" class="btn btn-primary">Read Full Blog</a>
                            </div>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
    <!-- ----------------------------Footer Section------------------ -->
    <footer class="text-center text-lg-start" style="background-color: skyblue;margin-top:20px;">
        <div class="container d-flex justify-content-center py-5">
            <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #54456b;">
                <i class="fab fa-facebook-f"></i>
            </button>
            <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #54456b;">
                <i class="fab fa-youtube"></i>
            </button>
            <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #54456b;">
                <i class="fab fa-instagram"></i>
            </button>
            <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #54456b;">
                <i class="fab fa-twitter"></i>
            </button>
        </div>
        <!-- Copyright -->
        <div class="text-center text-white p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            © 2022 Copyright:
            <a class="text-white" href="../../index.php">Blog</a>
        </div>
        <!-- Copyright -->
    </footer>
    <!-- End of .container -->

</body>

</html>