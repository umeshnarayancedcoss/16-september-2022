<?php
// session starts here---
session_start();
include("../config/config.php"); //database connectivity---
$category = $_REQUEST['category'];
$_SESSION['blog_category'] = $category; //holding BlogCategory in a session--
// NavBar Linking----
if ($_SESSION['user'] == "") {
    include("../View/menu.php");
} else {
    include("../View/UserMenu.php");
}
?>
<!-- ---HTML Code starts here -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top <?php echo $_SESSION['blog_category']; ?> Blogs</title>
</head>

<body>
    <div class="container" style="margin-top:70px;">
        <center>
            <h3>Top <?php echo $_SESSION['blog_category'] ?> Blogs</h3>
        </center>
        <div class="col-sm-12">
            <div class="row">
                <?php
                // Select query for fetching blogs from blog table which status is "show"---------
                $blog = Blog::find('all', array('conditions' => array('category' => $_SESSION['blog_category'], 'status' => 'Show'))); //blog query
                foreach ($blog as $key => $value) {
                ?>
                    <div class="col-4" style="margin-top:20px;">
                        <div class="card">
                            <img src="../../public/images/<?php echo $value->image ?>" class="card-img-top" style="height:220px;width:100%;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $value->title ?></h5>
                                <a href="../View/read_blog.php?blog_id=<?php echo $value->blog_id; ?>" class="btn btn-primary">Read Full Blog</a>
                            </div>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>

</body>

</html>