<?php
// session starts here--------
session_start();
$_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../../admin/index.php");
}
include("../config/config.php"); //database connectivity----------
include("../View/AdminMenu.php");  //Linking Admin NavBar--------
?>
<!----- HTML Code starts Here-- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <title>View Users</title>
</head>

<body>
    <!-- ------DIV for showing users in a table---------- -->
    <table class="table table-striped">
        <tr>
            <th>S. No.</th>
            <th>User ID</th>
            <th>User Name</th>
            <th>Email</th>
            <th>Contact No.</th>
            <th>Password</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php
        // QUery For fetching all users from Register Table-----
        $user = User::find('all',array('order'=> 'user_id desc'));
        $a = 1;
        foreach ($user as $key => $value) {
            $status = $value->status;
        ?>
            <tr>
                <td><?php echo $a++; ?></td>
                <td><?php echo $value->user_id ?></td>
                <td><?php echo $value->user_name ?></td>
                <td><?php echo $value->email ?></td>
                <td><?php echo $value->mobile ?></td>
                <td><?php echo $value->password ?></td>
                <?php
                if ($status == "Requested") { //if status to be 'requested'------
                ?>
                    <td><a href="../Controller/requested.php?user_id=<?php echo $value->user_id  ?>"><?php echo $status ?></a></td>
                <?php
                } else { //if status to be 'approved'---------
                ?>
                    <td><a href="../Controller/approved.php?user_id=<?php echo $value->user_id  ?>"><?php echo $value->status ?></a></td>
                <?php
                }
                ?>
                <td><a href="../Controller/delete_users.php?user_id=<?php echo $value->user_id ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Delete</button></a></td>
            <?php
        }
            ?>
            </tr>
            <?php
            $a++;
            ?>
            <tr></tr>
    </table>
</body>

</html>