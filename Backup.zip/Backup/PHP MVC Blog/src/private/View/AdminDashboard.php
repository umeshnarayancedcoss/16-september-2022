<?php
session_start();
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:../../admin/index.php");
}
include("../View/AdminMenu.php");
include("../config/config.php");

// if ($_SESSION['admin'] != "") {
//     echo $_SESSION['admin'];
//     echo "<br>";
//     echo '<a href="../View/AddCategory.php">Add Category</a>';
//     echo "<br>";
//     echo '<a href="../View/ViewUser.php">View Users</a>';
//     echo "<br>";
//     echo '<a href="../View/ViewBlog.php">View Blogs</a>';
//     echo "<br>";
//     echo '<a href="../Controller/adminLogout.php">Logout</a>';
// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Admin</title>
</head>

<body>

    <div class="container" style="margin-top:70px;">
        <div class="col-sm-12">
            <div class="row">
                <div class="col-6" style="margin-top:20px;">
                    <h3>Recent Users</h3>
                    <table class="table table-striped">
                        <tr>
                            <th>User_Id</th>
                            <th>UserName</th>
                            <th>Status</th>
                        </tr>
                        <tr>
                            <?php
                            $users = User::find('all', array('order' => 'user_id desc', 'limit' => 5));
                            foreach ($users as $key => $value) {
                                echo "<td>" . $value->user_id . "</td>";
                                echo "<td>" . $value->user_name . "</td>";
                                echo "<td>" . $value->status . "</td>";
                            ?>
                        </tr>
                    <?php
                            }
                    ?>
                    </table>
                    <a href="../View/ViewUser.php"><button style="height:35px;width:100px;background-color:green;color:white;border:none;border-radius:5px;">View More</button></a>
                </div>

                <div class="col-6" style="margin-top:20px;">
                    <h3>Recent Blogs</h3>
                    <table class="table table-striped">
                        <tr>
                            <th>Blog_Id</th>
                            <th>Title</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                        <tr>
                            <?php
                            $blogs = Blog::find('all', array('order' => 'blog_id desc', 'limit' => 5));
                            foreach ($blogs as $key => $value) {
                                echo "<td>" . $value->blog_id . "</td>";
                                echo "<td>" . $value->title . "</td>";
                                echo "<td>" . $value->date . "</td>";
                                echo "<td>" . $value->status . "</td>";
                            ?>
                        </tr>
                    <?php
                            }
                    ?>
                    </table>
                    <a href="../View/ViewBlog.php"><button style="height:35px;width:100px;background-color:green;color:white;border:none;border-radius:5px;">View More</button></a>
                </div>
            </div>
        </div>
    </div>

</body>

</html>