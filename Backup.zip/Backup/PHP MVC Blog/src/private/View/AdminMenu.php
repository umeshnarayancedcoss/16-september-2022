<?php
// session starts here---
session_start();
include("../config/config.php"); //database connectivity--
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* On Hover CSS */
        .nav-item:hover {
            background-color: white;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
        <div class="container-fluid">
            <a class="navbar-brand" href="../View/AdminDashboard.php"><img src="../../public/images/logo.png" style="height:30px; width:35px;"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../View/AdminDashboard.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/ViewUser.php"> Users</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/ViewBlog.php"> Blogs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/AddCategory.php"> Category</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Select Category
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <?php
                            // fetching all categories from category table---
                            $category = Category::find('all', array('order' => 'cat_name asc'));
                            foreach ($category as $key => $value) {
                                echo "<li><a class='dropdown-item' href='../View/category_blog.php?category=$value->cat_name'>" .  $value->cat_name . "</a></li>"; //generating options---
                            }
                            ?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-right rbx-navbar-icon-group">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../Controller/adminLogout.php">Logout</a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>

</body>

</html>