<?php
// session starts here----
session_start();
$_SESSION['user'];
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:../View/Login.php");
}
include("../config/config.php"); //database connectivity---
// NavBar Linking Condition---
if ($_SESSION['user'] == "") {
    include("../View/menu.php");
} else {
    include("../View/UserMenu.php");
}
$blog_id = $_REQUEST['blog_id'];
// Fetching data from blog table---------
$blog = Blog::find('all', array('conditions' => array('blog_id' => $blog_id)));
foreach ($blog as $key => $value) {
    // holding blog details into variables---
    $title = $value->title;
    $image = $value->image;
    $postedby = $value->posted_by;
    $description = $value->description;
    $posteddate = $value->date;
    $category = $value->category;
}
?>
<!-- ------------------HTML Starts Here---------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>::Post a Blog::</title>
</head>

<body>
    <form action="../Controller/BlogUpdateController.php?blog_id=<?php echo $blog_id; ?>" method="POST" enctype="multipart/form-data">
        <section class="vh-100">
            <div class="container h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-xl-9">
                        <div class="card" style="border-radius: 15px;">
                            <div class="card-body">
                                <div class="row align-items-center pt-4 pb-3">
                                    <div class="col-md-3 ps-5">
                                        <h6 class="mb-0">Blog Category</h6>
                                    </div>
                                    <div class="col-md-9 pe-5">
                                        <select name="category" id="category" class="form-control form-control-md" required>
                                            <option value="">---Select---</option>
                                            <option value="Business" <?php if ($category == 'Business') echo 'selected'; ?>>Business</option>
                                            <option value="Fashion" <?php if ($category == 'Fashion') echo 'selected'; ?>>Fashion</option>
                                            <option value="Travel" <?php if ($category == 'Travel') echo 'selected'; ?>>Travel</option>
                                            <option value="Sports" <?php if ($category == 'Sports') echo 'selected'; ?>>Sports</option>
                                            <option value="Technology" <?php if ($category == 'Technology') echo 'selected'; ?>>Technology</option>
                                            <option value="Other" <?php if ($category == 'Other') echo 'selected'; ?>>Other</option>
                                        </select>
                                    </div>
                                </div>
                                <hr class="mx-n3">
                                <div class="row align-items-center py-3">
                                    <div class="col-md-3 ps-5">
                                        <h6 class="mb-0">Title</h6>
                                    </div>
                                    <div class="col-md-9 pe-5">
                                        <input type="text" class="form-control form-control-md" name="title" id="title" placeholder="Write your Blog Title Here" value="<?php echo $title; ?>" required />
                                    </div>
                                </div>
                                <hr class="mx-n3">
                                <div class="row align-items-center py-3">
                                    <div class="col-md-3 ps-5">
                                        <h6 class="mb-0">Blog</h6>
                                    </div>
                                    <div class="col-md-9 pe-5">
                                        <textarea class="form-control" name="blog_description" rows="3" placeholder="Write your Blog Here" style="resize: none;"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                                <hr class="mx-n3">
                                <hr class="mx-n3">
                                <div class="px-5 py-4">
                                    <button type="submit" name="update" class="btn btn-primary btn-lg" id="update_blog">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </form>
    <!-- ----------------Form Ends Here---------- -->
</body>

</html>