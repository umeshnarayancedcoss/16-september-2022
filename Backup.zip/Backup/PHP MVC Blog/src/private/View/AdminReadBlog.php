<?php
// starts starts here--------------
session_start();
include("../config/config.php"); //database connectivity file-------
include("AdminMenu.php"); //Linking User NavBar
$blog_id = $_REQUEST['blog_id'];
// Query for fetching blog data with the help of blog_id------------
$blog = Blog::find('all', array('conditions' => array('blog_id' => $blog_id)));
foreach ($blog as $key => $value) {
    $title = $value->title;
    $image = $value->image;
    $postedby = $value->posted_by;
    $description = $value->description;
    $posteddate = $value->date;
}
?>
<!-- ------HTML Code starts here---------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title;  ?></title>
</head>

<body>
    <!-- -------Div for showing blog ---------- -->
    <div class="container" style="margin-top:80px;">
        <div class="col-sm-12" style="min-height:500px;">
            <div class="row" style="height:250px;">
                <div class="col-sm-5">
                    <img src="../../public/images/<?php echo $image ?>" style="height:250px;width:100%;border-radius:20px;border:1px solid;">
                </div>
                <div class="col-sm-7">
                    <p class="card-title" style="font-size:35px;"><?php echo $title ?></p>
                    <p style="margin-top: 60px"> Posted By- <b><?php echo $postedby; ?></b>, Posted Date- <b><?php echo $posteddate; ?></b>
                        <a href="../View/AdminDashboard.php" style="margin-left:25px;">Back to Home Page</a>
                    </p>
                </div>
            </div>
            <div class="row" style="min-height:auto;margin-top:4%;border-radius:5px;">
                <p align="justify" style="font-size:20px;"><?php echo $description; ?></p>
            </div>
        </div>
    </div>
</body>

</html>