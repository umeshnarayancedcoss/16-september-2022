-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql-server
-- Generation Time: Nov 22, 2022 at 06:15 AM
-- Server version: 8.0.19
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `MVC_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int NOT NULL,
  `admin_email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_email`, `password`, `status`) VALUES
(1, 'admin@gmail.com', 'admin', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `blog_id` int NOT NULL,
  `user_id` int NOT NULL,
  `posted_by` varchar(20) NOT NULL,
  `category` varchar(60) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `image` varchar(60) NOT NULL,
  `date` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`blog_id`, `user_id`, `posted_by`, `category`, `title`, `description`, `image`, `date`, `status`) VALUES
(7, 1, 'Umesh Narayan', 'Technology', 'Stay in the Present with these 10 Technology Blogs', 'Professionals in almost every industry have trouble keeping up to date with changing tech trends. So, the best and the only way to stay relevant with technology is through the information available online!\r\n\r\nSo, if you want intuitive articles along with insights from the tech industry, you need to read blogs that are consistently updated by people that know about the trends, and market, and care about giving quality content to their readers. \r\nThis unique blog is dedicated to modern life and the technology industry and answers every question related to tech trends, gadget reviews, and the latest updates.\r\n\r\nWired is ranked as one of the best tech blogs for professionals in every industry and delivers great ideas for presenting the most relevant topics to your audience.', 'download (3).jpeg', '21/11/22', 'Show'),
(8, 1, 'Umesh Narayan', 'Fashion', '21 Trendiest Fashion Blogs to Follow in 2023', 'A fashion blog can cover many topics, such as specific items of clothing and accessories, beauty tips, trends in various apparel markets (haute couture, prêt-à-porter, etc.), celebrity fashion choices, and street fashion trends.[1][2] They cover fashion at all levels, from the largest fashion design houses to the smallest independent designers.[2]\r\n\r\nMany fashion blogs can also be categorized as shopping blogs, similar to the content of fashion magazines. Some retailers in the fashion industry have started blogs to promote their products.', 'download (4).jpeg', '21/11/22', 'Show'),
(9, 2, 'Adarsh Singh', 'Business', '9 Steps to Market and Grow Your Blog', 'Make your layout easy to understand. You want your audience to quickly and easily understand what you offer. You should always ask yourself: “If I were my ideal reader, would I LOVE my website? Would I easily understand what it was about?” If the answer is no to either of those questions, then you need to re-do the look of your site.\r\n\r\nHave clear navigation. Make sure that your navigation bar, the content you offer and the general aesthetic of the whole site are all relatable. They need to work together as a whole: if they don’t, your reader will most likely close the window straight away.\r\n\r\nDon’t forget the search box. Put your search box somewhere clearly visible. It’s the easiest way for your readers to find the content they want, so force it into their attention.\r\n\r\n', 'download (5).jpeg', '21/11/22', 'Show'),
(13, 1, 'Umesh Narayan', 'Travel', '20 Most Beautiful Travel Blogs In 2022', ' Due to how popular this article has become, I have decided to keep this article alive and will continue to add more beautiful travel blogs as I discover it.\r\n\r\n2020 has come, maybe not with a bang as a lot of us may have hoped, but the world goes on and as such I have decided to extend this most beautiful travel blogs list even further with 6 new travel blogs to check out, bringing it to 20, a perfect number for the 2020 year. Without further ado, let\'s check out all the beautiful travel blogs out there.\r\n\r\nAs some of you may know, I have been in the design industry for the past 10 years working as a freelance designer in various companies while also running this blog. In fact, the majority of my income is mostly from my design freelance work over at The Pete Design.', 'download (6).jpeg', '21/11/22', 'Show'),
(14, 5, 'Abhishek Singh', 'Business', 'Distribution of national income needs policy intervention', 'The Indian digital banking sector is one of the fastest growing sectors in the country. What used to be largely unorganized has seen a lot of progress and unprecedented growth in the last decade. Tortuous negotiations at COP27 yielded an important breakthrough – the agreement to set up a loss and damage fund, often referred to as climate compensation fund. As per CMIE Report, in FY-2021-22, average monthly income of a regular salaried employee was about Rs 22,000, a self-employed person Rs 11,200 and a daily-wage worker was Rs 9,800.', 'download (7).jpeg', '21/11/22', 'Show'),
(15, 5, 'Abhishek Singh', 'Sports', 'Word Cup beyond expectations 2022', 'The whole of India is sad after experiencing the drubbing we had during the world cup semifinals versus England.  We are experiencing the same fate in Cricket as English Soccer hosting the biggest soccer league but,Back in 2016, a Pakistani comedian made an appearance at a local event in Zimbabwe impersonating the beloved comedy character Mr Bean. The penny soon dropped that the Pakistani gentleman was not.', 'images.jpeg', '21/11/22', 'Show'),
(16, 2, 'Adarsh Singh', 'Fashion', 'How to Start a Fashion Blog – Step by Step', 'Are you looking to start a fashion blog but don’t know where to begin? It is easy to start a blog, but the difficult part is to be successful and make money from it. In this article, we will show you how to start a fashion blog as well as share tips on how to make money from your fashion blog. f you are passionate about fashion and style, then you must have seen some top fashion bloggers and influencers on Instagram.\r\n\r\nThese fashion blogs not only provide a platform to the bloggers, but they also bring lots of opportunities their way. You will be surprised to discover the many ways fashion bloggers make money from their blogs.\r\n\r\nAccording to Harper’s Bazaar, designers and top brands spend over a BILLION dollar each year advertising on Instagram alone.', 'startfashionblog1.jpg', '21/11/22', 'Show');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int NOT NULL,
  `cat_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`) VALUES
(1, 'Travel'),
(2, 'Fashion'),
(3, 'Technology'),
(4, 'Sports'),
(5, 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `email`, `mobile`, `password`, `status`) VALUES
(1, 'Umesh Narayan', 'srivastavau215@gmail.com', '9140843718', '1234', 'Approved'),
(2, 'Adarsh Singh', 'adarsh@gmail.com', '8745698563', '1234', 'Approved'),
(5, 'Abhishek Singh', 'abhishek@gmail.com', '9856987456', '1234', 'Approved'),
(6, 'Rupesh Kumar', 'rupesh@gmail.com', '8745325689', '1234', 'Requested'),
(7, 'Satyam Kumar', 'satyam@gmail.com', '78965412', '1234', 'Requested'),
(8, 'Mohit Singh', 'mohit@gmail.com', '8569874563', '1234', 'Requested'),
(9, 'Pankaj Kumar', 'pankaj@gmail.com', '9874563255', '1234', 'Approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `blog_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
