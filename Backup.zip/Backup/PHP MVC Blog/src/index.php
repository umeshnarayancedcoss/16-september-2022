<?php
// Redirecting to indexPage.php in View Section---
header("location:./private/View/indexPage.php");
