<?php
// Redirecting to AdminLogin.php in View Section---
header("location:../private/View/AdminLogin.php");
