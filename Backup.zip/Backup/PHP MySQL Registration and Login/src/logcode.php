<?php
// session starts here-----
session_start();
include("./config.php"); //including database connectivity file----
if (isset($_POST)) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $query = "select email,pass from user where email = '$email' and pass = '$password'"; //query for getting email password-
    $res = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_array($res, MYSQLI_BOTH)) {
        $_SESSION['user'] = $email; //creating user session or mail id-------
        header("location:profile.php"); // redirect to profile dashboard-----
    } else { //if password and repeat password will be not same --------
        $msg = "Error: Wrong Email ID or Password.!!";
        header("location:login.php?msg=$msg");
    }
}
