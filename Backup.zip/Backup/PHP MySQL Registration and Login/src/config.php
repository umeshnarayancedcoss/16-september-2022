<?php
$servername = "mysql-server";
$username = "root";
$password = "secret";
$database = "mydb";
// Create connection
$conn = new mysqli($servername, $username, $password, $database);
