<?php
include("./config.php"); //including database connectivity file---------
if (isset($_POST)) {
    // storing form values into variables------
    $name = $_POST['name'];
    $email = $_POST['email'];
    $user_password = $_POST['password'];
    $cnfpassword = $_POST['cnfpassword'];
    // if password and repeat password will be same----
    if ($user_password == $cnfpassword) {
        $query = "INSERT INTO user (id,name,email, pass) VALUES (NULL, '$name', '$email', '$user_password')"; //insertion query for storing data into database table--
        mysqli_query($conn, $query);
        echo "<script>alert('Registered Successfully.!!');window.location.href='login.php';</script>"; //after registed successfully, redirected to login page---
    } else { //if password and repeat password will not be same---
        $msg = "Error: Password Not Matched";
        header("location:index.php?msg=$msg");
    }
}
