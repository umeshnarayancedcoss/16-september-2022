<?php
// session starts here---------
session_start();
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:login.php");
}
include("./config.php"); //including database connectivity file-----
$email = $_SESSION['user'];
$query = "SELECT * FROM user where email = '$email'"; //generating query for user detail----
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // storing user details into variables--------
        $id =  $row["id"];
        $name = $row["name"];
        $email = $row["email"];
        $password = $row["pass"];
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Welcome <?php echo $name; ?></title>
    <style>
        body {
            background-color: lightskyblue;
        }
    </style>
</head>

<body>
    <center>
        <h1>Welcome <?php echo $name; ?></h1>
    </center>
    <center>
        <p>We are delighted to have you among us. On behalf of all the members and the management, we would like to extend our warmest welcome and good wishes!</p>
    </center>
    <br><br>
    <!-- table for displaying user detail -->
    <table border="1px" cellpadding="5px" align="center" style="background-color: pink;">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
        </tr>
        <tr>
            <td><?php echo $id; ?></td>
            <td><?php echo $name; ?></td>
            <td><?php echo $email; ?></td>
            <td><?php echo $password; ?></td>
        </tr>
    </table>
    <br><br>
    <center><a href="logout.php"><button type="button" class="btn btn-outline-danger">Logout</button></a></center>
</body>

</html>