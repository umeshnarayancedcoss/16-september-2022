<?php
$msg = $_REQUEST['msg']; //storing error msg in a variable-----
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Login</title>
</head>

<body>
    <!-- Pills content -->
    <div class="tab-content">
        <div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
            <form action="logcode.php" method="POST">

                <h1 style="margin-left:25%;">Login Here</h1>

                <!-- Email input -->
                <div class="form-outline mb-4">
                    <center><input type="email" id="loginName" class="form-control" name="email" required style="width:50%;" /></center>
                    <label class="form-label" for="loginName" style="margin-left:25%;">Email or username</label>
                </div>

                <!-- Password input -->
                <div class="form-outline mb-4">
                    <center> <input type="password" id="loginPassword" class="form-control" name="password" required style="width:50%;" /></center>
                    <label class="form-label" for="loginPassword" style="margin-left:25%;">Password</label><br>
                    <p style="color:red;margin-left:25%;"><?php echo $msg; ?></p><!-- Displaying error message -->
                </div>
                <!-- 2 column grid layout -->
                <div class="row mb-4">
                    <div style="margin-left:40%;">
                        <!-- Checkbox and Forgot Password -->
                        <input class="form-check-input" type="checkbox" value="" id="loginCheck" checked />
                        <label class="form-check-label" for="loginCheck"> Remember me </label><a href="#!" style="margin-left:10px;">Forgot password?</a>
                    </div>
                </div>

                <!-- Submit button -->
                <center><button type="submit" class="btn btn-primary btn-block mb-4" style="width:50%;">Sign in</button></center>

                <!-- Register buttons -->
                <div class="text-center">
                    <p>Not a member? <a href="./index.php">Register</a></p>
                </div>
            </form>
        </div>

    </div>
    <!-- Pills content -->
</body>

</html>