<?php
// session starts here---------
session_start();
session_unset();
session_destroy(); // session destroys here----
header("location:login.php");
