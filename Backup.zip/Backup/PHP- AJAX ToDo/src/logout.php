<?php
// session starts here----
session_start();
// Session destroy here---
session_destroy();
header("location:index.php");
