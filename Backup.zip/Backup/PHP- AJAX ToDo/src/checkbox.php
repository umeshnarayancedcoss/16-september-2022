<?php
// Session starts here-----
session_start();
if (!isset($_SESSION['todo'])) {
    $_SESSION['todo'] = array();
}
$index = $_POST['index'];
// Changing 'incomplete' to 'complete'----
if ($_SESSION['todo'][$index]['status'] == 'incomplete') {
    $_SESSION['todo'][$index]['status'] = 'complete';
} else { // Changing 'complete' to 'incomplete'----
    $_SESSION['todo'][$index]['status'] = 'incomplete';
}
