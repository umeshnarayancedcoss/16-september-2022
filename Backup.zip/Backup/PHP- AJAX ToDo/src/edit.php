<?php
session_start();
$index = $_POST['index'];
$task_name = $_SESSION['todo'][$index]['task_name']; //holding task name into a variable with the help of key index--
echo $task_name;
