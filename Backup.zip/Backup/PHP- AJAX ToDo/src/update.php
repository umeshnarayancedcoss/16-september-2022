<?php
// session starts here-----
session_start();
$index = $_POST['index'];
$task = $_POST['task'];
// assigning new value into todo session array with the help of key index--------
$_SESSION['todo'][$index]['task_name'] = $task;
