<?php
// session starts here-----
session_start();
if (!isset($_SESSION['todo'])) {
    $_SESSION['todo'] = array();
}
// For incomplete tasks-----------
$tablei = ' <ul id="incomplete-tasks">';
foreach ($_SESSION['todo'] as $key => $value) {
    if ($value['status'] == "incomplete") { //checking task is incomplete or not----
        $tablei .= '   <li><input type="checkbox" class="cb" id=' . $key . ' ><label>' . $value['task_name'] . '</label><button class="edit" id=' . $key . '>Edit</button><button class="delete" id=' . $key . '>Delete</button></li>
            </ul>';
    }
}
// for completed task--------------
$tablec = '<h3>Completed</h3>';
$tablec .= ' <ul id="completed-tasks">';
foreach ($_SESSION['todo'] as $key => $value) {
    if ($value['status'] == "complete") { //checking task is complete or not-------
        $tablec .= '   <li><input type="checkbox" class="cb" id=' . $key . ' checked><label>' . $value['task_name'] . '</label><button class="edit" id=' . $key . '>Edit</button><button class="delete" id=' . $key . '>Delete</button></li>
         </ul>';
    }
}
echo $tablei . $tablec;
