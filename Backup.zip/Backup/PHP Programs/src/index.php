<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Programs</title>
</head>
<body>
    <!-- ----------------------------------Program Starting Here--------------------------------------- -->
    <h3>Write a program to print 2 php variables using single echo statement.</h3>
    <?php
    
   $x="Hello";
   $y="PHP";
   echo "$x $y";
    ?>
    <hr>
 <!-- ------------------------------------------------------------------------------------------------------------ -->

 <h3>Write a program to perform sum or addition of two numbers in PHP programming.</h3>
 <?php  
$x=15;  
$y=30;  
$z=$x+$y;  
echo "Sum= ",$z;  
?>  
<hr>
<!-- ------------------------------------------------------------------------------------------------------------ -->
<h3>Write a program to check student grade based on the marks using if-else statement.</h3>
 
<?php

$percentage=87.7;

if($percentage>=60){
    echo "First Division";
}else if($percentage>=45 && $percentage<60){
echo "Second Division";
}else if($percentage>=33 && $percentage<45){
    echo "Third Division";
}else{
    echo "Fail";
}
?>
<hr>
<!-- --------------------------------------------------------------------------------------------------------------- -->
<h3>Write a program to show day of the week (for example: Monday) based on numbers using switch/case statements.</h3>

<?php
$day = "5";

switch ($day) {
    case "1":
        echo "Monday";
        break;
    case "2":
        echo "Tuesday";
        break;
    case "3":
        echo " Wednesday";
        break;
	case "4":
        echo "Thursday";
        break;
    case "5":
        echo "Friday";
        break;
    case "6":
        echo "Saturday";
        break;
	case "7":
        echo "Sunday";
        break;
    default:
        echo "Invalid Number";
}
?>
<hr>
<!-- ----------------------------------------------------------------------------------------------- -->
<h3>Write a Program to display count, from 5 to 15 using PHP loop as given below.</h3>


<?php
for($i=5;$i<=15;$i++){
    echo $i.'<br/>';
}
?>

<hr>
<!-- ------------------------------------------------------------------------------------------------- -->
<h3>Write a program to print “Welcome to the PHP World” using some part of the text in variable & some part directly in echo.</h3>

<?php

$a="Welcome";
$b="PHP";
echo "$a to the $b World";

?>
<hr>
<!-- --------------------------------------------------------------------------------------------------------- -->
<h3>Write a program to calculate factorial of a number using for loop in php.</h3>

<?php  
$num = 5;  
$factorial = 1;  
for ($x=$num; $x>=1; $x--)   
{  
  $factorial = $factorial * $x;  
}  
echo "Factorial of $num is $factorial";  
?>  
<hr>
<!-- -------------------------------------------------------------------------------------------------------------- -->

<h3>Write a PHP program using nested for loop that creates a chess board</h3>

<table width="400px" cellspacing="0px" cellpadding="0px" border="1px solid">
<?php
for($row=1;$row<=8;$row++)
{
	echo "<tr>";
	for($column=1;$column<=8;$column++)
	{
		$total=$row+$column;
	    if($total%2==0)
		{
			echo "<td height=30px width=30px bgcolor=white></td>";
		}
	    else
		{
			echo "<td height=30px width=30px bgcolor=black></td>";
		}
	}
	echo "</tr>";
}
?>
</table>
<!-- ---------------------------------------------//END\\------------------------------------------------------ -->


</body>
</html>