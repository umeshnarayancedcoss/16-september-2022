// ---Check Function Starts Here--------------
function check() {
    // Holding input fields values into variables----
    var age = document.getElementById('age').value;
    var weight = document.getElementById('weight').value;
    // Switch case for age and weight starts here-------
    switch (true) {
        // For Blank Fields-----
        case (age == "" && weight == ""):
            alert("Please fill all the fields.!!");
            break;
        // For minimum age-----
        case (age < 5):
            alert("Minimum age should be 05");
            break;
        // For maximum age---
        case (age > 20):
            alert("Maximum age should be 20");
            break;
        // Normal weight condition------
        case ((age >= 5 && age <= 7) && (weight >= 15 && weight <= 20) ||
            (age >= 8 && age <= 10) && (weight >= 21 && weight <= 25) ||
            (age >= 11 && age <= 15) && (weight >= 26 && weight <= 30) ||
            (age >= 16 && age <= 20) && (weight >= 31 && weight <= 40)
        ):
            alert("Normal Weight");
            break;
        // Under weight condition-----
        case ((age >= 5 && age <= 7) && (weight < 15) ||
            (age >= 8 && age <= 10) && (weight < 21) ||
            (age >= 11 && age <= 15) && (weight < 26) ||
            (age >= 16 && age <= 20) && (weight < 31)
        ):
            alert("Under Weight");
            break;
        //  Over weight condition------
        case ((age >= 5 && age <= 7) && (weight > 20) ||
            (age >= 8 && age <= 10) && (weight > 25) ||
            (age >= 11 && age <= 15) && (weight > 30) ||
            (age >= 16 && age <= 20) && (weight > 40)
        ):
            alert("Over Weight");
        default:
            break;
    }

}