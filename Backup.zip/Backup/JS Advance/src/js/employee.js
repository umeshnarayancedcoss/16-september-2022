// --Import Export in Js--//
const id = "4";
const name = "Jesse";
const salary = 10000;
export {id, name, salary};