///-----Starting an array with static data object---------/////////
let data_array = [
    { "id": 1, "name": "John", "salary": 8000, "index": 0 },
    { "id": 2, "name": "Mark", "salary": 9000, "index": 1 },
    { "id": 3, "name": "Yash", "salary": 7000, "index": 2 },

];
//console.log(data_array);

///////--------Displaying static array-----------////////////////////////
//var x = 3;
var str = "<table border='1px solid black'><tr><th>ID</th><th>Name</th><th>Total Salary</th><th>Action</th></tr>"
data_array.forEach(element => {

    if (element.salary <= 0)
        debugger;   //Debugger on displaying static array objects

    else {

        str += "<tr><td>" + element.id + "</td><td>" + element.name + "</td><td>" + element.salary +
            "</td><td><button onclick='del(" + element.index + ")'>Delete</button></td></tr>"

        str += "</table>"

        // console.log(str);
        document.getElementById('table').innerHTML = str;
    }
})

/////////////////-----------Add function for adding a value in array by form-----------//////////////////////////

//let x = 0;
function add() {
    //alert('ok');

    var id = document.getElementById('id').value;
    //alert(id);
    var name = document.getElementById('name').value;
    //alert(name);
    var salary = document.getElementById('salary').value;
    //alert(salary);

    const message = document.getElementById("demo");
    message.innerHTML = "";
    var x = 3;
    //object creation
    var object = { id: id, name: name, salary: salary, index: x };
    x++;
    //console.log(object);

    //////--starting Try, Catch and Throw for form validation--------------/////////////

    try {
        //var regName = /^[a-zA-Z]+( [a-zA-Z]+)+$/;
        if (id == "" || name == "" || salary == "") throw "All fields must be filled";
        if (!isNaN(name)) throw "Name should not a number";
        if (name.length < 3) throw "Name must be atleast 3 characters";
        // if(!regName.test(name)) throw "Please Enter Valid Name";
        if (id < 1) throw "Please Enter Valid ID value.";
        if (salary < 1) throw "Salary should be greater zero";

        // pushing object values in an array
        data_array.push(object);

        //    showing result in table tag
        var index = 0;
        var str = "<table border='1px solid black'><tr><th>ID</th><th>Name</th><th>Total Salary</th><th>Action</th></tr>"
        data_array.forEach(element => {

            str += "<tr><td>" + element.id + "</td><td>" + element.name + "</td><td>" + element.salary +
                "</td><td><button onclick='del(" + index++ + ")'>Delete</button></td></tr>"

            str += "</table>"
            // console.log(str);
            // console.log(str);
            document.getElementById('table').innerHTML = str;

        })
        //    after 1 entry input box will be blank
        var id = document.getElementById('id').value = "";
        var name = document.getElementById('name').value = "";
        var salary = document.getElementById('salary').value = "";
    }
    catch (err) {
        message.innerHTML = "" + err;
    }

}
// console.log(data_array)
//////////////////////////////////////////////////delete function////////////////////////////////
function del(index) {
    // console.log(data_array);
    console.log(index);

    if (data_array.length == 0) {
        document.getElementById("table").style.display = "none";
    }
    else {
        data_array.splice(id, 1);

 
        var str = "<table border='1px solid black'><tr><th>ID</th><th>Name</th><th>Total Salary</th><th>Action</th></tr>"
        data_array.forEach(element => {


            str += "<tr><td>" + element.id + "</td><td>" + element.name + "</td><td>" + element.salary +
                "</td><td><button onclick='del(" + element.index + ")'>Delete</button></td></tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;

        })
    }


}
////////////////////////////////////Class and object//////////////////////////////////
class Employee {
    constructor(id, name, totalsalary) {
        this.id = id;
        this.name = name;
        this.totalsalary = totalsalary;
        this.index = 0;
    }
}

const emp = new Employee(1, "John", 8000, 0);
var str = "<table><tr><th>ID</th><th>Name</th><th>Total Salary</th></tr>"
str += "<tr><td>" + emp.id + "</td><td>" + emp.name + "</td><td>" + emp.totalsalary +
    "</td></tr>"
str += "</table>"
// console.log(str);
document.getElementById('t_class').innerHTML = str;

////////---Use objects of the above declared class to add employee details in to a JSON array object.-----//////

var object = { id: emp.id, name: emp.name, salary: emp.totalsalary, index: emp.index };
console.log(object);

data_array.push(object);
//console.log(data_array);

//    showing result in table tag
var str = "<table border='1px solid black'><tr><th>ID</th><th>Name</th><th>Total Salary</th></tr>"
data_array.forEach(element => {

    str += "<tr><td>" + element.id + "</td><td>" + element.name + "</td><td>" + element.salary +
        "</td></tr>"

    str += "</table>"

    // console.log(str);
    document.getElementById('js_object').innerHTML = str;

})

///////---Use 'this' keyword to display the employee details (stored in JSON array) on the HTML page.----////////////
class Employee1 {
    constructor(id, name, totalsalary) {
        this.id = id;
        this.name = name;
        this.totalsalary = totalsalary;
        this.index = 0;
    }
}

const emp1 = new Employee1(1, "John", 8000, 0);

var object = { id: emp1.id, name: emp1.name, salary: emp1.totalsalary, index: emp1.index };
console.log(object);

data_array.push(object);
//console.log(data_array);

//    showing result in table tag
var str = "<table border='1px solid black'><tr><th>ID</th><th>Name</th><th>Total Salary</th></tr>"
data_array.forEach(element => {

    str += "<tr><td>" + element.id + "</td><td>" + element.name + "</td><td>" + element.salary +
        "</td></tr>"

    str += "</table>"

    // console.log(str);
    document.getElementById('this_keyword').innerHTML = str;

})


////////----------Apply proper error handling (try catch) and calculate the salary of an employee as salary * 1.10 and display the employee details with updated salary.-------------////////////////

const message1 = document.getElementById("up_s");
message1.innerHTML = "";

var str = "<table border='1px solid black'><tr><th>ID</th><th>Name</th><th>Total Salary</th><th>Updated Salary</th></tr>"
try {
    if (data_array.salary <= 0) throw "Salary should be greater than or equal to zero";
    data_array.forEach(element => {
        var update_salary = element.salary * 1.10;

        str += "<tr><td>" + element.id + "</td><td>" + element.name + "</td><td>" + element.salary +
            "</td><td>" + update_salary + "</td></tr>"

        str += "</table>"

        // console.log(str);
        document.getElementById('update_salary').innerHTML = str;

    })
}
catch (err) {
    message1.innerHTML = "" + err;
}

////////---Write a JS arrow function to display the employee name and 15% of the salary as output.---////////

var display = () => {

    var str = "<table border='1px solid black'><tr><th>Name</th><th>15% of the Salary</th></tr>"
    data_array.forEach(element => {
        element.salary = (element.salary * 15) / 100;
        str += "<tr><td>" + element.name + "</td><td>" + element.salary + "</td></tr>"
        str += "</table>"

        // console.log(str);
        document.getElementById('arrow_table').innerHTML = str;

    })
}
/////////////////////Change the salary of each employee to 30,000/- with the help of a function in strict mode and display the result.//////////
function s_mode() {
    var str = "<table border='1px solid black'><tr><th>ID</th><th>Name</th><th>Total Salary</th></tr>"
    data_array.forEach(element => {
        "use strict";
        element.salary = 30000;
        str += "<tr><td>" + element.id + "</td><td>" + element.name + "</td><td>" + element.salary + "</td></tr>"
        str += "</table>"

        //console.log(str);
        document.getElementById('strict').innerHTML = str;

    })
}

//////////////////////////----------Script END---------------///////////////////////////////////////////////////









