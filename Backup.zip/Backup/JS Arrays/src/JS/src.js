let cart_array = [];

let data_array = [
    {
        "company": "Samsung", "model": "Galaxy", "memory": "64", "price": "15000", "quantity": "20", "rating": "0"
    },
    {
        "company": "Nokia", "model": "S730", "memory": "128", "price": "22000", "quantity": "15", "rating": "0"
    },
    {
        "company": "Xiaomi", "model": "Note", "memory": "32", "price": "12000", "quantity": "21", "rating": "0"
    },
    {
        "company": "Motoroala", "model": "G10", "memory": "32", "price": "15000", "quantity": "18", "rating": "0"
    },
    {
        "company": "Apple", "model": "S12", "memory": "64", "price": "25000", "quantity": "13", "rating": "0"
    }
];

////////////showing static array data which given in task///////////////////
var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th><th>Rating</th></tr>"
data_array.forEach(element => {
    str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><td>" + element.rating + "</td></tr>"

    str += "</table>"

    // console.log(str);
    document.getElementById('table').innerHTML = str;
})



// starting fun () function
function fun() {

    // receiving all the three values of forms by their ID
    var company = document.getElementById('company').value;
    var model = document.getElementById('model').value;
    var memory = document.getElementById('memory').value;
    var price = document.getElementById('price').value;

    // console.log(pro_id);
    // console.log(pro_name);
    // console.log(pro_price);

    //    Validation for blank fields
    if (company == "" || model == "" || memory == "" || price == "") {
        // if input values are blanks it will give an alert
        alert('Please Fill all the fields');
    }
    else if (price < 1) {
        // if product price is negative value it will give an alert
        alert('Please Fill Valid Product Price');
    } else {
        //  if all validation conditions satisfied then below code will be execute.

        //object creation
        var object = { company: company, model: model, memory: memory, price: price, quantity: '10', rating: '0' };
        //console.log(object);
        // pushing object values in an array
        data_array.push(object);

        //    showing result in table tag
        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th><th>Rating</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><td>" + element.rating + "</td></tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
        //    after 1 entry input box will be blank
        var company = document.getElementById('company').value = "";
        var model = document.getElementById('model').value = "";
        var memory = document.getElementById('memory').value = "";
        var price = document.getElementById('price').value = "";
    }
    //console.log(data_array);
}
///////////////////////////////////////////////////////////////////////////////////////////

function pricerange() {
    var minprice = document.getElementById('minprice').value;
    //console.log(minprice);
    //alert(minprice);
    var maxprice = document.getElementById('maxprice').value;
    //alert(maxprice);

    // showing result in table tag
    var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory</th><th>Price</th></tr>"
    data_array.forEach(element => {
        if ((element.price >= minprice) && (element.price <= maxprice)) {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><tr>"

            str += "</table>"

            //  console.log(element.price);

            document.getElementById('pricerange').innerHTML = str;
        }
    })


}


/////////////////////////////////////////////////////////////////////////////////////////

function textsearch() {

    var select = document.getElementById('select').value;
    var text = document.getElementById('text').value;
    // alert(select);

    var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory</th><th>Price</th><th>Quantity</th></tr>"
    data_array.forEach(element => {
        if (select == "company" && element.company == text) {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(element.company);
            document.getElementById('table').innerHTML = str;
        }
        if (select == "model" && element.model == text) {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(element.model);
            document.getElementById('table').innerHTML = str;
        }
        if (select == "memory" && element.memory == text) {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(element.company);
            document.getElementById('table').innerHTML = str;
        }
        if (select == "price" && element.price == text) {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            //  console.log(element.price);
            document.getElementById('table').innerHTML = str;
        }
    })



}
///////////////////////////////////////////////////////////////////////////////

function change() {

    var sort = document.getElementById('sort').value;
    // alert(sort);
    var items = document.getElementById('items').value;
    //alert (items);


    ///ascending order
    if (sort == "Ascending" && items == "Company") {
        data_array.sort(function (a, b) {
            return a.company.localeCompare(b.company)
        });
        console.table(data_array);

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }

    if (sort == "Ascending" && items == "Model") {
        data_array.sort(function (a, b) {
            return a.model.localeCompare(b.model)
        });
        //  console.table(data_array);

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }

    if (sort == "Ascending" && items == "Memory") {
        data_array.sort(function (a, b) {
            return a.memory.localeCompare(b.memory)
        });
        //console.table(data_array);

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }

    if (sort == "Ascending" && items == "Price") {
        data_array.sort((a, b) => a.price - b.price);

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }

    if (sort == "-Sort-" && items == "-Sort By-") {
        window.style.display = "none";
    }

    //des ord
    if (sort == "Descending" && items == "Company") {
        data_array.sort((a, b) => (b.company.localeCompare(a.company)));
        // console.table(data_array);

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }

    if (sort == "Descending" && items == "Model") {
        data_array.sort((a, b) => (b.model.localeCompare(a.model)));
        // console.table(data_array);

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }

    if (sort == "Descending" && items == "Memory") {
        data_array.sort((a, b) => (b.memory.localeCompare(a.memory)));
        //   console.table(data_array);

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }

    if (sort == "Descending" && items == "Price") {
        data_array.sort((a, b) => b.price - a.price);

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Quantity</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }


}

//////////////////////////////////--Delete Rows with Checkboxes--///////////////////////////////////////

var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)</th><th>Action</th></tr>"

data_array.forEach(element => {

    //objIndex3 = data_array.findIndex((obj => obj.model == element.model));
    //console.log(objIndex3);

    str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td><input type='checkbox' ></td><tr>"

    str += "</table>"

    // console.log(i);
    document.getElementById('check').innerHTML = str;
})
function del() {
    //alert('done');
    // const cb = document.querySelector('#cbox');
    //   console.log(cb.checked);   

    document.querySelectorAll("#check input:checked").forEach(e => {
        e.parentNode.parentNode.remove();
    })
    

}



/////////////////////////////---Upadte product quantity code---/////////////////////////////////////////////

function update() {

    var select_m = document.getElementById('select_m').value;
    //alert(select_m);
    var u_quantity = document.getElementById('u_quantity').value;
    //  alert(u_quantity);
    if (u_quantity < 0 || u_quantity == "") {
        alert('Please enter valid value.');
    }
    else {
        objIndex = data_array.findIndex((obj => obj.model == select_m));
        //  console.log(objIndex);
        data_array[objIndex].quantity = u_quantity;
        // console.log("After update: ", data_array[objIndex])

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)<th>Quantity</th><th>Rating</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><td>" + element.rating + "</td></tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })
    }

}

///////////////////////////////----Rating a product code-----///////////////////////////////////////////////

function rate() {
    var product = document.getElementById('product').value;
    // alert(product);
    var rating = document.getElementById('rating').value;
    // alert(rating);

    objIndex1 = data_array.findIndex((obj => obj.model == product));
    //console.log(objIndex1);
    data_array[objIndex1].rating = rating;
    // console.log("After update: ", data_array[objIndex])

    var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)<th>Quantity</th><th>Rating</th></tr>"
    data_array.forEach(element => {
        str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><td>" + element.rating + "</td></tr>"

        str += "</table>"

        // console.log(str);
        document.getElementById('table').innerHTML = str;
    })


}

////////////////////////////Add to Cart and Bill///////////////////////////////////////

function add() {
    var select_model = document.getElementById('select_model').value;
    //alert(select_model);
    var c_quantity = document.getElementById('c_quantity').value;
    // alert(c_quantity);

    objIndex2 = data_array.findIndex((obj => obj.model == select_model));
    // console.log(objIndex2);
    var t_quantity = data_array[objIndex2].quantity;
    // console.log(t_quantity);
    var price = data_array[objIndex2].price;
    // console.log(price);
    var company = data_array[objIndex2].company;
    //console.log(company);
    var update_quantity = t_quantity - c_quantity;
    // console.log(update_quantity);
    data_array[objIndex2].quantity = update_quantity;

    // console.log("After update: ", data_array[objIndex])

    if (c_quantity > t_quantity || c_quantity == "") {
        alert('Cart Quantity should be less than Available Quantity or Please enter a value');
    }
    else {
        var object = { company: company, model: select_model, quantity: c_quantity, price: price };
        //console.log(object);
        // pushing object values in an array
        cart_array.push(object);
        // console.log(cart_array);

        //data_array.model.quantity

        var str = "<table border='1px solid black'><tr><th>Company</th><th>Model</th><th>Memory(GB)</th><th>Price(Rs)<th>Quantity</th><th>Rating</th></tr>"
        data_array.forEach(element => {
            str += "<tr><td>" + element.company + "</td><td>" + element.model + "</td><td>" + element.memory + "</td><td>" + element.price + "</td><td>" + element.quantity + "</td><td>" + element.rating + "</td></tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('table').innerHTML = str;
        })


        // //    showing result in table tag
        var str = "<table><tr><th>Description</th><th>Quantity</th><th>Amount</th></tr>"
        cart_array.forEach(element => {
            str += "<tr><td>" + element.company + ' ' + element.model + "</td><td>" + element.quantity + "</td><td>" + element.price + "</td></tr>"

            str += "</table>"

            // console.log(str);
            document.getElementById('cart').innerHTML = str;
        })

    }


}

///////////////------code for generate bill----//////////////////////////////////
function bill() {
    var sum = 0;
    cart_array.forEach(element => {
        sum += element.price * element.quantity;
    })
    // console.log(sum);
    var str = "<table><tr><th>Description</th><th>Quantity</th><th>Amount</th></tr>"
    cart_array.forEach(element => {
        str += "<tr><td>" + element.company + ' ' + element.model + "</td><td>" + element.quantity + "</td><td>" + element.price + "</td></tr>"


        // console.log(str);
    })
    str += "<tr><td>Total</td><td></td><td>" + sum + "</td></tr>"
    str += "</table>"
    document.getElementById('cart').innerHTML = str;
    sum = 0;
    cart_array = [];


}