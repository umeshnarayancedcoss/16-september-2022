<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Arrays</title>
</head>

<body>
<!-- ----------------------------------Program 1------------------------------------------------ -->
    <h3>Write a PHP script that inserts a new item in an array in any position</h3>
    <?php
    $array = array('1', '2', '3', '4', '5');
    //print_r($array);
    echo "Original Array:<br/> ";
    foreach ($array as $x) {
        echo "$x ";
    }
    echo "\n";

    $n = 7;
    $position = 3;
    array_splice($array, $position, 0, $n);
    echo "<br/>After inserting '7' in the array is:<br/>";
    foreach ($array as $x) {
        echo "$x ";
    }

    ?>
    <hr>
    <!-- -------------------------------------------------Program 2---------------------------------------- -->

    <h3>Write a PHP script to calculate and display average temperature, five lowest and highest temperatures.</h3>
    <?php
    $temp = array(78, 60, 62, 68, 71, 68, 73, 85, 66, 64, 76, 63, 75, 76, 73, 68, 62, 73, 72, 65, 74, 62, 62, 65, 64, 68, 73, 75, 79, 73);
    $average = array_sum($temp) / count($temp);
    echo "Average Temperature is: $average <br/>";
    asort($temp, SORT_NUMERIC);
    $lowest = (array_slice($temp, 0, 7, true));
    echo " List of seven lowest temperatures : ";
    foreach ($lowest as $x) {
        echo "$x ";
    }
    echo "<br/>";
    rsort($temp);
    $greatest = (array_slice($temp, 0, 7, true));
    echo " List of seven greatest temperatures : ";
    foreach ($greatest as $x) {
        echo "$x, ";
    }
    ?>
    <hr>
    <!-- ------------------------------Program 3---------------------------------------------------------------------- -->
    <h3>Write a PHP program to filter out some elements with certain key-names.</h3>
    <?php
    $arr1 = array('c1' => 'Red', 'c2' => 'Green', 'c3' => 'White', 'c4' => 'Black');
    $arr2 = array('c2', 'c4');
    $f_result = array_diff_key($arr1, array_flip($arr2));
    print_r($f_result);
    ?>
    <hr>
    <!-- ----------------------------Program 4-------------------------------------------------------------- -->

    <h3>Write a PHP script to delete a specific value from an array using array_filter() function.</h3>
    <?php
    $number = array(1, 2, 3, 4, 5);
    echo "Original Array:<br/>";
    foreach ($number as $x) {
        echo "$x ";
    }
    echo "<br/> Array Filter for odd numbers <br/>";

    $odd_number = array_filter($number, function ($number) {
        return $number % 2 == 1;
    });
    print_r($odd_number);
    echo"<hr/>";
    ?>
<!-- ------------------------------------------------------------------------------------------------------------------ -->
</body>
</html>