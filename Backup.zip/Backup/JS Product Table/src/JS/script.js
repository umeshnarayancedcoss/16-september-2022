let data_array=[];
// staring fun () function
function fun(){
    
// receiving all the three values of forms by their ID
    var pro_id=document.getElementById('pro_id').value;
    var pro_name=document.getElementById('pro_name').value;
    var pro_price=document.getElementById('pro_price').value;

   // console.log(pro_id);
   // console.log(pro_name);
   // console.log(pro_price);

//    Validation for blank fields
    if(pro_id=="" || pro_name=="" || pro_price=="" ){
         // if input values are blanks it will give an alert
    alert('Please Fill all the fields');
}
else if (pro_price<1){
    // if product price is negative value it will give an alert
    alert('Please Fill Valid Product Price');
} else {
    //  if all validation conditions satisfied then below code will be execute.

        //object creation
   var object={pro_id:pro_id, pro_name:pro_name, pro_price:pro_price};
   console.log(object);
// pushing object values in an array
   data_array.push(object);

//    showing result in table tag
    var str="<table border='1'><tr><th>Product Id</th><th>Product Name</th><th>Product Price</th></tr>"
   data_array.forEach(element=>{
    str+="<tr><td>"+element.pro_id+"</td><td>"+element.pro_name+"</td><td> USD "+element.pro_price+"</td><tr>" 

    str+="</table>"

    console.log(str);
    document.getElementById('table').innerHTML=str;
   })
//    after 1 entry input box will be blank
   var pro_id=document.getElementById('pro_id').value="";
    var pro_name=document.getElementById('pro_name').value="";
    var pro_price=document.getElementById('pro_price').value="";

} 
   
}