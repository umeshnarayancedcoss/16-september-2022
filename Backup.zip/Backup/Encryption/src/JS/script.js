const arr_text = [];
function fun() {

    var text = document.getElementById('text').value;

    const arr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];

    arr_text.push(text);
    //console.log(arr_text);
    var i = 0;
    arr_text.forEach(element => {
        arr_text[i]; {
            i++;
        }
        console.log(arr_text);
    });


}