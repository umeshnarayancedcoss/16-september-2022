<?php
// session starts here--------
session_start();
$email = $_SESSION['user'];
include("./config/config.php"); //database connectivity---------
$blog_id = $_REQUEST['blog_id']; //holding blog id-------
if (isset($_POST)) {
    // holding updated data into variables----------
    $category = $_POST['category'];
    $title = $_POST['title'];
    $description = $_POST['blog_description'];
    // Query for upadting values in blog table------------
    $query = "UPDATE `tbl_blog` SET `category` = '$category', `title` = '$title', `description` = '$description' WHERE `tbl_blog`.`blog_id` = $blog_id";
    mysqli_query($conn, $query); //executing query
    echo "<script>alert('Blog Updated Successfully.!!');window.location.href='myblog.php';</script>";
}
