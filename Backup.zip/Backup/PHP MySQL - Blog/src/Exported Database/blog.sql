-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql-server
-- Generation Time: Nov 11, 2022 at 01:20 PM
-- Server version: 8.0.19
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int NOT NULL,
  `admin_email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_email`, `password`, `status`) VALUES
(1, 'admin@gmail.com', 'admin', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog`
--

CREATE TABLE `tbl_blog` (
  `blog_id` int NOT NULL,
  `user_id` int NOT NULL,
  `posted_by` varchar(30) NOT NULL,
  `category` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(700) NOT NULL,
  `image` varchar(60) NOT NULL,
  `date` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_blog`
--

INSERT INTO `tbl_blog` (`blog_id`, `user_id`, `posted_by`, `category`, `title`, `description`, `image`, `date`, `status`) VALUES
(5, 5, 'Umesh Narayan', 'Business', 'How to start a travel blog in 5 mins', 'Blogger is an American online content management system founded in 1999 which enables multi-user blogs with time-stamped entries. Pyra Labs developed it before being acquired by Google in 2003. Google hosts the blogs, which can be accessed through a subdomain of blogspot.com.\r\nWhen it comes to starting your travel blog, what many people don’t understand is that getting off on the right foot is half the battle. If your site isn’t supported by the right tools and software, you might be setting it up for failure.', 'how-to-start-travel-blog.jpg', '2022-11-10', 'show'),
(9, 9, 'Ashwani Singh', 'Fashion', 'Trendiest Fashion Blogs to Follow latest fashion tips', 'Instagram is great when it comes to OOTDs—outfit of the day—and quick style inspirations, but blogs are where the serious fashionistas go to write about trends, advice, and the latest fashion innovations. Not feeling particularly stylish today? Fashion blogs can give you inspiration for dressing well even on those lazy mornings. Got your eye on this season’s hottest trends? These blogs are great for helping you figure out which clothing pieces and colors suit your frame. They can also provide you with ideas about mixing and matching pieces to create a dozen perfect looks without breaking the bank.\r\n\r\n', 'download.jpeg', '2022-11-10', 'show'),
(10, 9, 'Ashwani Singh', 'Business', 'Big Ideas for Growing Small Business', 'The day you decide to take the plunge, leave your day job, and become a business owner can be extremely exciting, but it can real challenge. Starting and developing a business requires a high level of risk, expertise and dedication. To bolster an entrepreneurs chance of succeeding, we at ZoomShift have scoured the web for small business blogs in order to help find them the information they’re looking for. Here are fifteen of the best blogs at present for small business owners—providing information, insights and guidance:', 'b1.jpg', '2022-11-10', 'show'),
(11, 4, 'Ram Kumar', 'Food', 'Love Real Food How to Start a Food Blog: Step by Step', 'Here are the basic steps to set up a self-hosted WordPress food blog that is both beautiful and functional. Your blog will have your own domain name and your own distinct look, and it will be able to scale with you as your blog grows. When you’re starting a food blog, I recommend following these steps for a greater shot at success.\r\nShe has covered five continents and 25 countries while travelling and writing about her travel experience in her blogs. She started her blog in 2005 to share her travel experience. As a result, her blogs have won many awards, including the Indibloggies – India\'s best travel blog of the year', 'Food-Blogs-1.jpg', '2022-11-10', 'show'),
(16, 5, 'Umesh Narayan', 'Food', 'Stay in the Present with these 10 Technology ', 'Invest yourself in the business verse of the tech world with one of the most popular technology blogs thriving this year- TechCrunch.\r\n\r\nThe blog publishes content on businesses related to tech, analysis of emerging trends in tech, technology news, and listings of new tech products in the market. It is one of the first publications to report broadly on tech startups and funding rounds.\r\n\r\nTechCrunch offers knowledge about new gizmos and business-related apps. It is like a reservoir of information on Internet companies & startups around the world.', '1_QVTcnfXyMXivNu62IJ7JSg.jpeg', '2022-11-11', 'show');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cat_id` int NOT NULL,
  `cat_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cat_id`, `cat_name`) VALUES
(5, 'Travel'),
(6, 'Fashion'),
(7, 'Business'),
(8, 'Food'),
(9, 'Sports'),
(10, 'Technology'),
(11, 'dsdd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register`
--

CREATE TABLE `tbl_register` (
  `user_id` int NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(60) NOT NULL,
  `image` varchar(100) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `pincode` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_register`
--

INSERT INTO `tbl_register` (`user_id`, `user_name`, `gender`, `email`, `mobile`, `address`, `image`, `city`, `state`, `pincode`, `password`, `status`) VALUES
(4, 'Ram Kumar', 'male', 'ram@gmail.com', '6958656321', 'Kaisarbagh Lucknow', '2.jpeg', 'Lucknow', 'Uttar Pradesh', '265632', '1234', 'approved'),
(5, 'Umesh Narayan', 'male', 'srivastavau215@gmail.com', '9140843718', '121/K Purania Lucknow', '3.jpeg', 'Lucknow', 'Uttar Pradesh', '202360', '1234', 'approved'),
(8, 'Saurabh Kumar', 'male', 'saurabh@gmail.com', '9658745632', '121/K Alambag Lucknow', 'image (2).png', 'Lucknow', 'Uttar Pradesh', '236958', '1234', 'approved'),
(9, 'Ashwani Singh', 'male', 'ashwani@gmail.com', '9874563256', 'Sector-J Jankipuram Lucknow', 'image (3).png', 'Lucknow', 'Uttar Pradesh', '236523', '1234', 'approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `tbl_register`
--
ALTER TABLE `tbl_register`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  MODIFY `blog_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cat_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_register`
--
ALTER TABLE `tbl_register`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
