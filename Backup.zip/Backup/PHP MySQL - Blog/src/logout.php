<?php
// session starts here---
session_start();
session_unset(); //session unset---
session_destroy(); //session destroy----
echo "<script>alert('Logged Out Successfully.!!');window.location.href='login.php';</script>"; //redirect to login page---
