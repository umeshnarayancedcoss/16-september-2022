<?php
// session starts here------
session_start();
$email = $_SESSION['user'];
include("./config/config.php"); //database connection---
$query = "SELECT * FROM tbl_register where email = '$email'"; //select query for fetch user detail----
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // holding user id and name in variables----
        $user_id =  $row["user_id"];
        $user_name =  $row["user_name"];
    }
}
if (isset($_POST)) { //On submit post button---
    // holding form values into variables-----
    $category = $_POST['category'];
    $title = $_POST['title'];
    $blog_description = $_POST['blog_description'];
    $filename = $_FILES['file']['name'];
    $filetype = $_FILES['file']['type'];
    $file_tmp_name = $_FILES['file']['tmp_name'];
    $filesize = $_FILES['file']['size'];
    $file_ext = strtolower(end(explode('.', $_FILES['file']['name'])));
    $uploaddir = "./blog_images/";
    $uploadfile = $uploaddir . basename($_FILES['file']['name']);
    // Insertion query for insert blog in blog tble------
    $query = "INSERT INTO tbl_blog (blog_id,user_id,posted_by,category,title,description,image,date,status) VALUES (NULL, '$user_id','$user_name','$category', '$title','$blog_description','$filename',CURDATE(),'hide')";
    mysqli_query($conn, $query); //executing query---
    move_uploaded_file($file_tmp_name, "./blog_images/" . $filename); //image moved into folder----
    echo "<script>alert('Blog Posted Successfully.!!');window.location.href='myblog.php';</script>";
}
