<?php
// session starts here------
session_start();
$email = $_SESSION['user'];
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:login.php");
}
include("./config/config.php"); //database connectivity --
// Navbar Linking Condition----------
if ($_SESSION['user'] == "") {
    include("menu.php");
} else {
    include("usermenu.php");
}
$query = "SELECT * FROM tbl_register where email = '$email'"; //generating query for user detail----
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // storing user details into variables--------
        $user_id =  $row["user_id"];
        $user_name =  $row["user_name"];
    }
}
?>
<!-- ------HTML Code Starts Here---------- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>My Blogs</title>
    <style>
        /* ---------CSS For Table Tag------ */
        table,
        th,
        td {
            border: 1px solid black;
            text-align: center;
        }

        .table_show {
            font-family: rockwell;
            width: 100%;
            margin: 0px auto;
            cursor: not-allowed;
        }

        tr:nth-child(even) {
            background-color: pink;
        }

        tr:hover {
            background-color: aqua;
        }
    </style>
</head>

<body>
    <!-- -----------Showing data in table starts here------- -->
    <div class="showtables">
        <center>
            <h1>My Blogs</h1>
            <table class="table_show">
                <tr>
                    <th>S. No.</th>
                    <th>Blog ID</th>
                    <th>Posted Date</th>
                    <th>Category</th>
                    <th>Title</th>
                    <th>Related Image</th>
                    <th>Status</th>
                    <th>Delete</th>
                    <th>View</th>
                </tr>
                <?php
                // Fetching blogs from tbl_blog posted by specific user-------
                $query1 = "SELECT * FROM tbl_blog where user_id=$user_id order by blog_id desc";
                $result1 = mysqli_query($conn, $query1); //executing query-------
                $a = 1;
                while ($row1 = mysqli_fetch_assoc($result1)) {
                    $status = $row1['status'];
                ?>
                    <tr>
                        <td><?php echo $a++; ?></td>
                        <td><?php echo $row1['blog_id'] ?></td>
                        <td><?php echo $row1['date'] ?></td>
                        <td><?php echo $row1['category'] ?></td>
                        <td><?php echo $row1['title'] ?></td>
                        <td><img src="./blog_images/<?php echo $row1['image'] ?>" style="height:100px;width:100px;"></td>
                        <td><?php echo $status ?></td>
                        <td><a href="delete_blog.php?blog_id=<?php echo $row1['blog_id'] ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Delete</button></a></td>
                        <td><a href="view_blog.php?blog_id=<?php echo $row1['blog_id'] ?>">View</a></td>
                    <?php
                }
                    ?>
                    </tr>
                    <?php
                    $a++;
                    ?>
                    <tr></tr>
            </table>
    </div>
    </center>

</body>

</html>