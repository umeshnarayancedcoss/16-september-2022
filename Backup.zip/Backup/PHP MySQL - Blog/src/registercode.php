<?php
include("./config/config.php"); //database connectivity--------
// Holding Forms Input Fields Values into variables---------
$name = $_POST['name'];
$gender = $_POST['a'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$pincode = $_POST['pincode'];
$password = $_POST['password'];
$filename = $_FILES['file']['name'];
$filetype = $_FILES['file']['type'];
$file_tmp_name = $_FILES['file']['tmp_name'];
$filesize = $_FILES['file']['size'];
$file_ext = strtolower(end(explode('.', $_FILES['file']['name'])));
$uploaddir = "./images/";
$uploadfile = $uploaddir . basename($_FILES['file']['name']);
// Insertion query for inserting data into register table------------
$query = "INSERT INTO tbl_register (user_id,user_name,gender,email,mobile,address,image,city,state,pincode,password,status) VALUES (NULL, '$name','$gender', '$email','$mobile','$address','$filename','$city','$state','$pincode','$password','requested')";
mysqli_query($conn, $query); //executing query--
move_uploaded_file($file_tmp_name, "./images/" . $filename); //move image file to 'images' folder-----
echo "<script>alert('Registered Successfully.!!');window.location.href='register.php';</script>";
