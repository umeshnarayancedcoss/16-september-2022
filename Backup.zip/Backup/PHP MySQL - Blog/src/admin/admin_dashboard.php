<?php
// session starts here----------
session_start();
$_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
    session_destroy();
    header("location:index.php");
}
include("adminmenu.php"); //Linking Admin Navbar-----
?>
<!-- -----HTML Code Starts Here------ -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Admin Dashboard</title>
</head>

<body>
    <!-- ----------Admin DashBoard Options DIVs Starts Here---------- -->
    <div class="container" style="margin-top: 3%;">
        <div class="col-sm-12">
            <div class="row">
                <div class="col-sm-6" style="height:250px;">
                    <div class="container" style="background-color:aqua;height:200px;border-radius:20px;">
                        <span style="font-size:60px;background-color:red;border-radius:10px;margin-left:150px;"><a href="view_users.php" style="text-decoration: none;color:white">Users</a></span>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="container" style="background-color:aqua;height:200px;border-radius:20px;">
                        <span style="font-size:60px;background-color:red;border-radius:10px;margin-left:150px;"><a href="view_blog.php" style="text-decoration: none;color:white">Blogs</a></span>
                    </div>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-sm-6" style="height:250px;">
                    <div class="container" style="background-color:aqua;height:200px;border-radius:20px;">
                        <span style="font-size:60px;background-color:red;border-radius:10px;margin-left:150px;"><a href="#" style="text-decoration: none;color:white">Admin</a></span>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="container" style="background-color:aqua;height:200px;border-radius:20px;">
                        <span style="font-size:60px;background-color:red;border-radius:10px;margin-left:150px;"><a href="category.php" style="text-decoration: none;color:white">Category</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>