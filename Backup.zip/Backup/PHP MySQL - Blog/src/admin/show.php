<?php
// session start----------
session_start();
$blog_id = $_REQUEST['blog_id'];
include("../config/config.php"); //database connectivity----
// Update Query for changing status from 'show' to 'hide';
$query = "UPDATE `tbl_blog` SET `status` = 'hide' WHERE `tbl_blog`.`blog_id` = $blog_id";
mysqli_query($conn, $query);
header("location:view_blog.php");
