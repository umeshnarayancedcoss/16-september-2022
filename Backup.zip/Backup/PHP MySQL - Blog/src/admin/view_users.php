<?php
// session starts here--------
session_start();
$_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
  session_destroy();
  header("location:index.php");
}
include("../config/config.php"); //database connectivity----------
include("adminmenu.php"); //Linking Admin NavBar--------
?>
<!----- HTML Code starts Here-- -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Latest compiled and minified CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Latest compiled JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- linking jQuery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <title>View Users</title>
  <style>
    /* ---CSS for table--------- */
    table,
    th,
    td {
      border: 1px solid black;
      text-align: center;
    }

    .table_show {
      font-family: rockwell;
      width: 100%;
      margin: 0px auto;
      cursor: not-allowed;
    }

    tr:nth-child(even) {
      background-color: pink;
    }

    tr:hover {
      background-color: aqua;
    }
  </style>
</head>

<body>
  <!-- ------DIV for showing users in a table---------- -->
  <table class="show_table">
    <tr>
      <th>S. No.</th>
      <th>User ID</th>
      <th>User Name</th>
      <th>Gender</th>
      <th>Email</th>
      <th>Contact No.</th>
      <th>Address</th>
      <th>Image</th>
      <th>City</th>
      <th>State</th>
      <th>Pin Code</th>
      <th>Password</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
    <?php
    // QUery For fetching all users from Register Table-----
    $query = "SELECT * FROM tbl_register order by user_id desc";
    $result = mysqli_query($conn, $query); //executing query------
    $a = 1;
    while ($row = mysqli_fetch_assoc($result)) {
      $status = $row['status'];
    ?>
      <tr>
        <td><?php echo $a++; ?></td>
        <td><?php echo $row['user_id'] ?></td>
        <td><?php echo $row['user_name'] ?></td>
        <td><?php echo $row['gender'] ?></td>
        <td><?php echo $row['email'] ?></td>
        <td><?php echo $row['mobile'] ?></td>
        <td><?php echo $row['address'] ?></td>
        <td><img src="../images/<?php echo $row['image'] ?>" style="height:100px;width:100px;"></td>
        <td><?php echo $row['city'] ?></td>
        <td><?php echo $row['state'] ?></td>
        <td><?php echo $row['pincode'] ?></td>
        <td><?php echo $row['password'] ?></td>
        <?php
        if ($status == "requested") { //if status to be 'requested'------
        ?>
          <td><a href="requested.php?user_id=<?php echo $row['user_id']  ?>"><?php echo $status ?></a></td>
        <?php
        } else { //if status to be 'approved'---------
        ?>
          <td><a href="approved.php?user_id=<?php echo $row['user_id']  ?>"><?php echo $row['status'] ?></a></td>
        <?php
        }
        ?>
        <td><a href="delete_users.php?user_id=<?php echo $row['user_id'] ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Delete</button></a></td>
      <?php
    }
      ?>
      </tr>
      <?php
      $a++;
      ?>
      <tr></tr>
  </table>
</body>

</html>