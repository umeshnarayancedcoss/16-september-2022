<!-- --HTML Code Starts Here----- -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Latest compiled and minified CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Latest compiled JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- linking jQuery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="./css/style.css">
  <style>
    /* ------CSS For Hover on NavBar---- */
    .nav-item:hover {
      background-color: white;
    }
  </style>
</head>

<body>
  <div style="margin-top:70px;">
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="#"><img src="../images/blogger-logo-icon-png-22.png" style="height:30px;width:35px;"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="admin_dashboard.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="view_users.php">View Users</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="view_blog.php">View Blogs</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="category.php">View Category</a>
            </li>
          </ul>
          <ul class="nav navbar-right rbx-navbar-icon-group">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="logout.php">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </div>
</body>

</html>