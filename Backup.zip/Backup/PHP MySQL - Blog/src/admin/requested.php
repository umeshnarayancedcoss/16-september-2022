<?php
// session starts here----------
session_start();
$user_id = $_REQUEST['user_id'];
include("../config/config.php"); //database connectivity-----
// Upadte query for changing status from 'requested' to 'approved';
$query = "UPDATE `tbl_register` SET `status` = 'approved' WHERE `tbl_register`.`user_id` = $user_id";
mysqli_query($conn, $query); //executing query--
header("location:view_users.php");
