<?php
// session starts here---
session_start();
include("../config/config.php"); //database connectivity---
$user_id = $_REQUEST['user_id'];
$query = "DELETE FROM `tbl_register` WHERE `tbl_register`.`user_id` = $user_id"; //Query for delete user---
mysqli_query($conn, $query); //executing query---
echo "<script>alert('User Deleted Successfully.!!');window.location.href='view_users.php';</script>";
