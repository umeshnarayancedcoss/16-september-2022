<?php
// session starts here-------
session_start();
$user_id = $_REQUEST['user_id']; //holding user id in a variable--
include("../config/config.php"); //database connectivity-------
// Query for upadte status from 'approved' to 'requested' in register table-----
$query = "UPDATE `tbl_register` SET `status` = 'requested' WHERE `tbl_register`.`user_id` = $user_id";
mysqli_query($conn, $query); //executing query------
header("location:view_users.php");//redirected to ViewUser Page-------
