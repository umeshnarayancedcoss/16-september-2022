<?php
// session starts here------
session_start();
$_SESSION['admin'];
if (!isset($_SESSION['admin'])) {
  session_destroy();
  header("location:index.php");
}
include("../config/config.php"); //database connectivity---
include("adminmenu.php"); //Linking AdminMenu-----------
?>
<!-- --------HTML Code Starts Here--------- -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Latest compiled and minified CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Latest compiled JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- linking jQuery File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <title>View Blogs</title>
  <style>
    /* -----CSS for table-------------- */
    table,
    th,
    td {
      border: 1px solid black;
      text-align: center;
    }

    .table_show {
      font-family: rockwell;
      width: 100%;
      margin: 0px auto;
      cursor: not-allowed;
    }

    tr:nth-child(even) {
      background-color: pink;
    }

    tr:hover {
      background-color: aqua;
    }
  </style>
</head>

<body>
  <!-- ------DIV For showing tables showing here------ -->
  <div class="showtables">
    <table class="table_show">
      <tr>
        <th>S. No.</th>
        <th>Blog ID</th>
        <th>User ID</th>
        <th>Posted By</th>
        <th>Posted Date</th>
        <th>Category</th>
        <th>Title</th>
        <th>Description</th>
        <th>Related Image</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
      <?php
      // ---Query for fetching all Blogs From Blog Table------------
      $query = "SELECT * FROM tbl_blog order by blog_id desc";
      $result = mysqli_query($conn, $query); //executing query----
      $a = 1;
      while ($row = mysqli_fetch_assoc($result)) {
        $status = $row['status'];
      ?>
        <tr>
          <td><?php echo $a++; ?></td>
          <td><?php echo $row['blog_id'] ?></td>
          <td><?php echo $row['user_id'] ?></td>
          <td><?php echo $row['posted_by'] ?></td>
          <td><?php echo $row['date'] ?></td>
          <td><?php echo $row['category'] ?></td>
          <td><?php echo $row['title'] ?></td>
          <td><?php echo $row['description'] ?></td>
          <td><img src="../blog_images/<?php echo $row['image'] ?>" style="height:100px;width:100px;"></td>
          <?php
          if ($status == "show") { //if status will be 'show'----
          ?>
            <td><a href="show.php?blog_id=<?php echo $row['blog_id']  ?>"><?php echo $status ?></a></td>
          <?php
          } else { //if status will be 'hide'------
          ?>
            <td><a href="hide.php?blog_id=<?php echo $row['blog_id']  ?>"><?php echo $row['status'] ?></a></td>
          <?php
          }
          ?>
          <td><a href="delete_blog.php?blog_id=<?php echo $row['blog_id'] ?>"><button style="height:25px;width:70px;background-color:red;color:white;border-radius:15px;border:none;">Delete</button></a></td>
        <?php
      }
        ?>
        </tr>
        <?php
        $a++;
        ?>
        <tr></tr>
    </table>
  </div>
</body>

</html>