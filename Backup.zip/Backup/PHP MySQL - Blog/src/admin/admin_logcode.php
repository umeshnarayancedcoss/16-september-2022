<?php
// session starts here----
session_start();
include("../config/config.php"); //Linking Database Connectivity File-----
if (isset($_POST)) {
    // Holding Form Input Values into Variables------
    $email = $_POST['email'];
    $password = $_POST['password'];
    //Query For Fetching Email and Password from Admin Table----------
    $query = "select admin_email,password from tbl_admin where admin_email = '$email' and password = '$password'";
    $res = mysqli_query($conn, $query); //Executing Query---
    if ($row = mysqli_fetch_array($res, MYSQLI_BOTH)) {
        $_SESSION['admin'] = $email; //creating admin session of mail id-------
        header("location:admin_dashboard.php"); // redirect to admin dashboard-----
    } else { //if email and password will be not matched --------
        $msg = "Error: Wrong Email ID or Password.!!";
        header("location:index.php?msg=$msg");
    }
}
