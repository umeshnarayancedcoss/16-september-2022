<?php
// session starts here-----
session_start();
$blog_id = $_REQUEST['blog_id'];
include("../config/config.php"); //database connectivity----
// Query for change Blog status from 'hide' to 'show'---------------
$query = "UPDATE `tbl_blog` SET `status` = 'show' WHERE `tbl_blog`.`blog_id` = $blog_id";
mysqli_query($conn, $query); //executing query------
header("location:view_blog.php"); //redirected to viewBlog Page----
