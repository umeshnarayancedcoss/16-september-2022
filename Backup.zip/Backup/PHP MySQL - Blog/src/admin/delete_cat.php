<?php
// session starts here------
session_start();
include("../config/config.php"); //database connectivity-----
$cat_id = $_REQUEST['cat_id'];
$query = "DELETE FROM `tbl_category` WHERE `tbl_category`.`cat_id` = $cat_id"; //delete query for delete category---
mysqli_query($conn, $query); //eecuting query--
echo "<script>alert('Category Deleted Successfully.!!');window.location.href='category.php';</script>";
