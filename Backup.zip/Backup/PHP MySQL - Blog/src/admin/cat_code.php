<?php
// session starts here---------
session_start();
include("../config/config.php"); //database connectivity-----
if (isset($_POST)) {
    $category = $_POST['category']; //holding form value into variable--
    $query = "INSERT into tbl_category(cat_name)values('$category')"; //Insertion query in category table--
    mysqli_query($conn, $query); //executing query---
    header("location:category.php");
}
