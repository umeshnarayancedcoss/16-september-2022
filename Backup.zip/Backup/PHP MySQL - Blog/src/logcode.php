<?php
// session_starts here--------
session_start();
include("./config/config.php"); //database connectivity file------
if (isset($_POST)) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    // Query for fetching email, password, status of user from register table-------
    $query = "select email,password,status from tbl_register where email = '$email' and password = '$password' and status='approved'";
    $res = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_array($res, MYSQLI_BOTH)) {
        $_SESSION['user'] = $email; //creating session of user's email-----
        header("location:index.php");
    } else {
        $msg = "Error: Wrong Email ID or Password or Verification Under Process.!!"; //error message------
        header("location:login.php?msg=$msg");
    }
}
