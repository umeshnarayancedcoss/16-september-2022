<?php
// session starts here----
session_start();
include("./config/config.php"); //database connectivity-----
$blog_id = $_REQUEST['blog_id'];
$query = "DELETE FROM `tbl_blog` WHERE `tbl_blog`.`blog_id` = $blog_id"; //delete query----
mysqli_query($conn, $query);
echo "<script>alert('Blog Deleted Successfully.!!');window.location.href='myblog.php';</script>";
