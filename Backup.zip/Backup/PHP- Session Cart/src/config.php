<?php
// initilizing session product array----
$_SESSION['product'] = array(
	array(
		"productid" => "101",
		"images" => "football.png",
		"title" => "Product 101",
		"price" => "150.00",
	),
	array(
		"productid" => "102",
		"images" => "tennis.png",
		"title" => "Product 102",
		"price" => "120.00",
	),
	array(
		"productid" => "103",
		"images" => "basketball.png",
		"title" => "Product 103",
		"price" => "90.00",
	),
	array(
		"productid" => "104",
		"images" => "table-tennis.png",
		"title" => "Product 104",
		"price" => "110.00",
	),
	array(
		"productid" => "105",
		"images" => "soccer.png",
		"title" => "Product 105",
		"price" => "80.00",
	),
);
