<?php
//session_starts here--------
session_start();
if (!isset($_SESSION['product'])) {
	$_SESSION['product'] = array();
}
if (!isset($_SESSION['cart'])) {
	$_SESSION['cart'] = array();
}
if (!isset($_SESSION['quantity'])) {
    $_SESSION['quantity'] = 0;
}
include("config.php"); //including config file that contains Session product array----
?>
<!-- HTML Code starts here -->
<!DOCTYPE html>
<html>
<head>
	<title>
		Products
	</title>
	<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>
	<div id="header">
	<?php include("header.php"); ?>
	</div>
	<!-- Display products from Session Product Array -->
	<div id="main">
		<div id="products">
			<?php
			$i = 0;
			foreach ($_SESSION['product'] as $key => $val1) {
				// holding products details into variables---
				$pro_id=$val1['productid'];
				$pro_images=$val1['images'];
				$pro_title=$val1['title'];
				$pro_price=$val1['price'];
				echo '<div id="product-' . $val1["productid"] . '" class="product">';
				echo '<img src="images/' . $val1["images"] . '">';
				echo '<h3 class="title"><a href="#">' . $val1["title"] . '</a></h3>';
				echo '<span>Price: $' . $val1["price"] . '</span>';
				echo '<a class="add-to-cart" name="add_cart" href="cartcode.php?pro_id='.$pro_id.'&&pro_image='.$pro_images.'&&pro_title='.$pro_title.'&&pro_price='.$pro_price.'">Add To Cart</a>';
				echo '</div>';
			}
			?>
		</div>
	</div>
<div id="cart">
<?php 
// Showing cart as a table----
include("cartdisplay.php");
?>
</div>
	<div id="footer">
	<?php include("footer.php"); ?>
	</div>
</body>
</html>