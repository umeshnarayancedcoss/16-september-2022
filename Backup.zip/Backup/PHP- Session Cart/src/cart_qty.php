<?php
//session starts here-----
session_start();
// Holding product information into variables----
$pro_id = $_REQUEST['pro_id'];
$op = $_REQUEST['op'];
$pro_qty = $_REQUEST['pro_qty'];
$index = $_REQUEST['index'];
// Condition for increase the quantity---------
if ($op == 'inc') {
    foreach ($_SESSION['cart'] as &$value1) {
        if ($pro_id == $value1['productid']) {
            $value1['quantity'] += 1;
            header("location:products.php");
        }
    }
}
// Condition for decrease the quantity----
if ($op == 'dec') {
    if ($pro_qty == 1) { //if quantity zero than it will remove item from cart---
        echo "<script>";
        array_splice($_SESSION['cart'], $index, 1);
        $_SESSION['quantity'] = 0;
        echo "alert('Item removed from cart successfully.!!');
        window.location.href='products.php';
        </script>";
    } else {  //if quantity is greater than zero--------
        foreach ($_SESSION['cart'] as &$value1) {
            if ($value1['quantity'] > 0 && $pro_id == $value1['productid']) {
                $value1['quantity'] -= 1;
                header("location:products.php");
            }
        }
    }
}
