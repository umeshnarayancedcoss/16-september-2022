<?php
// sesssion starts here--
session_start();
// session destroy here---
session_destroy();
header("location:index.php");
