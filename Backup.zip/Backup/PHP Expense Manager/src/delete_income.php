<?php
session_start();
$_SESSION['amount']=0; //income will be set as zero
header("location:index.php");
?>