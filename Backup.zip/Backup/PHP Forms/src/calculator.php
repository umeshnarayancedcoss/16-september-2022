<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Calculator</title>
</head>
<body>

<?php 
// receiving num 1 value
$num1=$_POST['num1'];
//echo $num1;
// receiving num2 value
$num2=$_POST['num2'];
//echo $num2;
$operation=$_POST['operation'];
//echo $operation;

// switch case starts here------
switch($operation){
    case "+": // for addition
        $result=$num1+$num2;
        //echo $result;
        break;
        case "-": // for substraction
            $result=$num1-$num2;
           // echo $result;
            break;
            case "x": // for multiplication
                $result=$num1*$num2;
                //echo $result;
                break;
                case "/": // for diivide
                    $result=$num1/$num2;
                   // echo $result;

}

?>

  <h3>Write a simple calculator program in PHP using switch case</h3>  

  <!-- form starts here -->
<form action="" method="post">
Number 1: <input type="number" name=num1 value="<?php echo $num1; ?>"><br> 
Number 2: <input type="number" name=num2 value="<?php echo $num2; ?>"><br>
Result: <input type="text" name="result" value="<?php echo $result; ?>" readonly><br><br>

<!-- input type submit for operations -->
<input type="submit" value="+" name="operation">
<input type="submit" value="-" name="operation">
<input type="submit" value="x" name="operation">
<input type="submit" value="/" name="operation"><br><br>
<a href="index.php">Back</a>


</form>




</body>
</html>