<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload</title>
</head>
<body>

<?php  

if(isset($_POST['upload'])){
 
$filename=$_FILES['file']['name'];
//echo $filename;
$filetype=$_FILES['file']['type'];
//echo $filetype;
$file_tmp_name=$_FILES['file']['tmp_name'];
//echo $file_tmp_name;
$filesize=$_FILES['file']['size'];
//echo $filesize;
$file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));
//echo $file_ext;

if($filename==""){
    $message="Please select a image first";
}else if($file_ext!=='png'){
    $message="Image type should be png only";
}else if($filesize>200000){
    $message="Image size should not exceed 2MB";
}else {

$uploaddir = "./images/";
$uploadfile = $uploaddir . basename($_FILES['file']['name']);
move_uploaded_file($file_tmp_name,"./images/".$filename);
//echo "Success";
$message1="Image uploaded successfully.!! Please Check 'images' folder.";
}

}
?>  
    <h3>Write a program to upload image</h3>
    Please select a image: <br><br>
 
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="file"><br>
        <p style="color:red"><?php echo $message; ?></p>
        <p style="color:green"><?php echo $message1; ?></p>
        <input type="submit" value="Upload" name="upload"><br><br>
        <a href="index.php">Back</a>
    </form>
</body>
</html>