<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Forms</title>
</head>
<body>
    <!-- Index page that contains program list -->
    <h2>PHP Form Programs</h2>
    <table border="1px solid">
        <tr>
            <th>S.No.</th>
            <th>Program Name</th>
            <th>View</th>
        </tr>
        <tr>
            <td>01</td>
            <td>Write a program to calculate Electricity bill in PHP</td>
            <td><a href="Electricty_Bill.php">View</a></td>
        </tr>
        <tr>
            <td>02</td>
            <td>Write a simple calculator program in PHP using switch case</td>
            <td><a href="calculator.php">View</a></td>
        </tr>
        <tr>
            <td>03</td>
            <td>Write a program to calculate area</td>
            <td><a href="rectangle.php">View</a></td>
        </tr>
        <tr>
            <td>04</td>
            <td>Write a program for conversion</td>
            <td><a href="conversion.php">View</a></td>
        </tr>
        <tr>
            <td>05</td>
            <td>Write a program to upload image</td>
            <td><a href="image_upload.php">View</a></td>
        </tr>
        

    </table>
</body>
</html>