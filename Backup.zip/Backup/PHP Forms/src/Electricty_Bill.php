<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elecricity Bill Calculator</title>
</head>
<body>
<h3>Write a program to calculate Electricity bill in PHP</h3>
<!-- form start here -->
<form method="post" action="bill_code.php">
    Please Enter Your Elecricity Unit:
    <!-- input type number for elecricity unit -->
<input type="number" name="unit" min="0" required /> 
<!-- input type submit for calculate electricity bill -->
<input type="submit" value="Calculate Bill"><br><br>
<a href="index.php">Back</a>

</form>
</body>
</html>