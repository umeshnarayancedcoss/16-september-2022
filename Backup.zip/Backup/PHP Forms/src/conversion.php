<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conversion</title>
</head>
<body>

<?php  
if(isset($_POST['convert'])){
$digit=$_POST['digit'];
//echo $digit;
$choice=$_POST['h'];
//echo $choice;

if($choice=="h_to_m")
{
$h_to_m=$digit*60;
//echo $h_to_m;
$message1= "$digit hours = $h_to_m mins";
//echo $message1;
}
if($choice=="h_to_s"){
    $h_to_s=$digit*3600;
    //echo $h_to_s;
    $message2= "$digit hours = $h_to_s seconds";
    //echo $message2;
}
}
?>
    <h3>Write a program for conversion</h3>
    <!-- form starts here -->
    <form action="" method="post">
    <input type="number" name="digit" min="0"  value="<?php echo $digit; ?>" required/><br><br>
    <input type="radio" name="h" id="h_to_m" value="h_to_m" required>hours to mins <br>
    <input type="radio" name="h" id="h_to_s" value="h_to_s">hours to seconds <br>
<p style="color:red;"><?php echo $message1; ?><?php echo $message2; ?></p>
     <input type="submit" value="Convert" name="convert" /><br><br>
     <a href="index.php">Back</a>
    </form>
</body>
</html>