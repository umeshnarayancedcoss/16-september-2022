<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rectangle Area &P Perimeter</title>
</head>
<body>

<?php
if(isset($_POST['calc'])){
$length=$_POST['length'];
//echo $length;
$width=$_POST['width'];
//echo $width;

$area=$length*$width;
//echo $area;
$perimeter=2*($length+$width);
//echo $perimeter;

$area_msg="Area is echo $area sq. mtr.";
$perimeter_msg="Perimeter is echo $perimeter mtr";

}
?>
<!-- form start here -->
<form action="" method="post">
Length of Rectangle <input type="number" name=length min="0" value=<?php echo $length; ?> /> mt <br><br>
Width of Rectangle <input type="number" name=width min="0" value=<?php echo $width; ?> /> mt <br><br>
<input type="submit" value="Calculate Area & Perimeter" name="calc" style="margin-left:130px;"><br><br>
<a href="index.php">Back</a>

</form>

<div>
  <!-- printing area result -->
<?php echo $area_msg; ?>
</div>
<div>
  <!-- printing perimeter result -->
  <?php echo $perimeter_msg; ?>
</div>

</body>
</html>