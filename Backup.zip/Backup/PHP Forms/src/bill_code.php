<?php

$unit=$_POST['unit'];
//echo $unit;


// if else conditions starts here for bill calculation---
if($unit<=50 && $unit>=0)
{
    $bill=$unit*3.50;
    echo "Your electricity bill is $bill Rs. Only.";
} else if($unit<=150 && $unit>50)
{
    $bill=50*3.50+($unit-50)*4;
    echo "Your electricity bill is $bill Rs. Only.";

}else if($units<=250 && $unit>150){

    $bill=50*3.50+100*4+($unit-150)*5.20;
    echo "Your electricity bill is $bill Rs. Only.";

}else if($unit>250){
    $bill=50*3.50+100*4+100*5.20+($unit-250)*6.50;
    echo "Your electricity bill is $bill Rs. Only.";
}else{
    echo "Please enter valid electrity unit";
}

?>
<br><br>
<a href="index.php">Back</a>