<?php
echo "<h3>7. Log errors into my-error.log file</h3>";
$a = 9;
if ($a < 10) {
    error_log("Write this error down to a file!", 3, "./error.log"); //error log message for my-error.log file---
}
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
