<?php
echo "<h3>4. Create a custom error handler using set error handler that shows error no and error string</h3>";
//error handler function---
function customError($errno, $errstr)
{
    echo "<b>Error:</b> [$errno] $errstr<br>";
    die();
}
//set error handler---
set_error_handler("customError", E_USER_ERROR);
//trigger error---
$value = 150; //variable initilization--
if ($value > 100) {
    trigger_error("Value must be less than 100", E_USER_ERROR); //trigger custom error message--
}
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
