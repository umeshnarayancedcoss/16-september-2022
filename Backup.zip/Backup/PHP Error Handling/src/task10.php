<?php
echo "<h3>10. Send error message to the server log if error connecting to the database</h3>";
// Sending an error message to the server log if error connecting to the database---
if (!mysqli_connect("localhost", "user", "password", "my_db")) {
    error_log("Failed to connect to database.!!", 0);
}
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
