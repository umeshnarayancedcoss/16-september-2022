<?php
echo "<h3>2. Use E_USER_NOTICE if a file exist else use E_USER_ERROR and trigger error</h3>";
if (file_exists("mytestfile.txt")) { //if file exists, it will give a notice---
    trigger_error("file exists", E_USER_NOTICE);
} else { //if file doesn't exists, it will give an error---
    trigger_error("file doesn't exists", E_USER_ERROR);
}
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
