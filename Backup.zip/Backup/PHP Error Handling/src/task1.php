<?php
echo "<h3>1. Trigger an error for certain variable value greater than 100</h3>";
$value = 150; //variable initilization--
if ($value > 100) {
    trigger_error("Value must be less than 100."); //trigger custom error message---
}
echo "<br/>";
echo "<a href='./index.php'>Back</a>";
