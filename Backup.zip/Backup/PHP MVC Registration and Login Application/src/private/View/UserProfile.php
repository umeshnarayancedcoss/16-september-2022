<?php
//session starts here----
session_start();
$email = $_SESSION['user'];
include("../config/config.php"); //database connectivity---
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:../View/Login.php");
}
// Fetching User Record from table based on email id----
$user = User::find(array('conditions' => array('email' => $email)));
// Holding user record values into variables---
$user_id = $user->user_id;
$user_name = $user->user_name;
$user_email = $user->email;
$user_password = $user->password;
?>
<!-- --HTML Code starts here--- -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Welcome <?php echo $user_name; ?></title>
    <style>
        body {
            background-color: white;
        }
    </style>
</head>

<body>
    <center>
        <h1>Welcome <?php echo $user_name; ?></h1>
    </center>
    <center>
        <p>We are delighted to have you among us. On behalf of all the members and the management, we would like to extend our warmest welcome and good wishes!</p>
    </center>
    <br><br>
    <!-- table for displaying user detail -->
    <table border="1px" cellpadding="5px" align="center" style="background-color: pink;">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
        </tr>
        <tr>
            <td><?php echo $user_id; ?></td>
            <td><?php echo $user_name; ?></td>
            <td><?php echo $user_email; ?></td>
            <td><?php echo $user_password; ?></td>
        </tr>
    </table>
    <br><br>
    <center><a href="../Controller/logout.php"><button type="button" class="btn btn-outline-danger">Logout</button></a></center>
</body>

</html>