<?php
// session starts here------
session_start();
if (!isset($_SESSION['todo'])) {
    $_SESSION['todo'] = array();
}
?>
<!-- HTML Starts Here -->
<html>

<head>
    <title>TODO List</title>
    <!-- Linking AJAX CDN -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Linking stylesheet CSS File -->
    <link href="style.css" type="text/css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h2>TODO LIST</h2>
        <h3>Add Item <a href="logout.php">Reset Session</a></h3>
        <!-- ToDo Form starts here -->
        <form>
            <p>
                <input required id="new-task" type="text">
                <button type="submit" id="add">Add</button>
            <p id="update"></p>
            </p>
        </form> <!-- ToDo Form ends here -->
        <p id="msg" style="color:red;"></p> <!-- Showing blank field error message -->
        <!-- Showing toto data -->
        <h3>Todo</h3>
        <div id="todo">
        </div>
    </div>
</body>
<!-- Linking Script File -->
<script src="./script.js"></script>

</html>