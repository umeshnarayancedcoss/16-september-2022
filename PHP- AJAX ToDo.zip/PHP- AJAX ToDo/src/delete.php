<?php
session_start();
$index = $_POST['index'];
array_splice($_SESSION['todo'], $index, 1); //deleting data from todo session array---
