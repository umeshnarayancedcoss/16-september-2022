<?php
// session starts here--------
session_start();
if (!isset($_SESSION['todo'])) {
    $_SESSION['todo'] = array();
}
$taskname = $_POST['task_name'];
if ($taskname == "") {
    echo "no"; //for displaying error msg for blank field--
} else {
    // array data initilzation into varibale---
    $todo_data = array("task_name" => $taskname, "status" => "incomplete");
    // pushing data into todo session array------
    array_push($_SESSION['todo'], $todo_data);
}
