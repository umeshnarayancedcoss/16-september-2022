$(document).ready(function () {
    //-----display function for ToDo-----------
    function display() {
        $.ajax({
            url: "todo_display.php",
            method: "POST",
            success: function (data) {
                $('#todo').html(data);
            }
        });
    }
    // ----------Task Add into ToDo-------------
    $("#add").click(function () {
        var task_name = $("#new-task").val();
        $.ajax({
            url: "task_code.php",
            method: "POST",
            data: {
                task_name: task_name,
            },
            success: function (data) {

                if (data == "no") {
                    var msg = "Can't Add Blank Field.!!";
                    $('#msg').html(msg);

                } else {
                    $("#new-task").val("");
                    $('#msg').html("");
                    display(data);
                }
            }
        });
        return false;
    });
    //-------Checkbox click script---------------
    $(document).on("click", ".cb", function () {
        var index = $(this).attr("id");
        $.ajax({
            url: "checkbox.php",
            method: "POST",
            data: {
                index: index,
            },
            success: function (data) {
                display(data);
            }
        });
    });

    // --------Delete task from ToDo----------------
    $(document).on("click", ".delete", function () {
        var index = $(this).attr("id");
        $.ajax({
            url: "delete.php",
            method: "POST",
            data: {
                index: index,
            },
            success: function (data) {
                display(data);
            }
        });
    });
    // ----------Edit Task---------
    $(document).on("click", ".edit", function () {
        var index = $(this).attr("id");
        $("#add").hide();
        // var y = '<button id="+index+" onclick="update(' + index + ')">update</button>';
        var update_btn = '<button id=' + index + ' class="update">Update</button>';
        $('#update').html(update_btn);
        $.ajax({
            url: "edit.php",
            method: "POST",
            data: {
                index: index,
            },
            success: function (data) {
                $("#new-task").val(data);
            }
        });
    });

    // ------------------update------------------------
    $(document).on("click", ".update", function () {
        var task = $("#new-task").val();
        var index = this.id;
        $.ajax({
            url: "update.php",
            method: "POST",
            data: {
                index: index,
                task: task,
            },
            success: function (data) {
                $("#new-task").val("");
                $(".update").css("display", "none")
                $("#add").show();
                display(data);
            }
        });
        return false;
    });

}); //---jQuery ends here-----------
