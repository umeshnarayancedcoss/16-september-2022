<?php

header("location:../private/View/AdminLogin.php");
