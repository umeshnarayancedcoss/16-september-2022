<?php
header("location:./private/View/indexPage.php");


?>