<?php
// Database Connection File---
require_once '../library/php-activerecord/ActiveRecord.php'; //Linking ActiveRecord File--
ActiveRecord\Config::initialize(function ($cfg) {
    $cfg->set_model_directory('../Model'); //Setting Model Directory--
    $cfg->set_connections(array(
        'development' => 'mysql://root:secret@mysql-server/MVC_blog' //set connection---
    ));
});
