<?php
$msg = $_REQUEST['msg'];
// echo $msg;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Register Now.!!</title>
</head>

<body>

    <section class="vh-100 bg-image" style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp');">
        <div class="mask d-flex align-items-center h-100 gradient-custom-3">
            <div class="container h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                        <div class="card" style="border-radius: 15px;">
                            <div class="card-body p-7">
                                <h2 class="text-uppercase text-center mb-1">Create an account</h2>

                                <form method="POST" action="../Controller/registerController.php">

                                    <div class="form-outline mb-1">
                                        <input type="text" id="form3Example1cg" class="form-control form-control-md" name="name" required />
                                        <label class="form-label" for="form3Example1cg">Your Name</label>
                                    </div>

                                    <div class="form-outline mb-1">
                                        <input type="email" id="form3Example3cg" class="form-control form-control-md" name=email required />
                                        <label class="form-label" for="form3Example3cg">Your Email</label>
                                    </div>

                                    <div class="form-outline mb-1">
                                        <input type="number" id="form3Example3cg" class="form-control form-control-md" name="mobile" required />
                                        <label class="form-label" for="form3Example3cg">Your Contact No.</label>
                                    </div>

                                    <div class="form-outline mb-1">
                                        <input type="password" id="form3Example4cg" class="form-control form-control-md" name="password" required />
                                        <label class="form-label" for="form3Example4cg">Password</label>
                                    </div>

                                    <div class="form-outline mb-1">
                                        <input type="password" id="form3Example4cdg" class="form-control form-control-md" name="cnfpass" required />
                                        <label class="form-label" for="form3Example4cdg">Repeat your password</label>
                                    </div>

                                    <center>
                                        <p style="color:red;"><?php echo $msg; ?></p>
                                    </center>
                                    <div class="d-flex justify-content-center">
                                        <button type="submit" class="btn btn-success btn-block btn-lg gradient-custom-4 text-body">Register</button>
                                    </div>

                                    <p class="text-center text-muted mt-2 mb-0">Have already an account? <a href="./Login.php" class="fw-bold text-body"><u>Login here</u></a></p>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>

</html>