<?php
// session starts here-------
session_start();
$_SESSION['user'];
if (!isset($_SESSION['user'])) {
    session_destroy();
    header("location:login.php");
}
// if session will be blank it will include menu.php otherwise it will include usermenu.php---
// if ($_SESSION['user'] == "") {
//     include("menu.php");
// } else {
//     include("usermenu.php");
// }
include("../config/config.php"); //including database connection file------
?>
<!-- HTML Code Starts Here -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- linking jQuery File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>::Post a Blog::</title>
</head>

<body>
    <!-- -----------------Form Starts Here----------- -->
    <form action="blog_form_code.php" method="POST" enctype="multipart/form-data">
        <section class="vh-100">
            <div class="container h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-xl-9">
                        <h3 class="text-black mb-2">Post a blog--</h3>
                        <div class="card" style="border-radius: 15px;">
                            <div class="card-body">
                                <div class="row align-items-center pt-4 pb-3">
                                    <div class="col-md-3 ps-5">
                                        <h6 class="mb-0">Blog Category</h6>
                                    </div>
                                    <div class="col-md-9 pe-5">
                                        <select name="category" id="category" class="form-control form-control-md" required>
                                            <option value="" disabled selected>---Select---</option>
                                            <!-- ---Generating options from category table----- -->
                                            <?php
                                            $category=Category::find('all', array('order' => 'cat_name asc')); //category query
                                          foreach($category as $key=> $value) {
                                                echo "<option>" .  $value->cat_name . "</option>"; //generating options---
                                            }
                                            ?>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                </div>
                                <hr class="mx-n3">
                                <div class="row align-items-center py-3">
                                    <div class="col-md-3 ps-5">
                                        <h6 class="mb-0">Title</h6>
                                    </div>
                                    <div class="col-md-9 pe-5">
                                        <input type="text" class="form-control form-control-md" name="title" id="title" placeholder="Write your Blog Title Here" required />
                                    </div>
                                </div>
                                <hr class="mx-n3">
                                <div class="row align-items-center py-3">
                                    <div class="col-md-3 ps-5">
                                        <h6 class="mb-0">Blog</h6>
                                    </div>
                                    <div class="col-md-9 pe-5">
                                        <textarea class="form-control" name="blog_description" rows="3" placeholder="Write your Blog Here" style="resize: none;" required></textarea>
                                    </div>
                                </div>
                                <hr class="mx-n3">
                                <div class="row align-items-center py-3">
                                    <div class="col-md-3 ps-5">
                                        <h6 class="mb-0">Upload Relevant Image</h6>
                                    </div>
                                    <div class="col-md-9 pe-5">
                                        <input class="form-control form-control-md" id="formFileLg" type="file" name="file" required />
                                        <div class="small text-muted mt-2">Upload your relevant image. Max file
                                            size 2 MB</div>
                                    </div>
                                </div>
                                <hr class="mx-n3">
                                <div class="px-5 py-4">
                                    <button type="submit" class="btn btn-primary btn-lg" id="post_blog">Post</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </form>
    <!-- --------------------Form ends here------------ -->
</body>

</html>