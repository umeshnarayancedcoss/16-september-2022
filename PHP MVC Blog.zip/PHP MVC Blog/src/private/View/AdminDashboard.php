<?php
session_start();

if($_SESSION['admin']!=""){
    echo $_SESSION['admin'];
    echo "<br>";
    echo '<a href="../View/AddCategory.php">Add Category</a>';
    echo "<br>";
    echo '<a href="../Controller/adminLogout.php">Logout</a>';
}


?>