<?php
session_start();
echo $_SESSION['user'];
echo "<br>";
echo "IndexPage.php";
echo "<br>";
if ($_SESSION['user'] == "") {
    echo '<a href="./Register.php">Register</a>';
} else {
    echo '<a href="../View/blogForm.php">Post a Blog</a>';
    echo "<br>";
    echo '<a href="../Controller/logout.php">Logout</a>';
}
