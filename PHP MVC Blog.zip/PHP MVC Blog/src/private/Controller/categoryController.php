<?php
session_start();
include "../config/config.php";

    $category = $_POST['category'];
    // echo $category;
 
    $category = Category::create(array('cat_name' => $category));
     header("location:../View/AddCategory.php");
