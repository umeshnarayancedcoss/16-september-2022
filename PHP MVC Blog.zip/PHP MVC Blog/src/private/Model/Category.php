<?php
//ActiveRecord Model extending properties to Class Category----
class Category extends ActiveRecord\Model
{
}
