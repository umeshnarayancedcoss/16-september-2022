<?php
session_start();
$pro_index = $_POST['pro_index'];
array_splice($_SESSION['cart'], $pro_index, 1); //product remove from cart--
$_SESSION['quantity'] = 0; //session quantity set as 0----
