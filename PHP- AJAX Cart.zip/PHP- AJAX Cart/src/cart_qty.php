<?php
//session starts here--
session_start();
$op = $_REQUEST['op'];
$pro_index=$_POST['pro_index'];

if($op=="inc"){ //for increase counter
    $_SESSION['cart'][$pro_index]['quantity']++;
}
if ($op == 'dec') { //for decrease counter
    if ($_SESSION['cart'][$pro_index]['quantity'] == 1) { //if quantity zero than it will remove item from cart---
        array_splice($_SESSION['cart'], $pro_index, 1);
        $_SESSION['quantity'] = 0;
       echo 0;
    } else {  //if quantity is greater than zero--------
        $_SESSION['cart'][$pro_index]['quantity']--;
    }
}
