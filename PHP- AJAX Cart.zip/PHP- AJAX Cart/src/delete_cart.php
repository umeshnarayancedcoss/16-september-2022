<?php
session_start();
$_SESSION['cart'] = []; //session cart will be empty--
$_SESSION['quantity'] = 0; //session quantity will be zero--
