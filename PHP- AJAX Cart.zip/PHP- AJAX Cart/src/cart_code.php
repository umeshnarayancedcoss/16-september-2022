<?php
// sessiom starts here---
session_start();
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}
if (!isset($_SESSION['quantity'])) {
    $_SESSION['quantity'] = 0;
}
$pro_index = $_POST['pro_index'];
$flag = 0; //temporary variable for data insertion--
if (count($_SESSION['cart']) == 0) { //if cart will be blank---
    $_SESSION['quantity'] = $_SESSION['quantity'] + 1;
    $cart_data = array("productindex" => $pro_index, "quantity" => $_SESSION['quantity']);
    array_push($_SESSION['cart'], $cart_data);
} else if (count($_SESSION['cart']) > 0) { //checking that products already exists in cart or not.
    foreach ($_SESSION['cart'] as &$value1) {
        if ($pro_index == $value1['productindex']) {
            $flag = 1;
            $value1['quantity'] += 1;
        }
    }
    if ($flag == 0) { //if same product not exists in cart----
        $_SESSION['quantity'] = 1;
        $cart_data = array("productindex" => $pro_index, "quantity" => $_SESSION['quantity']);
        array_push($_SESSION['cart'], $cart_data);
    }
}
